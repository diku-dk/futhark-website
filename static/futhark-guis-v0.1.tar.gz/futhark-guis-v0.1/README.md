Prepackaged Futhark GUIs
==

This is a prepackaged archive of interactive Futhark -- see
http://futhark-lang.org -- visualisations.  To run them, you must have PyOpenCL,
PyGame, and NumPy installed on your system.

**IMPORTANT**: This package was developed for the purpose of showing off
Futhark's current capabilities for those who don't want to compile a large
compiler just to run a few examples, and as such this package does not
necessarily represent the newest advances in Futhark.  See
https://github.com/HIPERFIT/futhark-benchmarks for the sources of the four
included visualisations.

Published April 20, 2016.
