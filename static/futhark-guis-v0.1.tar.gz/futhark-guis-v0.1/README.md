Prepackaged Futhark GUIs
==

See http://futhark-lang.org for an overview of the Futhark programming
language.

This is a prepackaged archive of interactive Futhark visualisations.
To run them, you must have PyOpenCL, PyGame, and NumPy installed on
your system.

**IMPORTANT**: This package was developed for the purpose of showing
off Futhark's current interactive capabilities for those who don't
want to compile a large compiler just to run a few examples.  As such,
this package does not necessarily represent the newest advances in
Futhark.  See https://github.com/HIPERFIT/futhark-benchmarks for the
sources of the four included visualisations.

Packaged on April 22, 2016.
