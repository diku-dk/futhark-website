import sys
import numpy as np
import ctypes as ct
import pyopencl as cl
import time
import argparse
FUT_BLOCK_DIM = "16"
cl_group_size = np.int32(512)
synchronous = False
fut_opencl_src = """typedef char int8_t;
typedef short int16_t;
typedef int int32_t;
typedef long int64_t;
typedef uchar uint8_t;
typedef ushort uint16_t;
typedef uint uint32_t;
typedef ulong uint64_t;
static inline int8_t add8(int8_t x, int8_t y)
{
    return x + y;
}
static inline int16_t add16(int16_t x, int16_t y)
{
    return x + y;
}
static inline int32_t add32(int32_t x, int32_t y)
{
    return x + y;
}
static inline int64_t add64(int64_t x, int64_t y)
{
    return x + y;
}
static inline int8_t sub8(int8_t x, int8_t y)
{
    return x - y;
}
static inline int16_t sub16(int16_t x, int16_t y)
{
    return x - y;
}
static inline int32_t sub32(int32_t x, int32_t y)
{
    return x - y;
}
static inline int64_t sub64(int64_t x, int64_t y)
{
    return x - y;
}
static inline int8_t mul8(int8_t x, int8_t y)
{
    return x * y;
}
static inline int16_t mul16(int16_t x, int16_t y)
{
    return x * y;
}
static inline int32_t mul32(int32_t x, int32_t y)
{
    return x * y;
}
static inline int64_t mul64(int64_t x, int64_t y)
{
    return x * y;
}
static inline uint8_t udiv8(uint8_t x, uint8_t y)
{
    return x / y;
}
static inline uint16_t udiv16(uint16_t x, uint16_t y)
{
    return x / y;
}
static inline uint32_t udiv32(uint32_t x, uint32_t y)
{
    return x / y;
}
static inline uint64_t udiv64(uint64_t x, uint64_t y)
{
    return x / y;
}
static inline uint8_t umod8(uint8_t x, uint8_t y)
{
    return x % y;
}
static inline uint16_t umod16(uint16_t x, uint16_t y)
{
    return x % y;
}
static inline uint32_t umod32(uint32_t x, uint32_t y)
{
    return x % y;
}
static inline uint64_t umod64(uint64_t x, uint64_t y)
{
    return x % y;
}
static inline int8_t sdiv8(int8_t x, int8_t y)
{
    int8_t q = x / y;
    int8_t r = x % y;
    
    return q - ((r != 0 && r < 0 != y < 0) ? 1 : 0);
}
static inline int16_t sdiv16(int16_t x, int16_t y)
{
    int16_t q = x / y;
    int16_t r = x % y;
    
    return q - ((r != 0 && r < 0 != y < 0) ? 1 : 0);
}
static inline int32_t sdiv32(int32_t x, int32_t y)
{
    int32_t q = x / y;
    int32_t r = x % y;
    
    return q - ((r != 0 && r < 0 != y < 0) ? 1 : 0);
}
static inline int64_t sdiv64(int64_t x, int64_t y)
{
    int64_t q = x / y;
    int64_t r = x % y;
    
    return q - ((r != 0 && r < 0 != y < 0) ? 1 : 0);
}
static inline int8_t smod8(int8_t x, int8_t y)
{
    int8_t r = x % y;
    
    return r + (r == 0 || (x > 0 && y > 0) || (x < 0 && y < 0) ? 0 : y);
}
static inline int16_t smod16(int16_t x, int16_t y)
{
    int16_t r = x % y;
    
    return r + (r == 0 || (x > 0 && y > 0) || (x < 0 && y < 0) ? 0 : y);
}
static inline int32_t smod32(int32_t x, int32_t y)
{
    int32_t r = x % y;
    
    return r + (r == 0 || (x > 0 && y > 0) || (x < 0 && y < 0) ? 0 : y);
}
static inline int64_t smod64(int64_t x, int64_t y)
{
    int64_t r = x % y;
    
    return r + (r == 0 || (x > 0 && y > 0) || (x < 0 && y < 0) ? 0 : y);
}
static inline int8_t squot8(int8_t x, int8_t y)
{
    return x / y;
}
static inline int16_t squot16(int16_t x, int16_t y)
{
    return x / y;
}
static inline int32_t squot32(int32_t x, int32_t y)
{
    return x / y;
}
static inline int64_t squot64(int64_t x, int64_t y)
{
    return x / y;
}
static inline int8_t srem8(int8_t x, int8_t y)
{
    return x % y;
}
static inline int16_t srem16(int16_t x, int16_t y)
{
    return x % y;
}
static inline int32_t srem32(int32_t x, int32_t y)
{
    return x % y;
}
static inline int64_t srem64(int64_t x, int64_t y)
{
    return x % y;
}
static inline uint8_t shl8(uint8_t x, uint8_t y)
{
    return x << y;
}
static inline uint16_t shl16(uint16_t x, uint16_t y)
{
    return x << y;
}
static inline uint32_t shl32(uint32_t x, uint32_t y)
{
    return x << y;
}
static inline uint64_t shl64(uint64_t x, uint64_t y)
{
    return x << y;
}
static inline uint8_t lshr8(uint8_t x, uint8_t y)
{
    return x >> y;
}
static inline uint16_t lshr16(uint16_t x, uint16_t y)
{
    return x >> y;
}
static inline uint32_t lshr32(uint32_t x, uint32_t y)
{
    return x >> y;
}
static inline uint64_t lshr64(uint64_t x, uint64_t y)
{
    return x >> y;
}
static inline int8_t ashr8(int8_t x, int8_t y)
{
    return x >> y;
}
static inline int16_t ashr16(int16_t x, int16_t y)
{
    return x >> y;
}
static inline int32_t ashr32(int32_t x, int32_t y)
{
    return x >> y;
}
static inline int64_t ashr64(int64_t x, int64_t y)
{
    return x >> y;
}
static inline uint8_t and8(uint8_t x, uint8_t y)
{
    return x & y;
}
static inline uint16_t and16(uint16_t x, uint16_t y)
{
    return x & y;
}
static inline uint32_t and32(uint32_t x, uint32_t y)
{
    return x & y;
}
static inline uint64_t and64(uint64_t x, uint64_t y)
{
    return x & y;
}
static inline uint8_t or8(uint8_t x, uint8_t y)
{
    return x | y;
}
static inline uint16_t or16(uint16_t x, uint16_t y)
{
    return x | y;
}
static inline uint32_t or32(uint32_t x, uint32_t y)
{
    return x | y;
}
static inline uint64_t or64(uint64_t x, uint64_t y)
{
    return x | y;
}
static inline uint8_t xor8(uint8_t x, uint8_t y)
{
    return x ^ y;
}
static inline uint16_t xor16(uint16_t x, uint16_t y)
{
    return x ^ y;
}
static inline uint32_t xor32(uint32_t x, uint32_t y)
{
    return x ^ y;
}
static inline uint64_t xor64(uint64_t x, uint64_t y)
{
    return x ^ y;
}
static inline char ult8(uint8_t x, uint8_t y)
{
    return x < y;
}
static inline char ult16(uint16_t x, uint16_t y)
{
    return x < y;
}
static inline char ult32(uint32_t x, uint32_t y)
{
    return x < y;
}
static inline char ult64(uint64_t x, uint64_t y)
{
    return x < y;
}
static inline char ule8(uint8_t x, uint8_t y)
{
    return x <= y;
}
static inline char ule16(uint16_t x, uint16_t y)
{
    return x <= y;
}
static inline char ule32(uint32_t x, uint32_t y)
{
    return x <= y;
}
static inline char ule64(uint64_t x, uint64_t y)
{
    return x <= y;
}
static inline char slt8(int8_t x, int8_t y)
{
    return x < y;
}
static inline char slt16(int16_t x, int16_t y)
{
    return x < y;
}
static inline char slt32(int32_t x, int32_t y)
{
    return x < y;
}
static inline char slt64(int64_t x, int64_t y)
{
    return x < y;
}
static inline char sle8(int8_t x, int8_t y)
{
    return x <= y;
}
static inline char sle16(int16_t x, int16_t y)
{
    return x <= y;
}
static inline char sle32(int32_t x, int32_t y)
{
    return x <= y;
}
static inline char sle64(int64_t x, int64_t y)
{
    return x <= y;
}
static inline int8_t pow8(int8_t x, int8_t y)
{
    int8_t res = 1, rem = y;
    
    while (rem != 0) {
        if (rem & 1)
            res *= x;
        rem >>= 1;
        x *= x;
    }
    return res;
}
static inline int16_t pow16(int16_t x, int16_t y)
{
    int16_t res = 1, rem = y;
    
    while (rem != 0) {
        if (rem & 1)
            res *= x;
        rem >>= 1;
        x *= x;
    }
    return res;
}
static inline int32_t pow32(int32_t x, int32_t y)
{
    int32_t res = 1, rem = y;
    
    while (rem != 0) {
        if (rem & 1)
            res *= x;
        rem >>= 1;
        x *= x;
    }
    return res;
}
static inline int64_t pow64(int64_t x, int64_t y)
{
    int64_t res = 1, rem = y;
    
    while (rem != 0) {
        if (rem & 1)
            res *= x;
        rem >>= 1;
        x *= x;
    }
    return res;
}
static inline int8_t sext_i8_i8(int8_t x)
{
    return x;
}
static inline int16_t sext_i8_i16(int8_t x)
{
    return x;
}
static inline int32_t sext_i8_i32(int8_t x)
{
    return x;
}
static inline int64_t sext_i8_i64(int8_t x)
{
    return x;
}
static inline int8_t sext_i16_i8(int16_t x)
{
    return x;
}
static inline int16_t sext_i16_i16(int16_t x)
{
    return x;
}
static inline int32_t sext_i16_i32(int16_t x)
{
    return x;
}
static inline int64_t sext_i16_i64(int16_t x)
{
    return x;
}
static inline int8_t sext_i32_i8(int32_t x)
{
    return x;
}
static inline int16_t sext_i32_i16(int32_t x)
{
    return x;
}
static inline int32_t sext_i32_i32(int32_t x)
{
    return x;
}
static inline int64_t sext_i32_i64(int32_t x)
{
    return x;
}
static inline int8_t sext_i64_i8(int64_t x)
{
    return x;
}
static inline int16_t sext_i64_i16(int64_t x)
{
    return x;
}
static inline int32_t sext_i64_i32(int64_t x)
{
    return x;
}
static inline int64_t sext_i64_i64(int64_t x)
{
    return x;
}
static inline uint8_t zext_i8_i8(uint8_t x)
{
    return x;
}
static inline uint16_t zext_i8_i16(uint8_t x)
{
    return x;
}
static inline uint32_t zext_i8_i32(uint8_t x)
{
    return x;
}
static inline uint64_t zext_i8_i64(uint8_t x)
{
    return x;
}
static inline uint8_t zext_i16_i8(uint16_t x)
{
    return x;
}
static inline uint16_t zext_i16_i16(uint16_t x)
{
    return x;
}
static inline uint32_t zext_i16_i32(uint16_t x)
{
    return x;
}
static inline uint64_t zext_i16_i64(uint16_t x)
{
    return x;
}
static inline uint8_t zext_i32_i8(uint32_t x)
{
    return x;
}
static inline uint16_t zext_i32_i16(uint32_t x)
{
    return x;
}
static inline uint32_t zext_i32_i32(uint32_t x)
{
    return x;
}
static inline uint64_t zext_i32_i64(uint32_t x)
{
    return x;
}
static inline uint8_t zext_i64_i8(uint64_t x)
{
    return x;
}
static inline uint16_t zext_i64_i16(uint64_t x)
{
    return x;
}
static inline uint32_t zext_i64_i32(uint64_t x)
{
    return x;
}
static inline uint64_t zext_i64_i64(uint64_t x)
{
    return x;
}
static inline float fdiv32(float x, float y)
{
    return x / y;
}
static inline float fadd32(float x, float y)
{
    return x + y;
}
static inline float fsub32(float x, float y)
{
    return x - y;
}
static inline float fmul32(float x, float y)
{
    return x * y;
}
static inline float fpow32(float x, float y)
{
    return pow(x, y);
}
static inline char cmplt32(float x, float y)
{
    return x < y;
}
static inline char cmple32(float x, float y)
{
    return x <= y;
}
static inline float sitofp_i8_f32(int8_t x)
{
    return x;
}
static inline float sitofp_i16_f32(int16_t x)
{
    return x;
}
static inline float sitofp_i32_f32(int32_t x)
{
    return x;
}
static inline float sitofp_i64_f32(int64_t x)
{
    return x;
}
static inline float uitofp_i8_f32(uint8_t x)
{
    return x;
}
static inline float uitofp_i16_f32(uint16_t x)
{
    return x;
}
static inline float uitofp_i32_f32(uint32_t x)
{
    return x;
}
static inline float uitofp_i64_f32(uint64_t x)
{
    return x;
}
static inline int8_t fptosi_f32_i8(float x)
{
    return x;
}
static inline int16_t fptosi_f32_i16(float x)
{
    return x;
}
static inline int32_t fptosi_f32_i32(float x)
{
    return x;
}
static inline int64_t fptosi_f32_i64(float x)
{
    return x;
}
static inline uint8_t fptoui_f32_i8(float x)
{
    return x;
}
static inline uint16_t fptoui_f32_i16(float x)
{
    return x;
}
static inline uint32_t fptoui_f32_i32(float x)
{
    return x;
}
static inline uint64_t fptoui_f32_i64(float x)
{
    return x;
}
__kernel void map_kernel_936(int32_t width_740, float y_751, float res_747,
                             float view_743, __global unsigned char *mem_946,
                             __global unsigned char *mem_948)
{
    const uint kernel_thread_index_936 = get_global_id(0);
    
    if (kernel_thread_index_936 >= width_740)
        return;
    
    int32_t i_937;
    
    // compute thread index
    {
        i_937 = kernel_thread_index_936;
    }
    // read kernel parameters
    { }
    
    float x_939 = sitofp_i32_f32(i_937);
    float x_940 = x_939 * res_747;
    float y_941 = x_940 / y_751;
    float res_942 = view_743 + y_941;
    float x_943 = res_942 * res_942;
    
    // write kernel result
    {
        *(__global float *) &mem_946[i_937 * 4] = res_942;
        *(__global float *) &mem_948[i_937 * 4] = x_943;
    }
}
__kernel void map_kernel_887(int32_t width_740, float res_748, __global
                             unsigned char *mem_948, float view_744,
                             float y_752, __global unsigned char *mem_952,
                             char x_753, int32_t height_741,
                             int32_t nesting_size_885, __global
                             unsigned char *mem_946, __global
                             unsigned char *res_mem_954, int32_t limit_742,
                             __global unsigned char *mem_950, __global
                             unsigned char *mem_958)
{
    const uint kernel_thread_index_887 = get_global_id(0);
    
    if (kernel_thread_index_887 >= width_740 * height_741)
        return;
    
    int32_t i_888;
    int32_t i_889;
    float res_890;
    float x_891;
    
    // compute thread index
    {
        i_888 = squot32(kernel_thread_index_887, height_741);
        i_889 = kernel_thread_index_887 - squot32(kernel_thread_index_887,
                                                  height_741) * height_741;
    }
    // read kernel parameters
    {
        res_890 = *(__global float *) &mem_946[i_888 * 4];
        x_891 = *(__global float *) &mem_948[i_888 * 4];
    }
    
    float x_893 = sitofp_i32_f32(i_889);
    float x_894 = x_893 * res_748;
    float y_895 = x_894 / y_752;
    float res_896 = view_744 + y_895;
    float y_897 = res_896 * res_896;
    float res_898 = x_891 + y_897;
    char y_899 = res_898 < 4.0F;
    char loop_cond_900 = x_753 && y_899;
    char nameless_920;
    float c_921;
    float c_922;
    int32_t i_923;
    char loop_while_901;
    float c_902;
    float c_903;
    int32_t i_904;
    
    loop_while_901 = loop_cond_900;
    c_902 = res_890;
    c_903 = res_896;
    i_904 = 0;
    while (loop_while_901) {
        float x_905 = c_902 * c_902;
        float y_906 = c_903 * c_903;
        float res_907 = x_905 - y_906;
        float x_908 = c_902 * c_903;
        float y_909 = c_903 * c_902;
        float res_910 = x_908 + y_909;
        float res_911 = res_890 + res_907;
        float res_912 = res_896 + res_910;
        int32_t res_913 = i_904 + 1;
        char x_914 = slt32(res_913, limit_742);
        float x_915 = res_911 * res_911;
        float y_916 = res_912 * res_912;
        float res_917 = x_915 + y_916;
        char y_918 = res_917 < 4.0F;
        char loop_cond_919 = x_914 && y_918;
        char loop_while_tmp_973 = loop_cond_919;
        float c_tmp_974 = res_911;
        float c_tmp_975 = res_912;
        int32_t i_tmp_976;
        
        i_tmp_976 = res_913;
        loop_while_901 = loop_while_tmp_973;
        c_902 = c_tmp_974;
        c_903 = c_tmp_975;
        i_904 = i_tmp_976;
    }
    nameless_920 = loop_while_901;
    c_921 = c_902;
    c_922 = c_903;
    i_923 = i_904;
    
    char cond_924 = limit_742 == i_923;
    int32_t trunc_arg_925 = 3 * i_923;
    int8_t res_926 = sext_i32_i8(trunc_arg_925);
    int32_t trunc_arg_927 = 5 * i_923;
    int8_t res_928 = sext_i32_i8(trunc_arg_927);
    int32_t trunc_arg_929 = 7 * i_923;
    int8_t res_930 = sext_i32_i8(trunc_arg_929);
    
    if (cond_924) {
        *(__global int8_t *) &mem_950[kernel_thread_index_887] = 0;
        *(__global int8_t *) &mem_950[nesting_size_885 +
                                      kernel_thread_index_887] = 0;
        *(__global int8_t *) &mem_950[2 * nesting_size_885 +
                                      kernel_thread_index_887] = 0;
        for (int i_977 = 0; i_977 < 3; i_977++) {
            *(__global int8_t *) &res_mem_954[nesting_size_885 * i_977 +
                                              kernel_thread_index_887] =
                *(__global int8_t *) &mem_950[nesting_size_885 * i_977 +
                                              kernel_thread_index_887];
        }
    } else {
        *(__global int8_t *) &mem_952[kernel_thread_index_887] = res_926;
        *(__global int8_t *) &mem_952[nesting_size_885 +
                                      kernel_thread_index_887] = res_928;
        *(__global int8_t *) &mem_952[2 * nesting_size_885 +
                                      kernel_thread_index_887] = res_930;
        for (int i_978 = 0; i_978 < 3; i_978++) {
            *(__global int8_t *) &res_mem_954[nesting_size_885 * i_978 +
                                              kernel_thread_index_887] =
                *(__global int8_t *) &mem_952[nesting_size_885 * i_978 +
                                              kernel_thread_index_887];
        }
    }
    // write kernel result
    {
        for (int i_979 = 0; i_979 < 3; i_979++) {
            *(__global int8_t *) &mem_958[3 * (height_741 * i_888) +
                                          (height_741 * i_979 + i_889)] =
                *(__global int8_t *) &res_mem_954[nesting_size_885 * i_979 +
                                                  kernel_thread_index_887];
        }
    }
}
__kernel void fut_kernel_map_transpose_i8(__global int8_t *odata,
                                          uint odata_offset, __global
                                          int8_t *idata, uint idata_offset,
                                          uint width, uint height, __local
                                          int8_t *block)
{
    uint x_index;
    uint y_index;
    uint our_array_offset;
    
    // Adjust the input and output arrays with the basic offset.
    odata += odata_offset / sizeof(int8_t);
    idata += idata_offset / sizeof(int8_t);
    // Adjust the input and output arrays for the third dimension.
    our_array_offset = get_global_id(2) * width * height;
    odata += our_array_offset;
    idata += our_array_offset;
    // read the matrix tile into shared memory
    x_index = get_global_id(0);
    y_index = get_global_id(1);
    if (x_index < width && y_index < height) {
        uint index_in = y_index * width + x_index;
        
        block[get_local_id(1) * (FUT_BLOCK_DIM + 1) + get_local_id(0)] =
            idata[index_in];
    }
    barrier(CLK_LOCAL_MEM_FENCE);
    // Write the transposed matrix tile to global memory.
    x_index = get_group_id(1) * FUT_BLOCK_DIM + get_local_id(0);
    y_index = get_group_id(0) * FUT_BLOCK_DIM + get_local_id(1);
    if (x_index < height && y_index < width) {
        uint index_out = y_index * height + x_index;
        
        odata[index_out] = block[get_local_id(0) * (FUT_BLOCK_DIM + 1) +
                                 get_local_id(1)];
    }
}
"""
# Hacky parser/reader for values written in Futhark syntax.  Used for
# reading stdin when compiling standalone programs with the Python
# code generator.

lookahead_buffer = []

def reset_lookahead():
    global lookahead_buffer
    lookahead_buffer = []

def get_char(f):
    global lookahead_buffer
    if len(lookahead_buffer) == 0:
        return f.read(1)
    else:
        c = lookahead_buffer[0]
        lookahead_buffer = lookahead_buffer[1:]
        return c

def unget_char(f, c):
    global lookahead_buffer
    lookahead_buffer = [c] + lookahead_buffer

def peek_char(f):
    c = get_char(f)
    if c:
        unget_char(f, c)
    return c

def skip_spaces(f):
    c = get_char(f)
    while c != None:
        if c.isspace():
            c = get_char(f)
        elif c == '-':
          # May be line comment.
          if peek_char(f) == '-':
            # Yes, line comment. Skip to end of line.
            while (c != '\n' and c != None):
              c = get_char(f)
          else:
            break
        else:
          break
    if c:
        unget_char(f, c)

def parse_specific_char(f, expected):
    got = get_char(f)
    if got != expected:
        unget_char(f, got)
        raise ValueError
    return True

def parse_specific_string(f, s):
    for c in s:
        parse_specific_char(f, c)
    return True

def optional(p, *args):
    try:
        return p(*args)
    except ValueError:
        return None

def sepBy(p, sep, *args):
    elems = []
    x = optional(p, *args)
    if x != None:
        elems += [x]
        while optional(sep, *args) != None:
            x = p(*args)
            elems += [x]
    return elems

def parse_int(f):
    s = ''
    c = get_char(f)
    while c != None:
        if c.isdigit():
            s += c
            c = get_char(f)
        else:
            unget_char(f, c)
            break
    optional(read_int_trailer, f)
    return s

def parse_int_signed(f):
    s = ''
    c = get_char(f)

    if c == '-' and peek_char(f).isdigit():
      s = c + parse_int(f)
    else:
      unget_char(f, c)
      s = parse_int(f)

    return s

def read_int_trailer(f):
  parse_specific_char(f, 'i')
  while peek_char(f).isdigit():
    get_char(f)

def read_comma(f):
    skip_spaces(f)
    parse_specific_char(f, ',')
    return ','

def read_int(f):
    skip_spaces(f)
    return int(parse_int_signed(f))

def read_char(f):
    skip_spaces(f)
    parse_specific_char(f, '\'')
    c = get_char(f)
    parse_specific_char(f, '\'')
    return c

def read_double(f):
    skip_spaces(f)
    c = get_char(f)
    if (c == '-'):
      sign = '-'
    else:
      unget_char(f,c)
      sign = ''
    bef = optional(parse_int, f)
    if bef == None:
        bef = '0'
        parse_specific_char(f, '.')
        aft = parse_int(f)
    elif optional(parse_specific_char, f, '.'):
        aft = parse_int(f)
    else:
        aft = '0'
    if (optional(parse_specific_char, f, 'E') or
        optional(parse_specific_char, f, 'e')):
        expt = parse_int_signed(f)
    else:
        expt = '0'
    optional(read_float_trailer, f)
    return float(sign + bef + '.' + aft + 'E' + expt)

def read_float(f):
    return read_double(f)

def read_float_trailer(f):
  parse_specific_char(f, 'f')
  while peek_char(f).isdigit():
    get_char(f)

def read_bool(f):
    skip_spaces(f)
    if peek_char(f) == 'T':
        parse_specific_string(f, 'True')
        return True
    elif peek_char(f) == 'F':
        parse_specific_string(f, 'False')
        return False
    else:
        raise ValueError

def read_array_elems(f, elem_reader):
    skip_spaces(f)
    parse_specific_char(f, '[')
    xs = sepBy(elem_reader, read_comma, f)
    skip_spaces(f)
    parse_specific_char(f, ']')
    return xs

def read_array_helper(f, elem_reader, rank):
    def nested_row_reader(_):
        return read_array_helper(f, elem_reader, rank-1)
    if rank == 1:
        row_reader = elem_reader
    else:
        row_reader = nested_row_reader
    return read_array_elems(f, row_reader)

def expected_array_dims(l, rank):
  if rank > 1:
      n = len(l)
      if n == 0:
          elem = []
      else:
          elem = l[0]
      return [n] + expected_array_dims(elem, rank-1)
  else:
      return [len(l)]

def verify_array_dims(l, dims):
    if dims[0] != len(l):
        raise ValueError
    if len(dims) > 1:
        for x in l:
            verify_array_dims(x, dims[1:])

def read_double_signed(f):

    skip_spaces(f)
    c = get_char(f)

    if c == '-' and peek_char(f).isdigit():
      v = -1 * read_double(f)
    else:
      unget_char(f, c)
      v = read_double(f)

    return v

def read_array(f, elem_reader, rank, bt):
    elems = read_array_helper(f, elem_reader, rank)
    dims = expected_array_dims(elems, rank)
    verify_array_dims(elems, dims)
    return np.array(elems, dtype=bt)
# Scalar functions.

import numpy as np

def signed(x):
  if type(x) == np.uint8:
    return np.int8(x)
  elif type(x) == np.uint16:
    return np.int16(x)
  elif type(x) == np.uint32:
    return np.int32(x)
  else:
    return np.int64(x)

def unsigned(x):
  if type(x) == np.int8:
    return np.uint8(x)
  elif type(x) == np.int16:
    return np.uint16(x)
  elif type(x) == np.int32:
    return np.uint32(x)
  else:
    return np.uint64(x)

def shlN(x,y):
  return x << y

def ashrN(x,y):
  return x >> y

def sdivN(x,y):
  return x / y

def smodN(x,y):
  return x % y

def udivN(x,y):
  return signed(unsigned(x) / unsigned(y))

def umodN(x,y):
  return signed(unsigned(x) % unsigned(y))

def squotN(x,y):
  return np.int32(float(x) / float(y))

def sremN(x,y):
  return np.fmod(x,y)

def powN(x,y):
  return x ** y

def fpowN(x,y):
  return x ** y

def sleN(x,y):
  return x <= y

def sltN(x,y):
  return x < y

def uleN(x,y):
  return unsigned(x) <= unsigned(y)

def ultN(x,y):
  return unsigned(x) < unsigned(y)

def lshr8(x,y):
  return np.int8(np.uint8(x) >> np.uint8(y))

def lshr16(x,y):
  return np.int16(np.uint16(x) >> np.uint16(y))

def lshr32(x,y):
  return np.int32(np.uint32(x) >> np.uint32(y))

def lshr64(x,y):
  return np.int64(np.uint64(x) >> np.uint64(y))

def sext_T_i8(x):
  return np.int8(x)

def sext_T_i16(x):
  return np.int16(x)

def sext_T_i32(x):
  return np.int32(x)

def sext_T_i64(x):
  return np.int32(x)

def zext_i8_i8(x):
  return np.int8(np.uint8(x))

def zext_i8_i16(x):
  return np.int16(np.uint8(x))

def zext_i8_i32(x):
  return np.int32(np.uint8(x))

def zext_i8_i64(x):
  return np.int64(np.uint8(x))

def zext_i16_i8(x):
  return np.int8(np.uint16(x))

def zext_i16_i16(x):
  return np.int16(np.uint16(x))

def zext_i16_i32(x):
  return np.int32(np.uint16(x))

def zext_i16_i64(x):
  return np.int64(np.uint16(x))

def zext_i32_i8(x):
  return np.int8(np.uint32(x))

def zext_i32_i16(x):
  return np.int16(np.uint32(x))

def zext_i32_i32(x):
  return np.int32(np.uint32(x))

def zext_i32_i64(x):
  return np.int64(np.uint32(x))

def zext_i64_i8(x):
  return np.int8(np.uint64(x))

def zext_i64_i16(x):
  return np.int16(np.uint64(x))

def zext_i64_i32(x):
  return np.int32(np.uint64(x))

def zext_i64_i64(x):
  return np.int64(np.uint64(x))

shl8 = shl16 = shl32 = shl64 = shlN
ashr8 = ashr16 = ashr32 = ashr64 = ashrN
sdiv8 = sdiv16 = sdiv32 = sdiv64 = sdivN
smod8 = smod16 = smod32 = smod64 = smodN
udiv8 = udiv16 = udiv32 = udiv64 = udivN
umod8 = umod16 = umod32 = umod64 = umodN
squot8 = squot16 = squot32 = squot64 = squotN
srem8 = srem16 = srem32 = srem64 = sremN
pow8 = pow16 = pow32 = pow64 = powN
fpow32 = fpow64 = fpowN
sle8 = sle16 = sle32 = sle64 = sleN
slt8 = slt16 = slt32 = slt64 = sltN
ule8 = ule16 = ule32 = ule64 = uleN
ult8 = ult16 = ult32 = ult64 = ultN
sext_i8_i8 = sext_i16_i8 = sext_i32_i8 = sext_i64_i8 = sext_T_i8
sext_i8_i16 = sext_i16_i16 = sext_i32_i16 = sext_i64_i16 = sext_T_i16
sext_i8_i32 = sext_i16_i32 = sext_i32_i32 = sext_i64_i32 = sext_T_i32
sext_i8_i64 = sext_i16_i64 = sext_i32_i64 = sext_i64_i64 = sext_T_i64

def ssignum(x):
  return np.sign(x)

def usignum(x):
  if x < 0:
    return ssignum(-x)
  else:
    return ssignum(x)

def sitofp_T_f32(x):
  return np.float32(x)
sitofp_i8_f32 = sitofp_i16_f32 = sitofp_i32_f32 = sitofp_i64_f32 = sitofp_T_f32

def sitofp_T_f64(x):
  return np.float64(x)
sitofp_i8_f64 = sitofp_i16_f64 = sitofp_i32_f64 = sitofp_i64_f64 = sitofp_T_f64

def uitofp_T_f32(x):
  return np.float32(unsigned(x))
uitofp_i8_f32 = uitofp_i16_f32 = uitofp_i32_f32 = uitofp_i64_f32 = uitofp_T_f32

def uitofp_T_f64(x):
  return np.float64(unsigned(x))
uitofp_i8_f64 = uitofp_i16_f64 = uitofp_i32_f64 = uitofp_i64_f64 = uitofp_T_f64

def fptosi_T_i8(x):
  return np.int8(np.trunc(x))
fptosi_f32_i8 = fptosi_f64_i8 = fptosi_T_i8

def fptosi_T_i16(x):
  return np.int16(np.trunc(x))
fptosi_f32_i16 = fptosi_f64_i16 = fptosi_T_i16

def fptosi_T_i32(x):
  return np.int32(np.trunc(x))
fptosi_f32_i32 = fptosi_f64_i32 = fptosi_T_i32

def fptosi_T_i64(x):
  return np.int64(np.trunc(x))
fptosi_f32_i64 = fptosi_f64_i64 = fptosi_T_i64

def fptoui_T_i8(x):
  return np.uint8(np.trunc(x))
fptoui_f32_i8 = fptoui_f64_i8 = fptoui_T_i8

def fptoui_T_i16(x):
  return np.uint16(np.trunc(x))
fptoui_f32_i16 = fptoui_f64_i16 = fptoui_T_i16

def fptoui_T_i32(x):
  return np.uint32(np.trunc(x))
fptoui_f32_i32 = fptoui_f64_i32 = fptoui_T_i32

def fptoui_T_i64(x):
  return np.uint64(np.trunc(x))
fptoui_f32_i64 = fptoui_f64_i64 = fptoui_T_i64

def fpconv_f32_f64(x):
  return np.float64(x)

def fpconv_f64_f32(x):
  return np.float32(x)

def futhark_log64(x):
  return np.float64(np.log(x))

def futhark_sqrt64(x):
  return np.sqrt(x)

def futhark_exp64(x):
  return np.exp(x)

def futhark_cos64(x):
  return np.cos(x)

def futhark_sin64(x):
  return np.sin(x)

def futhark_atan2_64(x, y):
  return np.arctan2(x, y)

def futhark_isnan64(x):
  return np.isnan(x)

def futhark_isinf64(x):
  return np.isinf(x)

def futhark_log32(x):
  return np.float32(np.log(x))

def futhark_sqrt32(x):
  return np.float32(np.sqrt(x))

def futhark_exp32(x):
  return np.exp(x)

def futhark_cos32(x):
  return np.cos(x)

def futhark_sin32(x):
  return np.sin(x)

def futhark_atan2_32(x, y):
  return np.arctan2(x, y)

def futhark_isnan32(x):
  return np.isnan(x)

def futhark_isinf32(x):
  return np.isinf(x)
class mandelbrot:
  def __init__(self):
    self.ctx = cl.create_some_context(interactive=False)
    self.queue = cl.CommandQueue(self.ctx)
     # XXX: Assuming just a single device here.
    platform_name = self.ctx.get_info(cl.context_info.DEVICES)[0].platform.name
    device_type = self.ctx.get_info(cl.context_info.DEVICES)[0].type
    lockstep_width = 1
    if ((platform_name == "NVIDIA CUDA") and (device_type == cl.device_type.GPU)):
      lockstep_width = np.int32(32)
    if ((platform_name == "AMD Accelerated Parallel Processing") and (device_type == cl.device_type.GPU)):
      lockstep_width = np.int32(64)
    if (len(fut_opencl_src) >= 0):
      program = cl.Program(self.ctx, fut_opencl_src).build(["-DFUT_BLOCK_DIM={}".format(FUT_BLOCK_DIM), "-DLOCKSTEP_WIDTH={}".format(lockstep_width)])
    
    self.map_kernel_936_var = program.map_kernel_936
    self.map_kernel_887_var = program.map_kernel_887
    self.fut_kernel_map_transpose_i8_var = program.fut_kernel_map_transpose_i8
  def futhark_main(self, width_740, height_741, limit_742, view_743, view_744,
                   view_745, view_746):
    res_747 = (view_745 - view_743)
    res_748 = (view_746 - view_744)
    y_751 = sitofp_i32_f32(width_740)
    y_752 = sitofp_i32_f32(height_741)
    x_753 = slt32(np.int32(0), limit_742)
    bytes_945 = (np.int32(4) * width_740)
    mem_946 = cl.Buffer(self.ctx, cl.mem_flags.READ_WRITE,
                        long(long(bytes_945) if (bytes_945 > np.int32(0)) else np.int32(1)))
    mem_948 = cl.Buffer(self.ctx, cl.mem_flags.READ_WRITE,
                        long(long(bytes_945) if (bytes_945 > np.int32(0)) else np.int32(1)))
    group_size_971 = np.int32(512)
    num_groups_972 = squot32(((width_740 + group_size_971) - np.int32(1)),
                             group_size_971)
    if ((np.int32(1) * (num_groups_972 * group_size_971)) != np.int32(0)):
      self.map_kernel_936_var.set_args(np.int32(width_740), np.float32(y_751),
                                       np.float32(res_747),
                                       np.float32(view_743), mem_946, mem_948)
      cl.enqueue_nd_range_kernel(self.queue, self.map_kernel_936_var,
                                 (long((num_groups_972 * group_size_971)),),
                                 (long(group_size_971),))
      if synchronous:
        self.queue.finish()
    nesting_size_885 = (height_741 * width_740)
    x_957 = (width_740 * np.int32(3))
    bytes_955 = (x_957 * height_741)
    mem_958 = cl.Buffer(self.ctx, cl.mem_flags.READ_WRITE,
                        long(long(bytes_955) if (bytes_955 > np.int32(0)) else np.int32(1)))
    total_size_966 = (nesting_size_885 * np.int32(3))
    mem_952 = cl.Buffer(self.ctx, cl.mem_flags.READ_WRITE,
                        long(long(total_size_966) if (total_size_966 > np.int32(0)) else np.int32(1)))
    total_size_967 = (nesting_size_885 * np.int32(3))
    res_mem_954 = cl.Buffer(self.ctx, cl.mem_flags.READ_WRITE,
                            long(long(total_size_967) if (total_size_967 > np.int32(0)) else np.int32(1)))
    total_size_968 = (nesting_size_885 * np.int32(3))
    mem_950 = cl.Buffer(self.ctx, cl.mem_flags.READ_WRITE,
                        long(long(total_size_968) if (total_size_968 > np.int32(0)) else np.int32(1)))
    group_size_980 = np.int32(512)
    num_groups_981 = squot32((((width_740 * height_741) + group_size_980) - np.int32(1)),
                             group_size_980)
    if ((np.int32(1) * (num_groups_981 * group_size_980)) != np.int32(0)):
      self.map_kernel_887_var.set_args(np.int32(width_740), np.float32(res_748),
                                       mem_948, np.float32(view_744),
                                       np.float32(y_752), mem_952,
                                       np.byte(x_753), np.int32(height_741),
                                       np.int32(nesting_size_885), mem_946,
                                       res_mem_954, np.int32(limit_742),
                                       mem_950, mem_958)
      cl.enqueue_nd_range_kernel(self.queue, self.map_kernel_887_var,
                                 (long((num_groups_981 * group_size_980)),),
                                 (long(group_size_980),))
      if synchronous:
        self.queue.finish()
    x_961 = (width_740 * height_741)
    bytes_959 = (x_961 * np.int32(3))
    mem_962 = cl.Buffer(self.ctx, cl.mem_flags.READ_WRITE,
                        long(long(bytes_959) if (bytes_959 > np.int32(0)) else np.int32(1)))
    if ((((np.int32(1) * (height_741 + srem32((np.int32(16) - srem32(height_741,
                                                                     np.int32(16))),
                                              np.int32(16)))) * (np.int32(3) + srem32((np.int32(16) - srem32(np.int32(3),
                                                                                                             np.int32(16))),
                                                                                      np.int32(16)))) * width_740) != np.int32(0)):
      self.fut_kernel_map_transpose_i8_var.set_args(mem_962,
                                                    np.int32(np.int32(0)),
                                                    mem_958,
                                                    np.int32(np.int32(0)),
                                                    np.int32(height_741),
                                                    np.int32(np.int32(3)),
                                                    cl.LocalMemory(long((((np.int32(16) + np.int32(1)) * np.int32(16)) * np.int32(1)))))
      cl.enqueue_nd_range_kernel(self.queue,
                                 self.fut_kernel_map_transpose_i8_var,
                                 (long((height_741 + srem32((np.int32(16) - srem32(height_741,
                                                                                   np.int32(16))),
                                                            np.int32(16)))),
                                  long((np.int32(3) + srem32((np.int32(16) - srem32(np.int32(3),
                                                                                    np.int32(16))),
                                                             np.int32(16)))),
                                  long(width_740)), (long(np.int32(16)),
                                                     long(np.int32(16)),
                                                     long(np.int32(1))))
      if synchronous:
        self.queue.finish()
    out_mem_969 = mem_962
    out_memsize_970 = bytes_959
    return (out_memsize_970, out_mem_969)
  def main(self, width_740_ext, height_741_ext, limit_742_ext, view_743_ext,
           view_744_ext, view_745_ext, view_746_ext):
    width_740 = np.int32(width_740_ext)
    height_741 = np.int32(height_741_ext)
    limit_742 = np.int32(limit_742_ext)
    view_743 = np.float32(view_743_ext)
    view_744 = np.float32(view_744_ext)
    view_745 = np.float32(view_745_ext)
    view_746 = np.float32(view_746_ext)
    (out_memsize_970, out_mem_969) = self.futhark_main(width_740, height_741,
                                                       limit_742, view_743,
                                                       view_744, view_745,
                                                       view_746)
    out_mem_device_982 = np.empty((width_740, height_741, np.int32(3)),
                                  dtype=ct.c_int8)
    if (out_memsize_970 != np.int32(0)):
      cl.enqueue_copy(self.queue,
                      out_mem_device_982[np.int32(0):(np.int32(0) + (out_memsize_970 // 1))],
                      out_mem_969, device_offset=long(np.int32(0)),
                      is_blocking=synchronous)
    out_mem_969 = out_mem_device_982
    return out_mem_969