import sys
import numpy as np
import ctypes as ct
import pyopencl as cl
import time
import argparse
FUT_BLOCK_DIM = "16"
cl_group_size = np.int32(512)
synchronous = False
fut_opencl_src = """typedef char int8_t;
typedef short int16_t;
typedef int int32_t;
typedef long int64_t;
typedef uchar uint8_t;
typedef ushort uint16_t;
typedef uint uint32_t;
typedef ulong uint64_t;
static inline int8_t add8(int8_t x, int8_t y)
{
    return x + y;
}
static inline int16_t add16(int16_t x, int16_t y)
{
    return x + y;
}
static inline int32_t add32(int32_t x, int32_t y)
{
    return x + y;
}
static inline int64_t add64(int64_t x, int64_t y)
{
    return x + y;
}
static inline int8_t sub8(int8_t x, int8_t y)
{
    return x - y;
}
static inline int16_t sub16(int16_t x, int16_t y)
{
    return x - y;
}
static inline int32_t sub32(int32_t x, int32_t y)
{
    return x - y;
}
static inline int64_t sub64(int64_t x, int64_t y)
{
    return x - y;
}
static inline int8_t mul8(int8_t x, int8_t y)
{
    return x * y;
}
static inline int16_t mul16(int16_t x, int16_t y)
{
    return x * y;
}
static inline int32_t mul32(int32_t x, int32_t y)
{
    return x * y;
}
static inline int64_t mul64(int64_t x, int64_t y)
{
    return x * y;
}
static inline uint8_t udiv8(uint8_t x, uint8_t y)
{
    return x / y;
}
static inline uint16_t udiv16(uint16_t x, uint16_t y)
{
    return x / y;
}
static inline uint32_t udiv32(uint32_t x, uint32_t y)
{
    return x / y;
}
static inline uint64_t udiv64(uint64_t x, uint64_t y)
{
    return x / y;
}
static inline uint8_t umod8(uint8_t x, uint8_t y)
{
    return x % y;
}
static inline uint16_t umod16(uint16_t x, uint16_t y)
{
    return x % y;
}
static inline uint32_t umod32(uint32_t x, uint32_t y)
{
    return x % y;
}
static inline uint64_t umod64(uint64_t x, uint64_t y)
{
    return x % y;
}
static inline int8_t sdiv8(int8_t x, int8_t y)
{
    int8_t q = x / y;
    int8_t r = x % y;
    
    return q - ((r != 0 && r < 0 != y < 0) ? 1 : 0);
}
static inline int16_t sdiv16(int16_t x, int16_t y)
{
    int16_t q = x / y;
    int16_t r = x % y;
    
    return q - ((r != 0 && r < 0 != y < 0) ? 1 : 0);
}
static inline int32_t sdiv32(int32_t x, int32_t y)
{
    int32_t q = x / y;
    int32_t r = x % y;
    
    return q - ((r != 0 && r < 0 != y < 0) ? 1 : 0);
}
static inline int64_t sdiv64(int64_t x, int64_t y)
{
    int64_t q = x / y;
    int64_t r = x % y;
    
    return q - ((r != 0 && r < 0 != y < 0) ? 1 : 0);
}
static inline int8_t smod8(int8_t x, int8_t y)
{
    int8_t r = x % y;
    
    return r + (r == 0 || (x > 0 && y > 0) || (x < 0 && y < 0) ? 0 : y);
}
static inline int16_t smod16(int16_t x, int16_t y)
{
    int16_t r = x % y;
    
    return r + (r == 0 || (x > 0 && y > 0) || (x < 0 && y < 0) ? 0 : y);
}
static inline int32_t smod32(int32_t x, int32_t y)
{
    int32_t r = x % y;
    
    return r + (r == 0 || (x > 0 && y > 0) || (x < 0 && y < 0) ? 0 : y);
}
static inline int64_t smod64(int64_t x, int64_t y)
{
    int64_t r = x % y;
    
    return r + (r == 0 || (x > 0 && y > 0) || (x < 0 && y < 0) ? 0 : y);
}
static inline int8_t squot8(int8_t x, int8_t y)
{
    return x / y;
}
static inline int16_t squot16(int16_t x, int16_t y)
{
    return x / y;
}
static inline int32_t squot32(int32_t x, int32_t y)
{
    return x / y;
}
static inline int64_t squot64(int64_t x, int64_t y)
{
    return x / y;
}
static inline int8_t srem8(int8_t x, int8_t y)
{
    return x % y;
}
static inline int16_t srem16(int16_t x, int16_t y)
{
    return x % y;
}
static inline int32_t srem32(int32_t x, int32_t y)
{
    return x % y;
}
static inline int64_t srem64(int64_t x, int64_t y)
{
    return x % y;
}
static inline uint8_t shl8(uint8_t x, uint8_t y)
{
    return x << y;
}
static inline uint16_t shl16(uint16_t x, uint16_t y)
{
    return x << y;
}
static inline uint32_t shl32(uint32_t x, uint32_t y)
{
    return x << y;
}
static inline uint64_t shl64(uint64_t x, uint64_t y)
{
    return x << y;
}
static inline uint8_t lshr8(uint8_t x, uint8_t y)
{
    return x >> y;
}
static inline uint16_t lshr16(uint16_t x, uint16_t y)
{
    return x >> y;
}
static inline uint32_t lshr32(uint32_t x, uint32_t y)
{
    return x >> y;
}
static inline uint64_t lshr64(uint64_t x, uint64_t y)
{
    return x >> y;
}
static inline int8_t ashr8(int8_t x, int8_t y)
{
    return x >> y;
}
static inline int16_t ashr16(int16_t x, int16_t y)
{
    return x >> y;
}
static inline int32_t ashr32(int32_t x, int32_t y)
{
    return x >> y;
}
static inline int64_t ashr64(int64_t x, int64_t y)
{
    return x >> y;
}
static inline uint8_t and8(uint8_t x, uint8_t y)
{
    return x & y;
}
static inline uint16_t and16(uint16_t x, uint16_t y)
{
    return x & y;
}
static inline uint32_t and32(uint32_t x, uint32_t y)
{
    return x & y;
}
static inline uint64_t and64(uint64_t x, uint64_t y)
{
    return x & y;
}
static inline uint8_t or8(uint8_t x, uint8_t y)
{
    return x | y;
}
static inline uint16_t or16(uint16_t x, uint16_t y)
{
    return x | y;
}
static inline uint32_t or32(uint32_t x, uint32_t y)
{
    return x | y;
}
static inline uint64_t or64(uint64_t x, uint64_t y)
{
    return x | y;
}
static inline uint8_t xor8(uint8_t x, uint8_t y)
{
    return x ^ y;
}
static inline uint16_t xor16(uint16_t x, uint16_t y)
{
    return x ^ y;
}
static inline uint32_t xor32(uint32_t x, uint32_t y)
{
    return x ^ y;
}
static inline uint64_t xor64(uint64_t x, uint64_t y)
{
    return x ^ y;
}
static inline char ult8(uint8_t x, uint8_t y)
{
    return x < y;
}
static inline char ult16(uint16_t x, uint16_t y)
{
    return x < y;
}
static inline char ult32(uint32_t x, uint32_t y)
{
    return x < y;
}
static inline char ult64(uint64_t x, uint64_t y)
{
    return x < y;
}
static inline char ule8(uint8_t x, uint8_t y)
{
    return x <= y;
}
static inline char ule16(uint16_t x, uint16_t y)
{
    return x <= y;
}
static inline char ule32(uint32_t x, uint32_t y)
{
    return x <= y;
}
static inline char ule64(uint64_t x, uint64_t y)
{
    return x <= y;
}
static inline char slt8(int8_t x, int8_t y)
{
    return x < y;
}
static inline char slt16(int16_t x, int16_t y)
{
    return x < y;
}
static inline char slt32(int32_t x, int32_t y)
{
    return x < y;
}
static inline char slt64(int64_t x, int64_t y)
{
    return x < y;
}
static inline char sle8(int8_t x, int8_t y)
{
    return x <= y;
}
static inline char sle16(int16_t x, int16_t y)
{
    return x <= y;
}
static inline char sle32(int32_t x, int32_t y)
{
    return x <= y;
}
static inline char sle64(int64_t x, int64_t y)
{
    return x <= y;
}
static inline int8_t pow8(int8_t x, int8_t y)
{
    int8_t res = 1, rem = y;
    
    while (rem != 0) {
        if (rem & 1)
            res *= x;
        rem >>= 1;
        x *= x;
    }
    return res;
}
static inline int16_t pow16(int16_t x, int16_t y)
{
    int16_t res = 1, rem = y;
    
    while (rem != 0) {
        if (rem & 1)
            res *= x;
        rem >>= 1;
        x *= x;
    }
    return res;
}
static inline int32_t pow32(int32_t x, int32_t y)
{
    int32_t res = 1, rem = y;
    
    while (rem != 0) {
        if (rem & 1)
            res *= x;
        rem >>= 1;
        x *= x;
    }
    return res;
}
static inline int64_t pow64(int64_t x, int64_t y)
{
    int64_t res = 1, rem = y;
    
    while (rem != 0) {
        if (rem & 1)
            res *= x;
        rem >>= 1;
        x *= x;
    }
    return res;
}
static inline int8_t sext_i8_i8(int8_t x)
{
    return x;
}
static inline int16_t sext_i8_i16(int8_t x)
{
    return x;
}
static inline int32_t sext_i8_i32(int8_t x)
{
    return x;
}
static inline int64_t sext_i8_i64(int8_t x)
{
    return x;
}
static inline int8_t sext_i16_i8(int16_t x)
{
    return x;
}
static inline int16_t sext_i16_i16(int16_t x)
{
    return x;
}
static inline int32_t sext_i16_i32(int16_t x)
{
    return x;
}
static inline int64_t sext_i16_i64(int16_t x)
{
    return x;
}
static inline int8_t sext_i32_i8(int32_t x)
{
    return x;
}
static inline int16_t sext_i32_i16(int32_t x)
{
    return x;
}
static inline int32_t sext_i32_i32(int32_t x)
{
    return x;
}
static inline int64_t sext_i32_i64(int32_t x)
{
    return x;
}
static inline int8_t sext_i64_i8(int64_t x)
{
    return x;
}
static inline int16_t sext_i64_i16(int64_t x)
{
    return x;
}
static inline int32_t sext_i64_i32(int64_t x)
{
    return x;
}
static inline int64_t sext_i64_i64(int64_t x)
{
    return x;
}
static inline uint8_t zext_i8_i8(uint8_t x)
{
    return x;
}
static inline uint16_t zext_i8_i16(uint8_t x)
{
    return x;
}
static inline uint32_t zext_i8_i32(uint8_t x)
{
    return x;
}
static inline uint64_t zext_i8_i64(uint8_t x)
{
    return x;
}
static inline uint8_t zext_i16_i8(uint16_t x)
{
    return x;
}
static inline uint16_t zext_i16_i16(uint16_t x)
{
    return x;
}
static inline uint32_t zext_i16_i32(uint16_t x)
{
    return x;
}
static inline uint64_t zext_i16_i64(uint16_t x)
{
    return x;
}
static inline uint8_t zext_i32_i8(uint32_t x)
{
    return x;
}
static inline uint16_t zext_i32_i16(uint32_t x)
{
    return x;
}
static inline uint32_t zext_i32_i32(uint32_t x)
{
    return x;
}
static inline uint64_t zext_i32_i64(uint32_t x)
{
    return x;
}
static inline uint8_t zext_i64_i8(uint64_t x)
{
    return x;
}
static inline uint16_t zext_i64_i16(uint64_t x)
{
    return x;
}
static inline uint32_t zext_i64_i32(uint64_t x)
{
    return x;
}
static inline uint64_t zext_i64_i64(uint64_t x)
{
    return x;
}
static inline float fdiv32(float x, float y)
{
    return x / y;
}
static inline float fadd32(float x, float y)
{
    return x + y;
}
static inline float fsub32(float x, float y)
{
    return x - y;
}
static inline float fmul32(float x, float y)
{
    return x * y;
}
static inline float fpow32(float x, float y)
{
    return pow(x, y);
}
static inline char cmplt32(float x, float y)
{
    return x < y;
}
static inline char cmple32(float x, float y)
{
    return x <= y;
}
static inline float sitofp_i8_f32(int8_t x)
{
    return x;
}
static inline float sitofp_i16_f32(int16_t x)
{
    return x;
}
static inline float sitofp_i32_f32(int32_t x)
{
    return x;
}
static inline float sitofp_i64_f32(int64_t x)
{
    return x;
}
static inline float uitofp_i8_f32(uint8_t x)
{
    return x;
}
static inline float uitofp_i16_f32(uint16_t x)
{
    return x;
}
static inline float uitofp_i32_f32(uint32_t x)
{
    return x;
}
static inline float uitofp_i64_f32(uint64_t x)
{
    return x;
}
static inline int8_t fptosi_f32_i8(float x)
{
    return x;
}
static inline int16_t fptosi_f32_i16(float x)
{
    return x;
}
static inline int32_t fptosi_f32_i32(float x)
{
    return x;
}
static inline int64_t fptosi_f32_i64(float x)
{
    return x;
}
static inline uint8_t fptoui_f32_i8(float x)
{
    return x;
}
static inline uint16_t fptoui_f32_i16(float x)
{
    return x;
}
static inline uint32_t fptoui_f32_i32(float x)
{
    return x;
}
static inline uint64_t fptoui_f32_i64(float x)
{
    return x;
}
__kernel void map_kernel_1056(int32_t m_916, __global
                              unsigned char *world_mem_1141, int32_t n_915,
                              __global unsigned char *mem_1144)
{
    const uint kernel_thread_index_1056 = get_global_id(0);
    
    if (kernel_thread_index_1056 >= n_915 * m_916)
        return;
    
    int32_t i_1057;
    int32_t i_1058;
    char b_1059;
    
    // compute thread index
    {
        i_1057 = squot32(kernel_thread_index_1056, m_916);
        i_1058 = kernel_thread_index_1056 - squot32(kernel_thread_index_1056,
                                                    m_916) * m_916;
    }
    // read kernel parameters
    {
        b_1059 = *(__global char *) &world_mem_1141[i_1057 * m_916 + i_1058];
    }
    
    int8_t res_1060;
    
    if (b_1059) {
        res_1060 = 1;
    } else {
        res_1060 = 0;
    }
    // write kernel result
    {
        *(__global int8_t *) &mem_1144[i_1057 * m_916 + i_1058] = res_1060;
    }
}
__kernel void map_kernel_1208(int32_t m_916, __global unsigned char *mem_1146)
{
    const uint global_thread_index_1208 = get_global_id(0);
    
    if (global_thread_index_1208 >= m_916)
        return;
    
    int32_t i_1209;
    
    // compute thread index
    {
        i_1209 = global_thread_index_1208;
    }
    // read kernel parameters
    { }
    // write kernel result
    {
        *(__global int32_t *) &mem_1146[i_1209 * 4] = 0;
    }
}
__kernel void map_kernel_1212(int32_t m_916, __global unsigned char *mem_1146,
                              int32_t n_915, __global unsigned char *mem_1149)
{
    const uint global_thread_index_1212 = get_global_id(0);
    
    if (global_thread_index_1212 >= n_915 * m_916)
        return;
    
    int32_t i_1213;
    int32_t j_1214;
    int32_t input_1215;
    
    // compute thread index
    {
        i_1213 = squot32(global_thread_index_1212, m_916);
        j_1214 = global_thread_index_1212 - squot32(global_thread_index_1212,
                                                    m_916) * m_916;
    }
    // read kernel parameters
    {
        input_1215 = *(__global int32_t *) &mem_1146[j_1214 * 4];
    }
    // write kernel result
    {
        *(__global int32_t *) &mem_1149[(i_1213 * m_916 + j_1214) * 4] =
            input_1215;
    }
}
__kernel void map_kernel_1082(int32_t n_925, int32_t m_926, __global
                              unsigned char *mem_1162, __global
                              unsigned char *all_history_mem_1151, __global
                              unsigned char *mem_1165, __global
                              unsigned char *mem_1169)
{
    const uint kernel_thread_index_1082 = get_global_id(0);
    
    if (kernel_thread_index_1082 >= n_925 * m_926)
        return;
    
    int32_t i_1083;
    int32_t i_1084;
    int32_t not_curried_1085;
    
    // compute thread index
    {
        i_1083 = squot32(kernel_thread_index_1082, m_926);
        i_1084 = kernel_thread_index_1082 - squot32(kernel_thread_index_1082,
                                                    m_926) * m_926;
    }
    // read kernel parameters
    {
        not_curried_1085 = *(__global int32_t *) &all_history_mem_1151[(i_1083 *
                                                                        m_926 +
                                                                        i_1084) *
                                                                       4];
    }
    
    int32_t res_1086 = not_curried_1085 & 3;
    int32_t arg_1087 = ashr32(not_curried_1085, 2);
    char cond_1088 = slt32(255, arg_1087);
    int32_t res_1089;
    
    if (cond_1088) {
        res_1089 = 255;
    } else {
        res_1089 = arg_1087;
    }
    
    int8_t y_1091 = sext_i32_i8(res_1089);
    
    // write kernel result
    {
        *(__global int8_t *) &mem_1165[i_1083 * m_926 + i_1084] = y_1091;
        for (int i_1220 = 0; i_1220 < 3; i_1220++) {
            *(__global int8_t *) &mem_1169[3 * (m_926 * i_1083) + (m_926 *
                                                                   i_1220 +
                                                                   i_1084)] =
                *(__global int8_t *) &mem_1162[3 * res_1086 + i_1220];
        }
    }
}
__kernel void map_kernel_1071(__global unsigned char *mem_1165, int32_t n_925,
                              __global unsigned char *mem_1169, int32_t m_926,
                              __global unsigned char *mem_1173)
{
    const uint kernel_thread_index_1071 = get_global_id(0);
    
    if (kernel_thread_index_1071 >= n_925 * m_926 * 3)
        return;
    
    int32_t i_1072;
    int32_t i_1073;
    int32_t i_1074;
    int8_t y_1075;
    int8_t binop_param_noncurried_1076;
    
    // compute thread index
    {
        i_1072 = squot32(kernel_thread_index_1071, m_926 * 3);
        i_1073 = squot32(kernel_thread_index_1071 -
                         squot32(kernel_thread_index_1071, m_926 * 3) * (m_926 *
                                                                         3), 3);
        i_1074 = kernel_thread_index_1071 - squot32(kernel_thread_index_1071,
                                                    m_926 * 3) * (m_926 * 3) -
            squot32(kernel_thread_index_1071 - squot32(kernel_thread_index_1071,
                                                       m_926 * 3) * (m_926 * 3),
                    3) * 3;
    }
    // read kernel parameters
    {
        y_1075 = *(__global int8_t *) &mem_1165[i_1072 * m_926 + i_1073];
        binop_param_noncurried_1076 = *(__global int8_t *) &mem_1169[i_1072 *
                                                                     (3 *
                                                                      m_926) +
                                                                     i_1074 *
                                                                     m_926 +
                                                                     i_1073];
    }
    
    int8_t res_1077 = binop_param_noncurried_1076 - y_1075;
    
    // write kernel result
    {
        *(__global int8_t *) &mem_1173[i_1072 * (m_926 * 3) + i_1073 * 3 +
                                       i_1074] = res_1077;
    }
}
__kernel void map_kernel_1132(int32_t n_946, __global unsigned char *mem_1181,
                              __global unsigned char *mem_1183)
{
    const uint kernel_thread_index_1132 = get_global_id(0);
    
    if (kernel_thread_index_1132 >= n_946)
        return;
    
    int32_t i_1133;
    
    // compute thread index
    {
        i_1133 = kernel_thread_index_1132;
    }
    // read kernel parameters
    { }
    
    int32_t x_1135 = i_1133 - 1;
    int32_t res_1136 = smod32(x_1135, n_946);
    int32_t x_1137 = i_1133 + 1;
    int32_t res_1138 = smod32(x_1137, n_946);
    
    // write kernel result
    {
        *(__global int32_t *) &mem_1181[i_1133 * 4] = res_1138;
        *(__global int32_t *) &mem_1183[i_1133 * 4] = res_1136;
    }
}
__kernel void map_kernel_1098(__global unsigned char *world_mem_1185, __global
                              unsigned char *mem_1181, int32_t n_946, __global
                              unsigned char *mem_1179, __global
                              unsigned char *history_mem_1187, int32_t m_947,
                              __global unsigned char *mem_1183, __global
                              unsigned char *mem_1190, __global
                              unsigned char *mem_1193)
{
    const uint kernel_thread_index_1098 = get_global_id(0);
    
    if (kernel_thread_index_1098 >= n_946 * m_947)
        return;
    
    int32_t i_1099;
    int32_t i_1100;
    int32_t res_1102;
    int32_t res_1103;
    int32_t x_1105;
    
    // compute thread index
    {
        i_1099 = squot32(kernel_thread_index_1098, m_947);
        i_1100 = kernel_thread_index_1098 - squot32(kernel_thread_index_1098,
                                                    m_947) * m_947;
    }
    // read kernel parameters
    {
        res_1102 = *(__global int32_t *) &mem_1181[i_1099 * 4];
        res_1103 = *(__global int32_t *) &mem_1183[i_1099 * 4];
        x_1105 = *(__global int32_t *) &history_mem_1187[(i_1099 * m_947 +
                                                          i_1100) * 4];
    }
    
    int32_t x_1106 = i_1100 + 1;
    int32_t res_1107 = smod32(x_1106, m_947);
    int32_t x_1108 = i_1100 - 1;
    int32_t res_1109 = smod32(x_1108, m_947);
    int8_t x_1110 = *(__global int8_t *) &world_mem_1185[res_1103 * m_947 +
                                                         i_1100];
    int8_t y_1111 = *(__global int8_t *) &world_mem_1185[i_1099 * m_947 +
                                                         res_1109];
    int8_t x_1112 = x_1110 + y_1111;
    int8_t y_1113 = *(__global int8_t *) &world_mem_1185[i_1099 * m_947 +
                                                         i_1100];
    int8_t x_1114 = x_1112 + y_1113;
    int8_t y_1115 = *(__global int8_t *) &world_mem_1185[i_1099 * m_947 +
                                                         res_1107];
    int8_t x_1116 = x_1114 + y_1115;
    int8_t y_1117 = *(__global int8_t *) &world_mem_1185[res_1102 * m_947 +
                                                         i_1100];
    int8_t res_1118 = x_1116 + y_1117;
    int32_t i_1119 = sext_i8_i32(res_1118);
    int8_t res_1120 = *(__global int8_t *) &mem_1179[i_1119];
    int32_t res_1121 = x_1105 & 3;
    int32_t res_1122 = ashr32(x_1105, 2);
    int8_t y_1123 = sext_i32_i8(res_1121);
    char cond_1124 = res_1120 == y_1123;
    int32_t x_1125 = res_1122 + 1;
    int32_t x_1126 = x_1125 << 2;
    int32_t y_1127 = sext_i8_i32(res_1120);
    int32_t res_1128 = x_1126 | y_1127;
    int32_t res_1129;
    
    if (cond_1124) {
        res_1129 = res_1128;
    } else {
        res_1129 = y_1127;
    }
    // write kernel result
    {
        *(__global int32_t *) &mem_1190[(i_1099 * m_947 + i_1100) * 4] =
            res_1129;
        *(__global int8_t *) &mem_1193[i_1099 * m_947 + i_1100] = res_1120;
    }
}
"""
# Hacky parser/reader for values written in Futhark syntax.  Used for
# reading stdin when compiling standalone programs with the Python
# code generator.

lookahead_buffer = []

def reset_lookahead():
    global lookahead_buffer
    lookahead_buffer = []

def get_char(f):
    global lookahead_buffer
    if len(lookahead_buffer) == 0:
        return f.read(1)
    else:
        c = lookahead_buffer[0]
        lookahead_buffer = lookahead_buffer[1:]
        return c

def unget_char(f, c):
    global lookahead_buffer
    lookahead_buffer = [c] + lookahead_buffer

def peek_char(f):
    c = get_char(f)
    if c:
        unget_char(f, c)
    return c

def skip_spaces(f):
    c = get_char(f)
    while c != None:
        if c.isspace():
            c = get_char(f)
        elif c == '-':
          # May be line comment.
          if peek_char(f) == '-':
            # Yes, line comment. Skip to end of line.
            while (c != '\n' and c != None):
              c = get_char(f)
          else:
            break
        else:
          break
    if c:
        unget_char(f, c)

def parse_specific_char(f, expected):
    got = get_char(f)
    if got != expected:
        unget_char(f, got)
        raise ValueError
    return True

def parse_specific_string(f, s):
    for c in s:
        parse_specific_char(f, c)
    return True

def optional(p, *args):
    try:
        return p(*args)
    except ValueError:
        return None

def sepBy(p, sep, *args):
    elems = []
    x = optional(p, *args)
    if x != None:
        elems += [x]
        while optional(sep, *args) != None:
            x = p(*args)
            elems += [x]
    return elems

def parse_int(f):
    s = ''
    c = get_char(f)
    while c != None:
        if c.isdigit():
            s += c
            c = get_char(f)
        else:
            unget_char(f, c)
            break
    optional(read_int_trailer, f)
    return s

def parse_int_signed(f):
    s = ''
    c = get_char(f)

    if c == '-' and peek_char(f).isdigit():
      s = c + parse_int(f)
    else:
      unget_char(f, c)
      s = parse_int(f)

    return s

def read_int_trailer(f):
  parse_specific_char(f, 'i')
  while peek_char(f).isdigit():
    get_char(f)

def read_comma(f):
    skip_spaces(f)
    parse_specific_char(f, ',')
    return ','

def read_int(f):
    skip_spaces(f)
    return int(parse_int_signed(f))

def read_char(f):
    skip_spaces(f)
    parse_specific_char(f, '\'')
    c = get_char(f)
    parse_specific_char(f, '\'')
    return c

def read_double(f):
    skip_spaces(f)
    c = get_char(f)
    if (c == '-'):
      sign = '-'
    else:
      unget_char(f,c)
      sign = ''
    bef = optional(parse_int, f)
    if bef == None:
        bef = '0'
        parse_specific_char(f, '.')
        aft = parse_int(f)
    elif optional(parse_specific_char, f, '.'):
        aft = parse_int(f)
    else:
        aft = '0'
    if (optional(parse_specific_char, f, 'E') or
        optional(parse_specific_char, f, 'e')):
        expt = parse_int_signed(f)
    else:
        expt = '0'
    optional(read_float_trailer, f)
    return float(sign + bef + '.' + aft + 'E' + expt)

def read_float(f):
    return read_double(f)

def read_float_trailer(f):
  parse_specific_char(f, 'f')
  while peek_char(f).isdigit():
    get_char(f)

def read_bool(f):
    skip_spaces(f)
    if peek_char(f) == 'T':
        parse_specific_string(f, 'True')
        return True
    elif peek_char(f) == 'F':
        parse_specific_string(f, 'False')
        return False
    else:
        raise ValueError

def read_array_elems(f, elem_reader):
    skip_spaces(f)
    parse_specific_char(f, '[')
    xs = sepBy(elem_reader, read_comma, f)
    skip_spaces(f)
    parse_specific_char(f, ']')
    return xs

def read_array_helper(f, elem_reader, rank):
    def nested_row_reader(_):
        return read_array_helper(f, elem_reader, rank-1)
    if rank == 1:
        row_reader = elem_reader
    else:
        row_reader = nested_row_reader
    return read_array_elems(f, row_reader)

def expected_array_dims(l, rank):
  if rank > 1:
      n = len(l)
      if n == 0:
          elem = []
      else:
          elem = l[0]
      return [n] + expected_array_dims(elem, rank-1)
  else:
      return [len(l)]

def verify_array_dims(l, dims):
    if dims[0] != len(l):
        raise ValueError
    if len(dims) > 1:
        for x in l:
            verify_array_dims(x, dims[1:])

def read_double_signed(f):

    skip_spaces(f)
    c = get_char(f)

    if c == '-' and peek_char(f).isdigit():
      v = -1 * read_double(f)
    else:
      unget_char(f, c)
      v = read_double(f)

    return v

def read_array(f, elem_reader, rank, bt):
    elems = read_array_helper(f, elem_reader, rank)
    dims = expected_array_dims(elems, rank)
    verify_array_dims(elems, dims)
    return np.array(elems, dtype=bt)
# Scalar functions.

import numpy as np

def signed(x):
  if type(x) == np.uint8:
    return np.int8(x)
  elif type(x) == np.uint16:
    return np.int16(x)
  elif type(x) == np.uint32:
    return np.int32(x)
  else:
    return np.int64(x)

def unsigned(x):
  if type(x) == np.int8:
    return np.uint8(x)
  elif type(x) == np.int16:
    return np.uint16(x)
  elif type(x) == np.int32:
    return np.uint32(x)
  else:
    return np.uint64(x)

def shlN(x,y):
  return x << y

def ashrN(x,y):
  return x >> y

def sdivN(x,y):
  return x / y

def smodN(x,y):
  return x % y

def udivN(x,y):
  return signed(unsigned(x) / unsigned(y))

def umodN(x,y):
  return signed(unsigned(x) % unsigned(y))

def squotN(x,y):
  return np.int32(float(x) / float(y))

def sremN(x,y):
  return np.fmod(x,y)

def powN(x,y):
  return x ** y

def fpowN(x,y):
  return x ** y

def sleN(x,y):
  return x <= y

def sltN(x,y):
  return x < y

def uleN(x,y):
  return unsigned(x) <= unsigned(y)

def ultN(x,y):
  return unsigned(x) < unsigned(y)

def lshr8(x,y):
  return np.int8(np.uint8(x) >> np.uint8(y))

def lshr16(x,y):
  return np.int16(np.uint16(x) >> np.uint16(y))

def lshr32(x,y):
  return np.int32(np.uint32(x) >> np.uint32(y))

def lshr64(x,y):
  return np.int64(np.uint64(x) >> np.uint64(y))

def sext_T_i8(x):
  return np.int8(x)

def sext_T_i16(x):
  return np.int16(x)

def sext_T_i32(x):
  return np.int32(x)

def sext_T_i64(x):
  return np.int32(x)

def zext_i8_i8(x):
  return np.int8(np.uint8(x))

def zext_i8_i16(x):
  return np.int16(np.uint8(x))

def zext_i8_i32(x):
  return np.int32(np.uint8(x))

def zext_i8_i64(x):
  return np.int64(np.uint8(x))

def zext_i16_i8(x):
  return np.int8(np.uint16(x))

def zext_i16_i16(x):
  return np.int16(np.uint16(x))

def zext_i16_i32(x):
  return np.int32(np.uint16(x))

def zext_i16_i64(x):
  return np.int64(np.uint16(x))

def zext_i32_i8(x):
  return np.int8(np.uint32(x))

def zext_i32_i16(x):
  return np.int16(np.uint32(x))

def zext_i32_i32(x):
  return np.int32(np.uint32(x))

def zext_i32_i64(x):
  return np.int64(np.uint32(x))

def zext_i64_i8(x):
  return np.int8(np.uint64(x))

def zext_i64_i16(x):
  return np.int16(np.uint64(x))

def zext_i64_i32(x):
  return np.int32(np.uint64(x))

def zext_i64_i64(x):
  return np.int64(np.uint64(x))

shl8 = shl16 = shl32 = shl64 = shlN
ashr8 = ashr16 = ashr32 = ashr64 = ashrN
sdiv8 = sdiv16 = sdiv32 = sdiv64 = sdivN
smod8 = smod16 = smod32 = smod64 = smodN
udiv8 = udiv16 = udiv32 = udiv64 = udivN
umod8 = umod16 = umod32 = umod64 = umodN
squot8 = squot16 = squot32 = squot64 = squotN
srem8 = srem16 = srem32 = srem64 = sremN
pow8 = pow16 = pow32 = pow64 = powN
fpow32 = fpow64 = fpowN
sle8 = sle16 = sle32 = sle64 = sleN
slt8 = slt16 = slt32 = slt64 = sltN
ule8 = ule16 = ule32 = ule64 = uleN
ult8 = ult16 = ult32 = ult64 = ultN
sext_i8_i8 = sext_i16_i8 = sext_i32_i8 = sext_i64_i8 = sext_T_i8
sext_i8_i16 = sext_i16_i16 = sext_i32_i16 = sext_i64_i16 = sext_T_i16
sext_i8_i32 = sext_i16_i32 = sext_i32_i32 = sext_i64_i32 = sext_T_i32
sext_i8_i64 = sext_i16_i64 = sext_i32_i64 = sext_i64_i64 = sext_T_i64

def ssignum(x):
  return np.sign(x)

def usignum(x):
  if x < 0:
    return ssignum(-x)
  else:
    return ssignum(x)

def sitofp_T_f32(x):
  return np.float32(x)
sitofp_i8_f32 = sitofp_i16_f32 = sitofp_i32_f32 = sitofp_i64_f32 = sitofp_T_f32

def sitofp_T_f64(x):
  return np.float64(x)
sitofp_i8_f64 = sitofp_i16_f64 = sitofp_i32_f64 = sitofp_i64_f64 = sitofp_T_f64

def uitofp_T_f32(x):
  return np.float32(unsigned(x))
uitofp_i8_f32 = uitofp_i16_f32 = uitofp_i32_f32 = uitofp_i64_f32 = uitofp_T_f32

def uitofp_T_f64(x):
  return np.float64(unsigned(x))
uitofp_i8_f64 = uitofp_i16_f64 = uitofp_i32_f64 = uitofp_i64_f64 = uitofp_T_f64

def fptosi_T_i8(x):
  return np.int8(np.trunc(x))
fptosi_f32_i8 = fptosi_f64_i8 = fptosi_T_i8

def fptosi_T_i16(x):
  return np.int16(np.trunc(x))
fptosi_f32_i16 = fptosi_f64_i16 = fptosi_T_i16

def fptosi_T_i32(x):
  return np.int32(np.trunc(x))
fptosi_f32_i32 = fptosi_f64_i32 = fptosi_T_i32

def fptosi_T_i64(x):
  return np.int64(np.trunc(x))
fptosi_f32_i64 = fptosi_f64_i64 = fptosi_T_i64

def fptoui_T_i8(x):
  return np.uint8(np.trunc(x))
fptoui_f32_i8 = fptoui_f64_i8 = fptoui_T_i8

def fptoui_T_i16(x):
  return np.uint16(np.trunc(x))
fptoui_f32_i16 = fptoui_f64_i16 = fptoui_T_i16

def fptoui_T_i32(x):
  return np.uint32(np.trunc(x))
fptoui_f32_i32 = fptoui_f64_i32 = fptoui_T_i32

def fptoui_T_i64(x):
  return np.uint64(np.trunc(x))
fptoui_f32_i64 = fptoui_f64_i64 = fptoui_T_i64

def fpconv_f32_f64(x):
  return np.float64(x)

def fpconv_f64_f32(x):
  return np.float32(x)

def futhark_log64(x):
  return np.float64(np.log(x))

def futhark_sqrt64(x):
  return np.sqrt(x)

def futhark_exp64(x):
  return np.exp(x)

def futhark_cos64(x):
  return np.cos(x)

def futhark_sin64(x):
  return np.sin(x)

def futhark_atan2_64(x, y):
  return np.arctan2(x, y)

def futhark_isnan64(x):
  return np.isnan(x)

def futhark_isinf64(x):
  return np.isinf(x)

def futhark_log32(x):
  return np.float32(np.log(x))

def futhark_sqrt32(x):
  return np.float32(np.sqrt(x))

def futhark_exp32(x):
  return np.exp(x)

def futhark_cos32(x):
  return np.cos(x)

def futhark_sin32(x):
  return np.sin(x)

def futhark_atan2_32(x, y):
  return np.arctan2(x, y)

def futhark_isnan32(x):
  return np.isnan(x)

def futhark_isinf32(x):
  return np.isinf(x)
class quadlife_alt:
  def __init__(self):
    self.ctx = cl.create_some_context(interactive=False)
    self.queue = cl.CommandQueue(self.ctx)
     # XXX: Assuming just a single device here.
    platform_name = self.ctx.get_info(cl.context_info.DEVICES)[0].platform.name
    device_type = self.ctx.get_info(cl.context_info.DEVICES)[0].type
    lockstep_width = 1
    if ((platform_name == "NVIDIA CUDA") and (device_type == cl.device_type.GPU)):
      lockstep_width = np.int32(32)
    if ((platform_name == "AMD Accelerated Parallel Processing") and (device_type == cl.device_type.GPU)):
      lockstep_width = np.int32(64)
    if (len(fut_opencl_src) >= 0):
      program = cl.Program(self.ctx, fut_opencl_src).build(["-DFUT_BLOCK_DIM={}".format(FUT_BLOCK_DIM), "-DLOCKSTEP_WIDTH={}".format(lockstep_width)])
    
    self.map_kernel_1056_var = program.map_kernel_1056
    self.map_kernel_1208_var = program.map_kernel_1208
    self.map_kernel_1212_var = program.map_kernel_1212
    self.map_kernel_1082_var = program.map_kernel_1082
    self.map_kernel_1071_var = program.map_kernel_1071
    self.map_kernel_1132_var = program.map_kernel_1132
    self.map_kernel_1098_var = program.map_kernel_1098
  def futhark_init(self, world_mem_size_1140, world_mem_1141, n_915, m_916):
    nesting_size_1054 = (m_916 * n_915)
    bytes_1142 = (n_915 * m_916)
    mem_1144 = cl.Buffer(self.ctx, cl.mem_flags.READ_WRITE,
                         long(long(bytes_1142) if (bytes_1142 > np.int32(0)) else np.int32(1)))
    group_size_1206 = np.int32(512)
    num_groups_1207 = squot32((((n_915 * m_916) + group_size_1206) - np.int32(1)),
                              group_size_1206)
    if ((np.int32(1) * (num_groups_1207 * group_size_1206)) != np.int32(0)):
      self.map_kernel_1056_var.set_args(np.int32(m_916), world_mem_1141,
                                        np.int32(n_915), mem_1144)
      cl.enqueue_nd_range_kernel(self.queue, self.map_kernel_1056_var,
                                 (long((num_groups_1207 * group_size_1206)),),
                                 (long(group_size_1206),))
      if synchronous:
        self.queue.finish()
    bytes_1145 = (np.int32(4) * m_916)
    mem_1146 = cl.Buffer(self.ctx, cl.mem_flags.READ_WRITE,
                         long(long(bytes_1145) if (bytes_1145 > np.int32(0)) else np.int32(1)))
    group_size_1210 = np.int32(512)
    num_groups_1211 = squot32(((m_916 + group_size_1210) - np.int32(1)),
                              group_size_1210)
    if ((np.int32(1) * (num_groups_1211 * group_size_1210)) != np.int32(0)):
      self.map_kernel_1208_var.set_args(np.int32(m_916), mem_1146)
      cl.enqueue_nd_range_kernel(self.queue, self.map_kernel_1208_var,
                                 (long((num_groups_1211 * group_size_1210)),),
                                 (long(group_size_1210),))
      if synchronous:
        self.queue.finish()
    x_1148 = (np.int32(4) * n_915)
    bytes_1147 = (x_1148 * m_916)
    mem_1149 = cl.Buffer(self.ctx, cl.mem_flags.READ_WRITE,
                         long(long(bytes_1147) if (bytes_1147 > np.int32(0)) else np.int32(1)))
    group_size_1216 = np.int32(512)
    num_groups_1217 = squot32((((n_915 * m_916) + group_size_1216) - np.int32(1)),
                              group_size_1216)
    if ((np.int32(1) * (num_groups_1217 * group_size_1216)) != np.int32(0)):
      self.map_kernel_1212_var.set_args(np.int32(m_916), mem_1146,
                                        np.int32(n_915), mem_1149)
      cl.enqueue_nd_range_kernel(self.queue, self.map_kernel_1212_var,
                                 (long((num_groups_1217 * group_size_1216)),),
                                 (long(group_size_1216),))
      if synchronous:
        self.queue.finish()
    out_mem_1202 = mem_1144
    out_memsize_1203 = bytes_1142
    out_mem_1204 = mem_1149
    out_memsize_1205 = bytes_1147
    return (out_memsize_1203, out_mem_1202, out_memsize_1205, out_mem_1204)
  def futhark_render_frame(self, all_history_mem_size_1150,
                           all_history_mem_1151, n_925, m_926):
    mem_1153 = cl.Buffer(self.ctx, cl.mem_flags.READ_WRITE,
                         long(long(np.int32(3)) if (np.int32(3) > np.int32(0)) else np.int32(1)))
    cl.enqueue_copy(self.queue, mem_1153, np.array(np.int8(0), dtype=ct.c_int8),
                    device_offset=long(np.int32(0)), is_blocking=synchronous)
    cl.enqueue_copy(self.queue, mem_1153, np.array(np.int8(0), dtype=ct.c_int8),
                    device_offset=long(np.int32(1)), is_blocking=synchronous)
    cl.enqueue_copy(self.queue, mem_1153, np.array(np.int8(-1),
                                                   dtype=ct.c_int8),
                    device_offset=long(np.int32(2)), is_blocking=synchronous)
    mem_1155 = cl.Buffer(self.ctx, cl.mem_flags.READ_WRITE,
                         long(long(np.int32(3)) if (np.int32(3) > np.int32(0)) else np.int32(1)))
    cl.enqueue_copy(self.queue, mem_1155, np.array(np.int8(0), dtype=ct.c_int8),
                    device_offset=long(np.int32(0)), is_blocking=synchronous)
    cl.enqueue_copy(self.queue, mem_1155, np.array(np.int8(-1),
                                                   dtype=ct.c_int8),
                    device_offset=long(np.int32(1)), is_blocking=synchronous)
    cl.enqueue_copy(self.queue, mem_1155, np.array(np.int8(0), dtype=ct.c_int8),
                    device_offset=long(np.int32(2)), is_blocking=synchronous)
    mem_1157 = cl.Buffer(self.ctx, cl.mem_flags.READ_WRITE,
                         long(long(np.int32(3)) if (np.int32(3) > np.int32(0)) else np.int32(1)))
    cl.enqueue_copy(self.queue, mem_1157, np.array(np.int8(-1),
                                                   dtype=ct.c_int8),
                    device_offset=long(np.int32(0)), is_blocking=synchronous)
    cl.enqueue_copy(self.queue, mem_1157, np.array(np.int8(0), dtype=ct.c_int8),
                    device_offset=long(np.int32(1)), is_blocking=synchronous)
    cl.enqueue_copy(self.queue, mem_1157, np.array(np.int8(0), dtype=ct.c_int8),
                    device_offset=long(np.int32(2)), is_blocking=synchronous)
    mem_1159 = cl.Buffer(self.ctx, cl.mem_flags.READ_WRITE,
                         long(long(np.int32(3)) if (np.int32(3) > np.int32(0)) else np.int32(1)))
    cl.enqueue_copy(self.queue, mem_1159, np.array(np.int8(-1),
                                                   dtype=ct.c_int8),
                    device_offset=long(np.int32(0)), is_blocking=synchronous)
    cl.enqueue_copy(self.queue, mem_1159, np.array(np.int8(-1),
                                                   dtype=ct.c_int8),
                    device_offset=long(np.int32(1)), is_blocking=synchronous)
    cl.enqueue_copy(self.queue, mem_1159, np.array(np.int8(0), dtype=ct.c_int8),
                    device_offset=long(np.int32(2)), is_blocking=synchronous)
    mem_1162 = cl.Buffer(self.ctx, cl.mem_flags.READ_WRITE,
                         long(long(np.int32(12)) if (np.int32(12) > np.int32(0)) else np.int32(1)))
    if ((np.int32(3) * np.int32(1)) != np.int32(0)):
      cl.enqueue_copy(self.queue, mem_1162, mem_1153,
                      dest_offset=long(np.int32(0)),
                      src_offset=long(np.int32(0)),
                      byte_count=long((np.int32(3) * np.int32(1))))
    if synchronous:
      self.queue.finish()
    if ((np.int32(3) * np.int32(1)) != np.int32(0)):
      cl.enqueue_copy(self.queue, mem_1162, mem_1155,
                      dest_offset=long(np.int32(3)),
                      src_offset=long(np.int32(0)),
                      byte_count=long((np.int32(3) * np.int32(1))))
    if synchronous:
      self.queue.finish()
    if ((np.int32(3) * np.int32(1)) != np.int32(0)):
      cl.enqueue_copy(self.queue, mem_1162, mem_1157,
                      dest_offset=long((np.int32(3) * np.int32(2))),
                      src_offset=long(np.int32(0)),
                      byte_count=long((np.int32(3) * np.int32(1))))
    if synchronous:
      self.queue.finish()
    if ((np.int32(3) * np.int32(1)) != np.int32(0)):
      cl.enqueue_copy(self.queue, mem_1162, mem_1159,
                      dest_offset=long((np.int32(3) * np.int32(3))),
                      src_offset=long(np.int32(0)),
                      byte_count=long((np.int32(3) * np.int32(1))))
    if synchronous:
      self.queue.finish()
    nesting_size_1080 = (m_926 * n_925)
    bytes_1163 = (n_925 * m_926)
    mem_1165 = cl.Buffer(self.ctx, cl.mem_flags.READ_WRITE,
                         long(long(bytes_1163) if (bytes_1163 > np.int32(0)) else np.int32(1)))
    x_1168 = (n_925 * np.int32(3))
    bytes_1166 = (x_1168 * m_926)
    mem_1169 = cl.Buffer(self.ctx, cl.mem_flags.READ_WRITE,
                         long(long(bytes_1166) if (bytes_1166 > np.int32(0)) else np.int32(1)))
    group_size_1221 = np.int32(512)
    num_groups_1222 = squot32((((n_925 * m_926) + group_size_1221) - np.int32(1)),
                              group_size_1221)
    if ((np.int32(1) * (num_groups_1222 * group_size_1221)) != np.int32(0)):
      self.map_kernel_1082_var.set_args(np.int32(n_925), np.int32(m_926),
                                        mem_1162, all_history_mem_1151,
                                        mem_1165, mem_1169)
      cl.enqueue_nd_range_kernel(self.queue, self.map_kernel_1082_var,
                                 (long((num_groups_1222 * group_size_1221)),),
                                 (long(group_size_1221),))
      if synchronous:
        self.queue.finish()
    nesting_size_1067 = (np.int32(3) * m_926)
    nesting_size_1069 = (nesting_size_1067 * n_925)
    bytes_1170 = (bytes_1163 * np.int32(3))
    mem_1173 = cl.Buffer(self.ctx, cl.mem_flags.READ_WRITE,
                         long(long(bytes_1170) if (bytes_1170 > np.int32(0)) else np.int32(1)))
    group_size_1223 = np.int32(512)
    num_groups_1224 = squot32(((((n_925 * m_926) * np.int32(3)) + group_size_1223) - np.int32(1)),
                              group_size_1223)
    if ((np.int32(1) * (num_groups_1224 * group_size_1223)) != np.int32(0)):
      self.map_kernel_1071_var.set_args(mem_1165, np.int32(n_925), mem_1169,
                                        np.int32(m_926), mem_1173)
      cl.enqueue_nd_range_kernel(self.queue, self.map_kernel_1071_var,
                                 (long((num_groups_1224 * group_size_1223)),),
                                 (long(group_size_1223),))
      if synchronous:
        self.queue.finish()
    out_mem_1218 = mem_1173
    out_memsize_1219 = bytes_1170
    return (out_memsize_1219, out_mem_1218)
  def futhark_steps(self, world_mem_size_1174, history_mem_size_1176,
                    world_mem_1175, history_mem_1177, n_946, m_947, steps_950):
    mem_1179 = cl.Buffer(self.ctx, cl.mem_flags.READ_WRITE,
                         long(long(np.int32(16)) if (np.int32(16) > np.int32(0)) else np.int32(1)))
    cl.enqueue_copy(self.queue, mem_1179, np.array(np.int8(0), dtype=ct.c_int8),
                    device_offset=long(np.int32(0)), is_blocking=synchronous)
    cl.enqueue_copy(self.queue, mem_1179, np.array(np.int8(1), dtype=ct.c_int8),
                    device_offset=long(np.int32(1)), is_blocking=synchronous)
    cl.enqueue_copy(self.queue, mem_1179, np.array(np.int8(1), dtype=ct.c_int8),
                    device_offset=long(np.int32(2)), is_blocking=synchronous)
    cl.enqueue_copy(self.queue, mem_1179, np.array(np.int8(0), dtype=ct.c_int8),
                    device_offset=long(np.int32(3)), is_blocking=synchronous)
    cl.enqueue_copy(self.queue, mem_1179, np.array(np.int8(0), dtype=ct.c_int8),
                    device_offset=long(np.int32(4)), is_blocking=synchronous)
    cl.enqueue_copy(self.queue, mem_1179, np.array(np.int8(1), dtype=ct.c_int8),
                    device_offset=long(np.int32(5)), is_blocking=synchronous)
    cl.enqueue_copy(self.queue, mem_1179, np.array(np.int8(1), dtype=ct.c_int8),
                    device_offset=long(np.int32(6)), is_blocking=synchronous)
    cl.enqueue_copy(self.queue, mem_1179, np.array(np.int8(1), dtype=ct.c_int8),
                    device_offset=long(np.int32(7)), is_blocking=synchronous)
    cl.enqueue_copy(self.queue, mem_1179, np.array(np.int8(2), dtype=ct.c_int8),
                    device_offset=long(np.int32(8)), is_blocking=synchronous)
    cl.enqueue_copy(self.queue, mem_1179, np.array(np.int8(2), dtype=ct.c_int8),
                    device_offset=long(np.int32(9)), is_blocking=synchronous)
    cl.enqueue_copy(self.queue, mem_1179, np.array(np.int8(2), dtype=ct.c_int8),
                    device_offset=long(np.int32(10)), is_blocking=synchronous)
    cl.enqueue_copy(self.queue, mem_1179, np.array(np.int8(3), dtype=ct.c_int8),
                    device_offset=long(np.int32(11)), is_blocking=synchronous)
    cl.enqueue_copy(self.queue, mem_1179, np.array(np.int8(3), dtype=ct.c_int8),
                    device_offset=long(np.int32(12)), is_blocking=synchronous)
    cl.enqueue_copy(self.queue, mem_1179, np.array(np.int8(2), dtype=ct.c_int8),
                    device_offset=long(np.int32(13)), is_blocking=synchronous)
    cl.enqueue_copy(self.queue, mem_1179, np.array(np.int8(2), dtype=ct.c_int8),
                    device_offset=long(np.int32(14)), is_blocking=synchronous)
    cl.enqueue_copy(self.queue, mem_1179, np.array(np.int8(3), dtype=ct.c_int8),
                    device_offset=long(np.int32(15)), is_blocking=synchronous)
    bytes_1180 = (np.int32(4) * n_946)
    mem_1181 = cl.Buffer(self.ctx, cl.mem_flags.READ_WRITE,
                         long(long(bytes_1180) if (bytes_1180 > np.int32(0)) else np.int32(1)))
    mem_1183 = cl.Buffer(self.ctx, cl.mem_flags.READ_WRITE,
                         long(long(bytes_1180) if (bytes_1180 > np.int32(0)) else np.int32(1)))
    group_size_1229 = np.int32(512)
    num_groups_1230 = squot32(((n_946 + group_size_1229) - np.int32(1)),
                              group_size_1229)
    if ((np.int32(1) * (num_groups_1230 * group_size_1229)) != np.int32(0)):
      self.map_kernel_1132_var.set_args(np.int32(n_946), mem_1181, mem_1183)
      cl.enqueue_nd_range_kernel(self.queue, self.map_kernel_1132_var,
                                 (long((num_groups_1230 * group_size_1229)),),
                                 (long(group_size_1229),))
      if synchronous:
        self.queue.finish()
    nesting_size_1096 = (m_947 * n_946)
    bytes_1188 = (bytes_1180 * m_947)
    bytes_1191 = (n_946 * m_947)
    double_buffer_mem_1198 = cl.Buffer(self.ctx, cl.mem_flags.READ_WRITE,
                                       long(long(bytes_1191) if (bytes_1191 > np.int32(0)) else np.int32(1)))
    double_buffer_mem_1199 = cl.Buffer(self.ctx, cl.mem_flags.READ_WRITE,
                                       long(long(bytes_1188) if (bytes_1188 > np.int32(0)) else np.int32(1)))
    mem_1190 = cl.Buffer(self.ctx, cl.mem_flags.READ_WRITE,
                         long(long(bytes_1188) if (bytes_1188 > np.int32(0)) else np.int32(1)))
    mem_1193 = cl.Buffer(self.ctx, cl.mem_flags.READ_WRITE,
                         long(long(bytes_1191) if (bytes_1191 > np.int32(0)) else np.int32(1)))
    world_mem_size_1184 = world_mem_size_1174
    history_mem_size_1186 = history_mem_size_1176
    world_mem_1185 = world_mem_1175
    history_mem_1187 = history_mem_1177
    i_956 = np.int32(0)
    one_1240 = np.int32(1)
    for counter_1239 in range(steps_950):
      group_size_1237 = np.int32(512)
      num_groups_1238 = squot32((((n_946 * m_947) + group_size_1237) - np.int32(1)),
                                group_size_1237)
      if ((np.int32(1) * (num_groups_1238 * group_size_1237)) != np.int32(0)):
        self.map_kernel_1098_var.set_args(world_mem_1185, mem_1181,
                                          np.int32(n_946), mem_1179,
                                          history_mem_1187, np.int32(m_947),
                                          mem_1183, mem_1190, mem_1193)
        cl.enqueue_nd_range_kernel(self.queue, self.map_kernel_1098_var,
                                   (long((num_groups_1238 * group_size_1237)),),
                                   (long(group_size_1237),))
        if synchronous:
          self.queue.finish()
      if (((n_946 * m_947) * np.int32(1)) != np.int32(0)):
        cl.enqueue_copy(self.queue, double_buffer_mem_1198, mem_1193,
                        dest_offset=long(np.int32(0)),
                        src_offset=long(np.int32(0)),
                        byte_count=long(((n_946 * m_947) * np.int32(1))))
      if synchronous:
        self.queue.finish()
      if (((n_946 * m_947) * np.int32(4)) != np.int32(0)):
        cl.enqueue_copy(self.queue, double_buffer_mem_1199, mem_1190,
                        dest_offset=long(np.int32(0)),
                        src_offset=long(np.int32(0)),
                        byte_count=long(((n_946 * m_947) * np.int32(4))))
      if synchronous:
        self.queue.finish()
      world_mem_size_tmp_1231 = bytes_1191
      history_mem_size_tmp_1232 = bytes_1188
      world_mem_tmp_1233 = double_buffer_mem_1198
      history_mem_tmp_1234 = double_buffer_mem_1199
      world_mem_size_1184 = world_mem_size_tmp_1231
      history_mem_size_1186 = history_mem_size_tmp_1232
      world_mem_1185 = world_mem_tmp_1233
      history_mem_1187 = history_mem_tmp_1234
      i_956 += one_1240
    world_mem_1195 = world_mem_1185
    world_mem_size_1194 = world_mem_size_1184
    history_mem_1197 = history_mem_1187
    history_mem_size_1196 = history_mem_size_1186
    out_mem_1225 = world_mem_1195
    out_memsize_1226 = world_mem_size_1194
    out_mem_1227 = history_mem_1197
    out_memsize_1228 = history_mem_size_1196
    return (out_memsize_1226, out_mem_1225, out_memsize_1228, out_mem_1227)
  def init(self, world_mem_1141_ext):
    n_915 = np.int32(world_mem_1141_ext.shape[np.int32(0)])
    m_916 = np.int32(world_mem_1141_ext.shape[np.int32(1)])
    world_mem_size_1140 = np.int32(world_mem_1141_ext.nbytes)
    world_mem_device_1241 = cl.Buffer(self.ctx, cl.mem_flags.READ_WRITE,
                                      long(long(world_mem_size_1140) if (world_mem_size_1140 > np.int32(0)) else np.int32(1)))
    world_mem_1141 = world_mem_1141_ext
    if (world_mem_1141_ext.nbytes != np.int32(0)):
      cl.enqueue_copy(self.queue, world_mem_device_1241,
                      world_mem_1141[np.int32(0):(np.int32(0) + (world_mem_1141_ext.nbytes // 1))],
                      device_offset=long(np.int32(0)), is_blocking=synchronous)
    world_mem_1141 = world_mem_device_1241
    (out_memsize_1203, out_mem_1202, out_memsize_1205,
     out_mem_1204) = self.futhark_init(world_mem_size_1140, world_mem_1141,
                                       n_915, m_916)
    out_mem_device_1242 = np.empty((n_915, m_916), dtype=ct.c_int8)
    if (out_memsize_1203 != np.int32(0)):
      cl.enqueue_copy(self.queue,
                      out_mem_device_1242[np.int32(0):(np.int32(0) + (out_memsize_1203 // 1))],
                      out_mem_1202, device_offset=long(np.int32(0)),
                      is_blocking=synchronous)
    out_mem_1202 = out_mem_device_1242
    out_mem_device_1243 = np.empty((n_915, m_916), dtype=ct.c_int32)
    if (out_memsize_1205 != np.int32(0)):
      cl.enqueue_copy(self.queue,
                      out_mem_device_1243[np.int32(0):(np.int32(0) + (out_memsize_1205 // 4))],
                      out_mem_1204, device_offset=long(np.int32(0)),
                      is_blocking=synchronous)
    out_mem_1204 = out_mem_device_1243
    return (out_mem_1202, out_mem_1204)
  def render_frame(self, all_history_mem_1151_ext):
    n_925 = np.int32(all_history_mem_1151_ext.shape[np.int32(0)])
    m_926 = np.int32(all_history_mem_1151_ext.shape[np.int32(1)])
    all_history_mem_size_1150 = np.int32(all_history_mem_1151_ext.nbytes)
    all_history_mem_device_1244 = cl.Buffer(self.ctx, cl.mem_flags.READ_WRITE,
                                            long(long(all_history_mem_size_1150) if (all_history_mem_size_1150 > np.int32(0)) else np.int32(1)))
    all_history_mem_1151 = all_history_mem_1151_ext
    if (all_history_mem_1151_ext.nbytes != np.int32(0)):
      cl.enqueue_copy(self.queue, all_history_mem_device_1244,
                      all_history_mem_1151[np.int32(0):(np.int32(0) + (all_history_mem_1151_ext.nbytes // 4))],
                      device_offset=long(np.int32(0)), is_blocking=synchronous)
    all_history_mem_1151 = all_history_mem_device_1244
    (out_memsize_1219,
     out_mem_1218) = self.futhark_render_frame(all_history_mem_size_1150,
                                               all_history_mem_1151, n_925,
                                               m_926)
    out_mem_device_1245 = np.empty((n_925, m_926, np.int32(3)), dtype=ct.c_int8)
    if (out_memsize_1219 != np.int32(0)):
      cl.enqueue_copy(self.queue,
                      out_mem_device_1245[np.int32(0):(np.int32(0) + (out_memsize_1219 // 1))],
                      out_mem_1218, device_offset=long(np.int32(0)),
                      is_blocking=synchronous)
    out_mem_1218 = out_mem_device_1245
    return out_mem_1218
  def steps(self, world_mem_1175_ext, history_mem_1177_ext, steps_950_ext):
    n_946 = np.int32(world_mem_1175_ext.shape[np.int32(0)])
    m_947 = np.int32(world_mem_1175_ext.shape[np.int32(1)])
    world_mem_size_1174 = np.int32(world_mem_1175_ext.nbytes)
    world_mem_device_1246 = cl.Buffer(self.ctx, cl.mem_flags.READ_WRITE,
                                      long(long(world_mem_size_1174) if (world_mem_size_1174 > np.int32(0)) else np.int32(1)))
    world_mem_1175 = world_mem_1175_ext
    if (world_mem_1175_ext.nbytes != np.int32(0)):
      cl.enqueue_copy(self.queue, world_mem_device_1246,
                      world_mem_1175[np.int32(0):(np.int32(0) + (world_mem_1175_ext.nbytes // 1))],
                      device_offset=long(np.int32(0)), is_blocking=synchronous)
    world_mem_1175 = world_mem_device_1246
    n_946 = np.int32(history_mem_1177_ext.shape[np.int32(0)])
    m_947 = np.int32(history_mem_1177_ext.shape[np.int32(1)])
    history_mem_size_1176 = np.int32(history_mem_1177_ext.nbytes)
    history_mem_device_1247 = cl.Buffer(self.ctx, cl.mem_flags.READ_WRITE,
                                        long(long(history_mem_size_1176) if (history_mem_size_1176 > np.int32(0)) else np.int32(1)))
    history_mem_1177 = history_mem_1177_ext
    if (history_mem_1177_ext.nbytes != np.int32(0)):
      cl.enqueue_copy(self.queue, history_mem_device_1247,
                      history_mem_1177[np.int32(0):(np.int32(0) + (history_mem_1177_ext.nbytes // 4))],
                      device_offset=long(np.int32(0)), is_blocking=synchronous)
    history_mem_1177 = history_mem_device_1247
    steps_950 = np.int32(steps_950_ext)
    (out_memsize_1226, out_mem_1225, out_memsize_1228,
     out_mem_1227) = self.futhark_steps(world_mem_size_1174,
                                        history_mem_size_1176, world_mem_1175,
                                        history_mem_1177, n_946, m_947,
                                        steps_950)
    out_mem_device_1248 = np.empty((n_946, m_947), dtype=ct.c_int8)
    if (out_memsize_1226 != np.int32(0)):
      cl.enqueue_copy(self.queue,
                      out_mem_device_1248[np.int32(0):(np.int32(0) + (out_memsize_1226 // 1))],
                      out_mem_1225, device_offset=long(np.int32(0)),
                      is_blocking=synchronous)
    out_mem_1225 = out_mem_device_1248
    out_mem_device_1249 = np.empty((n_946, m_947), dtype=ct.c_int32)
    if (out_memsize_1228 != np.int32(0)):
      cl.enqueue_copy(self.queue,
                      out_mem_device_1249[np.int32(0):(np.int32(0) + (out_memsize_1228 // 4))],
                      out_mem_1227, device_offset=long(np.int32(0)),
                      is_blocking=synchronous)
    out_mem_1227 = out_mem_device_1249
    return (out_mem_1225, out_mem_1227)