import sys
import numpy as np
import ctypes as ct
import pyopencl as cl
import time
import argparse
FUT_BLOCK_DIM = "16"
cl_group_size = np.int32(512)
synchronous = False
fut_opencl_src = """typedef char int8_t;
typedef short int16_t;
typedef int int32_t;
typedef long int64_t;
typedef uchar uint8_t;
typedef ushort uint16_t;
typedef uint uint32_t;
typedef ulong uint64_t;
static inline int8_t add8(int8_t x, int8_t y)
{
    return x + y;
}
static inline int16_t add16(int16_t x, int16_t y)
{
    return x + y;
}
static inline int32_t add32(int32_t x, int32_t y)
{
    return x + y;
}
static inline int64_t add64(int64_t x, int64_t y)
{
    return x + y;
}
static inline int8_t sub8(int8_t x, int8_t y)
{
    return x - y;
}
static inline int16_t sub16(int16_t x, int16_t y)
{
    return x - y;
}
static inline int32_t sub32(int32_t x, int32_t y)
{
    return x - y;
}
static inline int64_t sub64(int64_t x, int64_t y)
{
    return x - y;
}
static inline int8_t mul8(int8_t x, int8_t y)
{
    return x * y;
}
static inline int16_t mul16(int16_t x, int16_t y)
{
    return x * y;
}
static inline int32_t mul32(int32_t x, int32_t y)
{
    return x * y;
}
static inline int64_t mul64(int64_t x, int64_t y)
{
    return x * y;
}
static inline uint8_t udiv8(uint8_t x, uint8_t y)
{
    return x / y;
}
static inline uint16_t udiv16(uint16_t x, uint16_t y)
{
    return x / y;
}
static inline uint32_t udiv32(uint32_t x, uint32_t y)
{
    return x / y;
}
static inline uint64_t udiv64(uint64_t x, uint64_t y)
{
    return x / y;
}
static inline uint8_t umod8(uint8_t x, uint8_t y)
{
    return x % y;
}
static inline uint16_t umod16(uint16_t x, uint16_t y)
{
    return x % y;
}
static inline uint32_t umod32(uint32_t x, uint32_t y)
{
    return x % y;
}
static inline uint64_t umod64(uint64_t x, uint64_t y)
{
    return x % y;
}
static inline int8_t sdiv8(int8_t x, int8_t y)
{
    int8_t q = x / y;
    int8_t r = x % y;
    
    return q - ((r != 0 && r < 0 != y < 0) ? 1 : 0);
}
static inline int16_t sdiv16(int16_t x, int16_t y)
{
    int16_t q = x / y;
    int16_t r = x % y;
    
    return q - ((r != 0 && r < 0 != y < 0) ? 1 : 0);
}
static inline int32_t sdiv32(int32_t x, int32_t y)
{
    int32_t q = x / y;
    int32_t r = x % y;
    
    return q - ((r != 0 && r < 0 != y < 0) ? 1 : 0);
}
static inline int64_t sdiv64(int64_t x, int64_t y)
{
    int64_t q = x / y;
    int64_t r = x % y;
    
    return q - ((r != 0 && r < 0 != y < 0) ? 1 : 0);
}
static inline int8_t smod8(int8_t x, int8_t y)
{
    int8_t r = x % y;
    
    return r + (r == 0 || (x > 0 && y > 0) || (x < 0 && y < 0) ? 0 : y);
}
static inline int16_t smod16(int16_t x, int16_t y)
{
    int16_t r = x % y;
    
    return r + (r == 0 || (x > 0 && y > 0) || (x < 0 && y < 0) ? 0 : y);
}
static inline int32_t smod32(int32_t x, int32_t y)
{
    int32_t r = x % y;
    
    return r + (r == 0 || (x > 0 && y > 0) || (x < 0 && y < 0) ? 0 : y);
}
static inline int64_t smod64(int64_t x, int64_t y)
{
    int64_t r = x % y;
    
    return r + (r == 0 || (x > 0 && y > 0) || (x < 0 && y < 0) ? 0 : y);
}
static inline int8_t squot8(int8_t x, int8_t y)
{
    return x / y;
}
static inline int16_t squot16(int16_t x, int16_t y)
{
    return x / y;
}
static inline int32_t squot32(int32_t x, int32_t y)
{
    return x / y;
}
static inline int64_t squot64(int64_t x, int64_t y)
{
    return x / y;
}
static inline int8_t srem8(int8_t x, int8_t y)
{
    return x % y;
}
static inline int16_t srem16(int16_t x, int16_t y)
{
    return x % y;
}
static inline int32_t srem32(int32_t x, int32_t y)
{
    return x % y;
}
static inline int64_t srem64(int64_t x, int64_t y)
{
    return x % y;
}
static inline uint8_t shl8(uint8_t x, uint8_t y)
{
    return x << y;
}
static inline uint16_t shl16(uint16_t x, uint16_t y)
{
    return x << y;
}
static inline uint32_t shl32(uint32_t x, uint32_t y)
{
    return x << y;
}
static inline uint64_t shl64(uint64_t x, uint64_t y)
{
    return x << y;
}
static inline uint8_t lshr8(uint8_t x, uint8_t y)
{
    return x >> y;
}
static inline uint16_t lshr16(uint16_t x, uint16_t y)
{
    return x >> y;
}
static inline uint32_t lshr32(uint32_t x, uint32_t y)
{
    return x >> y;
}
static inline uint64_t lshr64(uint64_t x, uint64_t y)
{
    return x >> y;
}
static inline int8_t ashr8(int8_t x, int8_t y)
{
    return x >> y;
}
static inline int16_t ashr16(int16_t x, int16_t y)
{
    return x >> y;
}
static inline int32_t ashr32(int32_t x, int32_t y)
{
    return x >> y;
}
static inline int64_t ashr64(int64_t x, int64_t y)
{
    return x >> y;
}
static inline uint8_t and8(uint8_t x, uint8_t y)
{
    return x & y;
}
static inline uint16_t and16(uint16_t x, uint16_t y)
{
    return x & y;
}
static inline uint32_t and32(uint32_t x, uint32_t y)
{
    return x & y;
}
static inline uint64_t and64(uint64_t x, uint64_t y)
{
    return x & y;
}
static inline uint8_t or8(uint8_t x, uint8_t y)
{
    return x | y;
}
static inline uint16_t or16(uint16_t x, uint16_t y)
{
    return x | y;
}
static inline uint32_t or32(uint32_t x, uint32_t y)
{
    return x | y;
}
static inline uint64_t or64(uint64_t x, uint64_t y)
{
    return x | y;
}
static inline uint8_t xor8(uint8_t x, uint8_t y)
{
    return x ^ y;
}
static inline uint16_t xor16(uint16_t x, uint16_t y)
{
    return x ^ y;
}
static inline uint32_t xor32(uint32_t x, uint32_t y)
{
    return x ^ y;
}
static inline uint64_t xor64(uint64_t x, uint64_t y)
{
    return x ^ y;
}
static inline char ult8(uint8_t x, uint8_t y)
{
    return x < y;
}
static inline char ult16(uint16_t x, uint16_t y)
{
    return x < y;
}
static inline char ult32(uint32_t x, uint32_t y)
{
    return x < y;
}
static inline char ult64(uint64_t x, uint64_t y)
{
    return x < y;
}
static inline char ule8(uint8_t x, uint8_t y)
{
    return x <= y;
}
static inline char ule16(uint16_t x, uint16_t y)
{
    return x <= y;
}
static inline char ule32(uint32_t x, uint32_t y)
{
    return x <= y;
}
static inline char ule64(uint64_t x, uint64_t y)
{
    return x <= y;
}
static inline char slt8(int8_t x, int8_t y)
{
    return x < y;
}
static inline char slt16(int16_t x, int16_t y)
{
    return x < y;
}
static inline char slt32(int32_t x, int32_t y)
{
    return x < y;
}
static inline char slt64(int64_t x, int64_t y)
{
    return x < y;
}
static inline char sle8(int8_t x, int8_t y)
{
    return x <= y;
}
static inline char sle16(int16_t x, int16_t y)
{
    return x <= y;
}
static inline char sle32(int32_t x, int32_t y)
{
    return x <= y;
}
static inline char sle64(int64_t x, int64_t y)
{
    return x <= y;
}
static inline int8_t pow8(int8_t x, int8_t y)
{
    int8_t res = 1, rem = y;
    
    while (rem != 0) {
        if (rem & 1)
            res *= x;
        rem >>= 1;
        x *= x;
    }
    return res;
}
static inline int16_t pow16(int16_t x, int16_t y)
{
    int16_t res = 1, rem = y;
    
    while (rem != 0) {
        if (rem & 1)
            res *= x;
        rem >>= 1;
        x *= x;
    }
    return res;
}
static inline int32_t pow32(int32_t x, int32_t y)
{
    int32_t res = 1, rem = y;
    
    while (rem != 0) {
        if (rem & 1)
            res *= x;
        rem >>= 1;
        x *= x;
    }
    return res;
}
static inline int64_t pow64(int64_t x, int64_t y)
{
    int64_t res = 1, rem = y;
    
    while (rem != 0) {
        if (rem & 1)
            res *= x;
        rem >>= 1;
        x *= x;
    }
    return res;
}
static inline int8_t sext_i8_i8(int8_t x)
{
    return x;
}
static inline int16_t sext_i8_i16(int8_t x)
{
    return x;
}
static inline int32_t sext_i8_i32(int8_t x)
{
    return x;
}
static inline int64_t sext_i8_i64(int8_t x)
{
    return x;
}
static inline int8_t sext_i16_i8(int16_t x)
{
    return x;
}
static inline int16_t sext_i16_i16(int16_t x)
{
    return x;
}
static inline int32_t sext_i16_i32(int16_t x)
{
    return x;
}
static inline int64_t sext_i16_i64(int16_t x)
{
    return x;
}
static inline int8_t sext_i32_i8(int32_t x)
{
    return x;
}
static inline int16_t sext_i32_i16(int32_t x)
{
    return x;
}
static inline int32_t sext_i32_i32(int32_t x)
{
    return x;
}
static inline int64_t sext_i32_i64(int32_t x)
{
    return x;
}
static inline int8_t sext_i64_i8(int64_t x)
{
    return x;
}
static inline int16_t sext_i64_i16(int64_t x)
{
    return x;
}
static inline int32_t sext_i64_i32(int64_t x)
{
    return x;
}
static inline int64_t sext_i64_i64(int64_t x)
{
    return x;
}
static inline uint8_t zext_i8_i8(uint8_t x)
{
    return x;
}
static inline uint16_t zext_i8_i16(uint8_t x)
{
    return x;
}
static inline uint32_t zext_i8_i32(uint8_t x)
{
    return x;
}
static inline uint64_t zext_i8_i64(uint8_t x)
{
    return x;
}
static inline uint8_t zext_i16_i8(uint16_t x)
{
    return x;
}
static inline uint16_t zext_i16_i16(uint16_t x)
{
    return x;
}
static inline uint32_t zext_i16_i32(uint16_t x)
{
    return x;
}
static inline uint64_t zext_i16_i64(uint16_t x)
{
    return x;
}
static inline uint8_t zext_i32_i8(uint32_t x)
{
    return x;
}
static inline uint16_t zext_i32_i16(uint32_t x)
{
    return x;
}
static inline uint32_t zext_i32_i32(uint32_t x)
{
    return x;
}
static inline uint64_t zext_i32_i64(uint32_t x)
{
    return x;
}
static inline uint8_t zext_i64_i8(uint64_t x)
{
    return x;
}
static inline uint16_t zext_i64_i16(uint64_t x)
{
    return x;
}
static inline uint32_t zext_i64_i32(uint64_t x)
{
    return x;
}
static inline uint64_t zext_i64_i64(uint64_t x)
{
    return x;
}
static inline float fdiv32(float x, float y)
{
    return x / y;
}
static inline float fadd32(float x, float y)
{
    return x + y;
}
static inline float fsub32(float x, float y)
{
    return x - y;
}
static inline float fmul32(float x, float y)
{
    return x * y;
}
static inline float fpow32(float x, float y)
{
    return pow(x, y);
}
static inline char cmplt32(float x, float y)
{
    return x < y;
}
static inline char cmple32(float x, float y)
{
    return x <= y;
}
static inline float sitofp_i8_f32(int8_t x)
{
    return x;
}
static inline float sitofp_i16_f32(int16_t x)
{
    return x;
}
static inline float sitofp_i32_f32(int32_t x)
{
    return x;
}
static inline float sitofp_i64_f32(int64_t x)
{
    return x;
}
static inline float uitofp_i8_f32(uint8_t x)
{
    return x;
}
static inline float uitofp_i16_f32(uint16_t x)
{
    return x;
}
static inline float uitofp_i32_f32(uint32_t x)
{
    return x;
}
static inline float uitofp_i64_f32(uint64_t x)
{
    return x;
}
static inline int8_t fptosi_f32_i8(float x)
{
    return x;
}
static inline int16_t fptosi_f32_i16(float x)
{
    return x;
}
static inline int32_t fptosi_f32_i32(float x)
{
    return x;
}
static inline int64_t fptosi_f32_i64(float x)
{
    return x;
}
static inline uint8_t fptoui_f32_i8(float x)
{
    return x;
}
static inline uint16_t fptoui_f32_i16(float x)
{
    return x;
}
static inline uint32_t fptoui_f32_i32(float x)
{
    return x;
}
static inline uint64_t fptoui_f32_i64(float x)
{
    return x;
}
__kernel void map_kernel_38211(int32_t g_30887, __global
                               unsigned char *mem_38123)
{
    const uint global_thread_index_38211 = get_global_id(0);
    
    if (global_thread_index_38211 >= g_30887)
        return;
    
    int32_t i_38212;
    
    // compute thread index
    {
        i_38212 = global_thread_index_38211;
    }
    // read kernel parameters
    { }
    // write kernel result
    {
        *(__global float *) &mem_38123[i_38212 * 4] = 0.0F;
    }
}
__kernel void map_kernel_38215(__global unsigned char *mem_38123,
                               int32_t g_30887, __global
                               unsigned char *mem_38126)
{
    const uint global_thread_index_38215 = get_global_id(0);
    
    if (global_thread_index_38215 >= g_30887 * g_30887)
        return;
    
    int32_t i_38216;
    int32_t j_38217;
    float input_38218;
    
    // compute thread index
    {
        i_38216 = squot32(global_thread_index_38215, g_30887);
        j_38217 = global_thread_index_38215 - squot32(global_thread_index_38215,
                                                      g_30887) * g_30887;
    }
    // read kernel parameters
    {
        input_38218 = *(__global float *) &mem_38123[j_38217 * 4];
    }
    // write kernel result
    {
        *(__global float *) &mem_38126[(i_38216 * g_30887 + j_38217) * 4] =
            input_38218;
    }
}
__kernel void map_kernel_35236(char eq_x_z_30920, float res_30900,
                               char eq_x_z_30916, char eq_x_y_30924, __global
                               unsigned char *S1_mem_38128, int32_t res_30909,
                               __global unsigned char *U0_mem_38117,
                               int32_t y_30914, char eq_x_y_30922,
                               float arg_30902, char eq_x_y_30918,
                               int32_t arg_30895, int32_t x_30903,
                               int32_t g_30887, __global
                               unsigned char *mem_38130)
{
    const uint kernel_thread_index_35236 = get_global_id(0);
    
    if (kernel_thread_index_35236 >= x_30903)
        return;
    
    int32_t i_35237;
    
    // compute thread index
    {
        i_35237 = kernel_thread_index_35236;
    }
    // read kernel parameters
    { }
    
    int32_t res_35239 = sdiv32(i_35237, g_30887);
    int32_t res_35240 = smod32(i_35237, g_30887);
    char x_35241 = sle32(1, res_35239);
    char y_35242 = sle32(res_35239, arg_30895);
    char x_35243 = x_35241 && y_35242;
    char y_35244 = sle32(1, res_35240);
    char x_35245 = x_35243 && y_35244;
    char y_35246 = sle32(res_35240, arg_30895);
    char res_35247 = x_35245 && y_35246;
    int32_t i_35248 = res_35239 - 1;
    int32_t i_35249 = res_35239 + 1;
    int32_t i_35250 = res_35240 - 1;
    int32_t i_35251 = res_35240 + 1;
    float res_35423;
    
    if (res_35247) {
        float x_35252 = *(__global float *) &U0_mem_38117[(res_35239 * g_30887 +
                                                           res_35240) * 4];
        float x_35253 = *(__global float *) &S1_mem_38128[(i_35248 * g_30887 +
                                                           res_35240) * 4];
        float y_35254 = *(__global float *) &S1_mem_38128[(i_35249 * g_30887 +
                                                           res_35240) * 4];
        float x_35255 = x_35253 + y_35254;
        float y_35256 = *(__global float *) &S1_mem_38128[(res_35239 * g_30887 +
                                                           i_35250) * 4];
        float x_35257 = x_35255 + y_35256;
        float y_35258 = *(__global float *) &S1_mem_38128[(res_35239 * g_30887 +
                                                           i_35251) * 4];
        float y_35259 = x_35257 + y_35258;
        float y_35260 = res_30900 * y_35259;
        float x_35261 = x_35252 + y_35260;
        float res_35262 = x_35261 / arg_30902;
        
        res_35423 = res_35262;
    } else {
        int32_t arg_35263 = sdiv32(res_35239, res_30909);
        int32_t arg_35264 = sdiv32(res_35240, res_30909);
        int32_t arg_35265 = sdiv32(1, res_30909);
        char x_35266 = arg_35263 == 0;
        char y_35267 = arg_35263 == y_30914;
        char x_35268 = x_35266 || y_35267;
        char x_35269 = arg_35264 == 0;
        char y_35270 = arg_35264 == y_30914;
        char y_35271 = x_35269 || y_35270;
        char res_35272 = x_35268 && y_35271;
        char cond_35273 = x_35266 && x_35269;
        char cond_35274 = x_35266 && y_35270;
        char cond_35275 = y_35267 && x_35269;
        int32_t res_35276;
        int32_t res_35277;
        
        if (cond_35275) {
            res_35276 = 1;
            res_35277 = 0;
        } else {
            res_35276 = arg_30895;
            res_35277 = y_30914;
        }
        
        int32_t res_35278;
        int32_t res_35279;
        int32_t res_35280;
        int32_t res_35281;
        
        if (cond_35274) {
            res_35278 = 1;
            res_35279 = y_30914;
            res_35280 = 0;
            res_35281 = arg_30895;
        } else {
            res_35278 = arg_30895;
            res_35279 = res_35277;
            res_35280 = y_30914;
            res_35281 = res_35276;
        }
        
        int32_t res_35282;
        int32_t res_35283;
        int32_t res_35284;
        int32_t res_35285;
        
        if (cond_35273) {
            res_35282 = 1;
            res_35283 = 0;
            res_35284 = 0;
            res_35285 = 1;
        } else {
            res_35282 = res_35278;
            res_35283 = res_35279;
            res_35284 = res_35280;
            res_35285 = res_35281;
        }
        
        char not_p_35286 = !cond_35274;
        char p_and_eq_x_y_35287 = not_p_35286 && eq_x_z_30916;
        char not_p_35288 = !cond_35273;
        char p_and_eq_x_y_35289 = not_p_35288 && p_and_eq_x_y_35287;
        char cond_35290 = arg_35265 == 1;
        float res_35291;
        
        if (cond_35290) {
            res_35291 = -1.0F;
        } else {
            res_35291 = 1.0F;
        }
        
        char p_and_eq_x_y_35292 = cond_35274 && eq_x_y_30918;
        char p_and_eq_x_y_35293 = not_p_35286 && eq_x_z_30920;
        char eq_x_z_35294 = p_and_eq_x_y_35292 || p_and_eq_x_y_35293;
        char p_and_eq_x_y_35295 = cond_35273 && eq_x_y_30918;
        char p_and_eq_x_y_35296 = not_p_35288 && eq_x_z_35294;
        char cond_35297 = p_and_eq_x_y_35295 || p_and_eq_x_y_35296;
        char not_p_35298 = !cond_35275;
        char p_and_eq_x_y_35299 = not_p_35298 && eq_x_y_30922;
        char eq_x_z_35300 = cond_35275 || p_and_eq_x_y_35299;
        char p_and_eq_x_y_35301 = cond_35274 && eq_x_y_30922;
        char p_and_eq_x_y_35302 = not_p_35286 && eq_x_z_35300;
        char eq_x_z_35303 = p_and_eq_x_y_35301 || p_and_eq_x_y_35302;
        char p_and_eq_x_y_35304 = not_p_35288 && eq_x_z_35303;
        char cond_35305 = cond_35273 || p_and_eq_x_y_35304;
        char cond_35306 = arg_35265 == 2;
        float res_35307;
        
        if (cond_35306) {
            res_35307 = -1.0F;
        } else {
            res_35307 = 1.0F;
        }
        
        char p_and_eq_x_y_35308 = cond_35275 && eq_x_y_30924;
        char eq_x_z_35309 = p_and_eq_x_y_35308 || not_p_35298;
        char p_and_eq_x_y_35310 = not_p_35286 && eq_x_z_35309;
        char eq_x_z_35311 = cond_35274 || p_and_eq_x_y_35310;
        char p_and_eq_x_y_35312 = cond_35273 && eq_x_y_30924;
        char p_and_eq_x_y_35313 = not_p_35288 && eq_x_z_35311;
        char cond_35314 = p_and_eq_x_y_35312 || p_and_eq_x_y_35313;
        int32_t res_35315;
        int32_t res_35316;
        float res_35317;
        
        if (cond_35314) {
            res_35315 = res_35282;
            res_35316 = arg_30895;
            res_35317 = res_35307;
        } else {
            res_35315 = 0;
            res_35316 = 0;
            res_35317 = 0.0F;
        }
        
        int32_t res_35318;
        int32_t res_35319;
        float res_35320;
        
        if (cond_35305) {
            res_35318 = res_35282;
            res_35319 = 1;
            res_35320 = res_35307;
        } else {
            res_35318 = res_35315;
            res_35319 = res_35316;
            res_35320 = res_35317;
        }
        
        int32_t res_35321;
        int32_t res_35322;
        float res_35323;
        
        if (cond_35297) {
            res_35321 = arg_30895;
            res_35322 = res_35283;
            res_35323 = res_35291;
        } else {
            res_35321 = res_35318;
            res_35322 = res_35319;
            res_35323 = res_35320;
        }
        
        int32_t res_35324;
        int32_t res_35325;
        float res_35326;
        
        if (p_and_eq_x_y_35289) {
            res_35324 = 1;
            res_35325 = res_35283;
            res_35326 = res_35291;
        } else {
            res_35324 = res_35321;
            res_35325 = res_35322;
            res_35326 = res_35323;
        }
        
        int32_t i_35327 = res_35324 - 1;
        int32_t i_35328 = res_35324 + 1;
        int32_t i_35329 = res_35325 - 1;
        int32_t i_35330 = res_35325 + 1;
        char p_and_eq_x_y_35331 = not_p_35286 && eq_x_y_30922;
        char eq_x_z_35332 = cond_35274 || p_and_eq_x_y_35331;
        char p_and_eq_x_y_35333 = not_p_35288 && eq_x_z_35332;
        char cond_35334 = cond_35273 || p_and_eq_x_y_35333;
        char p_and_eq_x_y_35335 = cond_35274 && eq_x_y_30924;
        char eq_x_z_35336 = p_and_eq_x_y_35335 || not_p_35286;
        char p_and_eq_x_y_35337 = not_p_35288 && eq_x_z_35336;
        char cond_35338 = p_and_eq_x_y_35312 || p_and_eq_x_y_35337;
        char p_and_eq_x_y_35339 = not_p_35298 && eq_x_z_30916;
        char p_and_eq_x_y_35340 = cond_35274 && eq_x_z_30916;
        char p_and_eq_x_y_35341 = not_p_35286 && p_and_eq_x_y_35339;
        char eq_x_z_35342 = p_and_eq_x_y_35340 || p_and_eq_x_y_35341;
        char p_and_eq_x_y_35343 = not_p_35288 && eq_x_z_35342;
        char p_and_eq_x_y_35344 = cond_35275 && eq_x_y_30918;
        char p_and_eq_x_y_35345 = not_p_35298 && eq_x_z_30920;
        char eq_x_z_35346 = p_and_eq_x_y_35344 || p_and_eq_x_y_35345;
        char p_and_eq_x_y_35347 = cond_35274 && eq_x_z_30920;
        char p_and_eq_x_y_35348 = not_p_35286 && eq_x_z_35346;
        char eq_x_z_35349 = p_and_eq_x_y_35347 || p_and_eq_x_y_35348;
        char p_and_eq_x_y_35350 = not_p_35288 && eq_x_z_35349;
        char cond_35351 = p_and_eq_x_y_35295 || p_and_eq_x_y_35350;
        int32_t res_35352;
        int32_t res_35353;
        float res_35354;
        
        if (cond_35351) {
            res_35352 = res_35284;
            res_35353 = arg_30895;
            res_35354 = res_35307;
        } else {
            res_35352 = 0;
            res_35353 = 0;
            res_35354 = 0.0F;
        }
        
        int32_t res_35355;
        int32_t res_35356;
        float res_35357;
        
        if (p_and_eq_x_y_35343) {
            res_35355 = res_35284;
            res_35356 = 1;
            res_35357 = res_35307;
        } else {
            res_35355 = res_35352;
            res_35356 = res_35353;
            res_35357 = res_35354;
        }
        
        int32_t res_35358;
        int32_t res_35359;
        float res_35360;
        
        if (cond_35338) {
            res_35358 = arg_30895;
            res_35359 = res_35285;
            res_35360 = res_35291;
        } else {
            res_35358 = res_35355;
            res_35359 = res_35356;
            res_35360 = res_35357;
        }
        
        int32_t res_35361;
        int32_t res_35362;
        float res_35363;
        
        if (cond_35334) {
            res_35361 = 1;
            res_35362 = res_35285;
            res_35363 = res_35291;
        } else {
            res_35361 = res_35358;
            res_35362 = res_35359;
            res_35363 = res_35360;
        }
        
        int32_t i_35364 = res_35361 - 1;
        int32_t i_35365 = res_35361 + 1;
        int32_t i_35366 = res_35362 - 1;
        int32_t i_35367 = res_35362 + 1;
        int32_t res_35368;
        int32_t res_35369;
        float res_35370;
        
        if (y_35270) {
            res_35368 = arg_35263;
            res_35369 = arg_30895;
            res_35370 = res_35307;
        } else {
            res_35368 = 0;
            res_35369 = 0;
            res_35370 = 0.0F;
        }
        
        int32_t res_35371;
        int32_t res_35372;
        float res_35373;
        
        if (x_35269) {
            res_35371 = arg_35263;
            res_35372 = 1;
            res_35373 = res_35307;
        } else {
            res_35371 = res_35368;
            res_35372 = res_35369;
            res_35373 = res_35370;
        }
        
        int32_t res_35374;
        int32_t res_35375;
        float res_35376;
        
        if (y_35267) {
            res_35374 = arg_30895;
            res_35375 = arg_35264;
            res_35376 = res_35291;
        } else {
            res_35374 = res_35371;
            res_35375 = res_35372;
            res_35376 = res_35373;
        }
        
        int32_t res_35377;
        int32_t res_35378;
        float res_35379;
        
        if (x_35266) {
            res_35377 = 1;
            res_35378 = arg_35264;
            res_35379 = res_35291;
        } else {
            res_35377 = res_35374;
            res_35378 = res_35375;
            res_35379 = res_35376;
        }
        
        int32_t i_35380 = res_35377 - 1;
        int32_t i_35381 = res_35377 + 1;
        int32_t i_35382 = res_35378 - 1;
        int32_t i_35383 = res_35378 + 1;
        float res_35422;
        
        if (res_35272) {
            float x_35384 = *(__global float *) &U0_mem_38117[(res_35324 *
                                                               g_30887 +
                                                               res_35325) * 4];
            float x_35385 = *(__global float *) &S1_mem_38128[(i_35327 *
                                                               g_30887 +
                                                               res_35325) * 4];
            float y_35386 = *(__global float *) &S1_mem_38128[(i_35328 *
                                                               g_30887 +
                                                               res_35325) * 4];
            float x_35387 = x_35385 + y_35386;
            float y_35388 = *(__global float *) &S1_mem_38128[(res_35324 *
                                                               g_30887 +
                                                               i_35329) * 4];
            float x_35389 = x_35387 + y_35388;
            float y_35390 = *(__global float *) &S1_mem_38128[(res_35324 *
                                                               g_30887 +
                                                               i_35330) * 4];
            float y_35391 = x_35389 + y_35390;
            float y_35392 = res_30900 * y_35391;
            float x_35393 = x_35384 + y_35392;
            float res_35394 = x_35393 / arg_30902;
            float res_35395 = res_35326 * res_35394;
            float x_35396 = *(__global float *) &U0_mem_38117[(res_35361 *
                                                               g_30887 +
                                                               res_35362) * 4];
            float x_35397 = *(__global float *) &S1_mem_38128[(i_35364 *
                                                               g_30887 +
                                                               res_35362) * 4];
            float y_35398 = *(__global float *) &S1_mem_38128[(i_35365 *
                                                               g_30887 +
                                                               res_35362) * 4];
            float x_35399 = x_35397 + y_35398;
            float y_35400 = *(__global float *) &S1_mem_38128[(res_35361 *
                                                               g_30887 +
                                                               i_35366) * 4];
            float x_35401 = x_35399 + y_35400;
            float y_35402 = *(__global float *) &S1_mem_38128[(res_35361 *
                                                               g_30887 +
                                                               i_35367) * 4];
            float y_35403 = x_35401 + y_35402;
            float y_35404 = res_30900 * y_35403;
            float x_35405 = x_35396 + y_35404;
            float res_35406 = x_35405 / arg_30902;
            float res_35407 = res_35363 * res_35406;
            float y_35408 = res_35395 + res_35407;
            float res_35409 = 0.5F * y_35408;
            
            res_35422 = res_35409;
        } else {
            float x_35410 = *(__global float *) &U0_mem_38117[(res_35377 *
                                                               g_30887 +
                                                               res_35378) * 4];
            float x_35411 = *(__global float *) &S1_mem_38128[(i_35380 *
                                                               g_30887 +
                                                               res_35378) * 4];
            float y_35412 = *(__global float *) &S1_mem_38128[(i_35381 *
                                                               g_30887 +
                                                               res_35378) * 4];
            float x_35413 = x_35411 + y_35412;
            float y_35414 = *(__global float *) &S1_mem_38128[(res_35377 *
                                                               g_30887 +
                                                               i_35382) * 4];
            float x_35415 = x_35413 + y_35414;
            float y_35416 = *(__global float *) &S1_mem_38128[(res_35377 *
                                                               g_30887 +
                                                               i_35383) * 4];
            float y_35417 = x_35415 + y_35416;
            float y_35418 = res_30900 * y_35417;
            float x_35419 = x_35410 + y_35418;
            float res_35420 = x_35419 / arg_30902;
            float res_35421 = res_35379 * res_35420;
            
            res_35422 = res_35421;
        }
        res_35423 = res_35422;
    }
    // write kernel result
    {
        *(__global float *) &mem_38130[i_35237 * 4] = res_35423;
    }
}
__kernel void map_kernel_35426(char eq_x_z_30920, float res_30900,
                               char eq_x_z_30916, char eq_x_y_30924,
                               int32_t res_30909, int32_t y_30914,
                               char eq_x_y_30922, float arg_30902, __global
                               unsigned char *S1_mem_38134, char eq_x_y_30918,
                               int32_t arg_30895, int32_t x_30903, __global
                               unsigned char *V0_mem_38119, int32_t g_30887,
                               __global unsigned char *mem_38136)
{
    const uint kernel_thread_index_35426 = get_global_id(0);
    
    if (kernel_thread_index_35426 >= x_30903)
        return;
    
    int32_t i_35427;
    
    // compute thread index
    {
        i_35427 = kernel_thread_index_35426;
    }
    // read kernel parameters
    { }
    
    int32_t res_35429 = sdiv32(i_35427, g_30887);
    int32_t res_35430 = smod32(i_35427, g_30887);
    char x_35431 = sle32(1, res_35429);
    char y_35432 = sle32(res_35429, arg_30895);
    char x_35433 = x_35431 && y_35432;
    char y_35434 = sle32(1, res_35430);
    char x_35435 = x_35433 && y_35434;
    char y_35436 = sle32(res_35430, arg_30895);
    char res_35437 = x_35435 && y_35436;
    int32_t i_35438 = res_35429 - 1;
    int32_t i_35439 = res_35429 + 1;
    int32_t i_35440 = res_35430 - 1;
    int32_t i_35441 = res_35430 + 1;
    float res_35613;
    
    if (res_35437) {
        float x_35442 = *(__global float *) &V0_mem_38119[(res_35429 * g_30887 +
                                                           res_35430) * 4];
        float x_35443 = *(__global float *) &S1_mem_38134[(i_35438 * g_30887 +
                                                           res_35430) * 4];
        float y_35444 = *(__global float *) &S1_mem_38134[(i_35439 * g_30887 +
                                                           res_35430) * 4];
        float x_35445 = x_35443 + y_35444;
        float y_35446 = *(__global float *) &S1_mem_38134[(res_35429 * g_30887 +
                                                           i_35440) * 4];
        float x_35447 = x_35445 + y_35446;
        float y_35448 = *(__global float *) &S1_mem_38134[(res_35429 * g_30887 +
                                                           i_35441) * 4];
        float y_35449 = x_35447 + y_35448;
        float y_35450 = res_30900 * y_35449;
        float x_35451 = x_35442 + y_35450;
        float res_35452 = x_35451 / arg_30902;
        
        res_35613 = res_35452;
    } else {
        int32_t arg_35453 = sdiv32(res_35429, res_30909);
        int32_t arg_35454 = sdiv32(res_35430, res_30909);
        int32_t arg_35455 = sdiv32(2, res_30909);
        char x_35456 = arg_35453 == 0;
        char y_35457 = arg_35453 == y_30914;
        char x_35458 = x_35456 || y_35457;
        char x_35459 = arg_35454 == 0;
        char y_35460 = arg_35454 == y_30914;
        char y_35461 = x_35459 || y_35460;
        char res_35462 = x_35458 && y_35461;
        char cond_35463 = x_35456 && x_35459;
        char cond_35464 = x_35456 && y_35460;
        char cond_35465 = y_35457 && x_35459;
        int32_t res_35466;
        int32_t res_35467;
        
        if (cond_35465) {
            res_35466 = 1;
            res_35467 = 0;
        } else {
            res_35466 = arg_30895;
            res_35467 = y_30914;
        }
        
        int32_t res_35468;
        int32_t res_35469;
        int32_t res_35470;
        int32_t res_35471;
        
        if (cond_35464) {
            res_35468 = 1;
            res_35469 = y_30914;
            res_35470 = 0;
            res_35471 = arg_30895;
        } else {
            res_35468 = arg_30895;
            res_35469 = res_35467;
            res_35470 = y_30914;
            res_35471 = res_35466;
        }
        
        int32_t res_35472;
        int32_t res_35473;
        int32_t res_35474;
        int32_t res_35475;
        
        if (cond_35463) {
            res_35472 = 1;
            res_35473 = 0;
            res_35474 = 0;
            res_35475 = 1;
        } else {
            res_35472 = res_35468;
            res_35473 = res_35469;
            res_35474 = res_35470;
            res_35475 = res_35471;
        }
        
        char not_p_35476 = !cond_35464;
        char p_and_eq_x_y_35477 = not_p_35476 && eq_x_z_30916;
        char not_p_35478 = !cond_35463;
        char p_and_eq_x_y_35479 = not_p_35478 && p_and_eq_x_y_35477;
        char cond_35480 = arg_35455 == 1;
        float res_35481;
        
        if (cond_35480) {
            res_35481 = -1.0F;
        } else {
            res_35481 = 1.0F;
        }
        
        char p_and_eq_x_y_35482 = cond_35464 && eq_x_y_30918;
        char p_and_eq_x_y_35483 = not_p_35476 && eq_x_z_30920;
        char eq_x_z_35484 = p_and_eq_x_y_35482 || p_and_eq_x_y_35483;
        char p_and_eq_x_y_35485 = cond_35463 && eq_x_y_30918;
        char p_and_eq_x_y_35486 = not_p_35478 && eq_x_z_35484;
        char cond_35487 = p_and_eq_x_y_35485 || p_and_eq_x_y_35486;
        char not_p_35488 = !cond_35465;
        char p_and_eq_x_y_35489 = not_p_35488 && eq_x_y_30922;
        char eq_x_z_35490 = cond_35465 || p_and_eq_x_y_35489;
        char p_and_eq_x_y_35491 = cond_35464 && eq_x_y_30922;
        char p_and_eq_x_y_35492 = not_p_35476 && eq_x_z_35490;
        char eq_x_z_35493 = p_and_eq_x_y_35491 || p_and_eq_x_y_35492;
        char p_and_eq_x_y_35494 = not_p_35478 && eq_x_z_35493;
        char cond_35495 = cond_35463 || p_and_eq_x_y_35494;
        char cond_35496 = arg_35455 == 2;
        float res_35497;
        
        if (cond_35496) {
            res_35497 = -1.0F;
        } else {
            res_35497 = 1.0F;
        }
        
        char p_and_eq_x_y_35498 = cond_35465 && eq_x_y_30924;
        char eq_x_z_35499 = p_and_eq_x_y_35498 || not_p_35488;
        char p_and_eq_x_y_35500 = not_p_35476 && eq_x_z_35499;
        char eq_x_z_35501 = cond_35464 || p_and_eq_x_y_35500;
        char p_and_eq_x_y_35502 = cond_35463 && eq_x_y_30924;
        char p_and_eq_x_y_35503 = not_p_35478 && eq_x_z_35501;
        char cond_35504 = p_and_eq_x_y_35502 || p_and_eq_x_y_35503;
        int32_t res_35505;
        int32_t res_35506;
        float res_35507;
        
        if (cond_35504) {
            res_35505 = res_35472;
            res_35506 = arg_30895;
            res_35507 = res_35497;
        } else {
            res_35505 = 0;
            res_35506 = 0;
            res_35507 = 0.0F;
        }
        
        int32_t res_35508;
        int32_t res_35509;
        float res_35510;
        
        if (cond_35495) {
            res_35508 = res_35472;
            res_35509 = 1;
            res_35510 = res_35497;
        } else {
            res_35508 = res_35505;
            res_35509 = res_35506;
            res_35510 = res_35507;
        }
        
        int32_t res_35511;
        int32_t res_35512;
        float res_35513;
        
        if (cond_35487) {
            res_35511 = arg_30895;
            res_35512 = res_35473;
            res_35513 = res_35481;
        } else {
            res_35511 = res_35508;
            res_35512 = res_35509;
            res_35513 = res_35510;
        }
        
        int32_t res_35514;
        int32_t res_35515;
        float res_35516;
        
        if (p_and_eq_x_y_35479) {
            res_35514 = 1;
            res_35515 = res_35473;
            res_35516 = res_35481;
        } else {
            res_35514 = res_35511;
            res_35515 = res_35512;
            res_35516 = res_35513;
        }
        
        int32_t i_35517 = res_35514 - 1;
        int32_t i_35518 = res_35514 + 1;
        int32_t i_35519 = res_35515 - 1;
        int32_t i_35520 = res_35515 + 1;
        char p_and_eq_x_y_35521 = not_p_35476 && eq_x_y_30922;
        char eq_x_z_35522 = cond_35464 || p_and_eq_x_y_35521;
        char p_and_eq_x_y_35523 = not_p_35478 && eq_x_z_35522;
        char cond_35524 = cond_35463 || p_and_eq_x_y_35523;
        char p_and_eq_x_y_35525 = cond_35464 && eq_x_y_30924;
        char eq_x_z_35526 = p_and_eq_x_y_35525 || not_p_35476;
        char p_and_eq_x_y_35527 = not_p_35478 && eq_x_z_35526;
        char cond_35528 = p_and_eq_x_y_35502 || p_and_eq_x_y_35527;
        char p_and_eq_x_y_35529 = not_p_35488 && eq_x_z_30916;
        char p_and_eq_x_y_35530 = cond_35464 && eq_x_z_30916;
        char p_and_eq_x_y_35531 = not_p_35476 && p_and_eq_x_y_35529;
        char eq_x_z_35532 = p_and_eq_x_y_35530 || p_and_eq_x_y_35531;
        char p_and_eq_x_y_35533 = not_p_35478 && eq_x_z_35532;
        char p_and_eq_x_y_35534 = cond_35465 && eq_x_y_30918;
        char p_and_eq_x_y_35535 = not_p_35488 && eq_x_z_30920;
        char eq_x_z_35536 = p_and_eq_x_y_35534 || p_and_eq_x_y_35535;
        char p_and_eq_x_y_35537 = cond_35464 && eq_x_z_30920;
        char p_and_eq_x_y_35538 = not_p_35476 && eq_x_z_35536;
        char eq_x_z_35539 = p_and_eq_x_y_35537 || p_and_eq_x_y_35538;
        char p_and_eq_x_y_35540 = not_p_35478 && eq_x_z_35539;
        char cond_35541 = p_and_eq_x_y_35485 || p_and_eq_x_y_35540;
        int32_t res_35542;
        int32_t res_35543;
        float res_35544;
        
        if (cond_35541) {
            res_35542 = res_35474;
            res_35543 = arg_30895;
            res_35544 = res_35497;
        } else {
            res_35542 = 0;
            res_35543 = 0;
            res_35544 = 0.0F;
        }
        
        int32_t res_35545;
        int32_t res_35546;
        float res_35547;
        
        if (p_and_eq_x_y_35533) {
            res_35545 = res_35474;
            res_35546 = 1;
            res_35547 = res_35497;
        } else {
            res_35545 = res_35542;
            res_35546 = res_35543;
            res_35547 = res_35544;
        }
        
        int32_t res_35548;
        int32_t res_35549;
        float res_35550;
        
        if (cond_35528) {
            res_35548 = arg_30895;
            res_35549 = res_35475;
            res_35550 = res_35481;
        } else {
            res_35548 = res_35545;
            res_35549 = res_35546;
            res_35550 = res_35547;
        }
        
        int32_t res_35551;
        int32_t res_35552;
        float res_35553;
        
        if (cond_35524) {
            res_35551 = 1;
            res_35552 = res_35475;
            res_35553 = res_35481;
        } else {
            res_35551 = res_35548;
            res_35552 = res_35549;
            res_35553 = res_35550;
        }
        
        int32_t i_35554 = res_35551 - 1;
        int32_t i_35555 = res_35551 + 1;
        int32_t i_35556 = res_35552 - 1;
        int32_t i_35557 = res_35552 + 1;
        int32_t res_35558;
        int32_t res_35559;
        float res_35560;
        
        if (y_35460) {
            res_35558 = arg_35453;
            res_35559 = arg_30895;
            res_35560 = res_35497;
        } else {
            res_35558 = 0;
            res_35559 = 0;
            res_35560 = 0.0F;
        }
        
        int32_t res_35561;
        int32_t res_35562;
        float res_35563;
        
        if (x_35459) {
            res_35561 = arg_35453;
            res_35562 = 1;
            res_35563 = res_35497;
        } else {
            res_35561 = res_35558;
            res_35562 = res_35559;
            res_35563 = res_35560;
        }
        
        int32_t res_35564;
        int32_t res_35565;
        float res_35566;
        
        if (y_35457) {
            res_35564 = arg_30895;
            res_35565 = arg_35454;
            res_35566 = res_35481;
        } else {
            res_35564 = res_35561;
            res_35565 = res_35562;
            res_35566 = res_35563;
        }
        
        int32_t res_35567;
        int32_t res_35568;
        float res_35569;
        
        if (x_35456) {
            res_35567 = 1;
            res_35568 = arg_35454;
            res_35569 = res_35481;
        } else {
            res_35567 = res_35564;
            res_35568 = res_35565;
            res_35569 = res_35566;
        }
        
        int32_t i_35570 = res_35567 - 1;
        int32_t i_35571 = res_35567 + 1;
        int32_t i_35572 = res_35568 - 1;
        int32_t i_35573 = res_35568 + 1;
        float res_35612;
        
        if (res_35462) {
            float x_35574 = *(__global float *) &V0_mem_38119[(res_35514 *
                                                               g_30887 +
                                                               res_35515) * 4];
            float x_35575 = *(__global float *) &S1_mem_38134[(i_35517 *
                                                               g_30887 +
                                                               res_35515) * 4];
            float y_35576 = *(__global float *) &S1_mem_38134[(i_35518 *
                                                               g_30887 +
                                                               res_35515) * 4];
            float x_35577 = x_35575 + y_35576;
            float y_35578 = *(__global float *) &S1_mem_38134[(res_35514 *
                                                               g_30887 +
                                                               i_35519) * 4];
            float x_35579 = x_35577 + y_35578;
            float y_35580 = *(__global float *) &S1_mem_38134[(res_35514 *
                                                               g_30887 +
                                                               i_35520) * 4];
            float y_35581 = x_35579 + y_35580;
            float y_35582 = res_30900 * y_35581;
            float x_35583 = x_35574 + y_35582;
            float res_35584 = x_35583 / arg_30902;
            float res_35585 = res_35516 * res_35584;
            float x_35586 = *(__global float *) &V0_mem_38119[(res_35551 *
                                                               g_30887 +
                                                               res_35552) * 4];
            float x_35587 = *(__global float *) &S1_mem_38134[(i_35554 *
                                                               g_30887 +
                                                               res_35552) * 4];
            float y_35588 = *(__global float *) &S1_mem_38134[(i_35555 *
                                                               g_30887 +
                                                               res_35552) * 4];
            float x_35589 = x_35587 + y_35588;
            float y_35590 = *(__global float *) &S1_mem_38134[(res_35551 *
                                                               g_30887 +
                                                               i_35556) * 4];
            float x_35591 = x_35589 + y_35590;
            float y_35592 = *(__global float *) &S1_mem_38134[(res_35551 *
                                                               g_30887 +
                                                               i_35557) * 4];
            float y_35593 = x_35591 + y_35592;
            float y_35594 = res_30900 * y_35593;
            float x_35595 = x_35586 + y_35594;
            float res_35596 = x_35595 / arg_30902;
            float res_35597 = res_35553 * res_35596;
            float y_35598 = res_35585 + res_35597;
            float res_35599 = 0.5F * y_35598;
            
            res_35612 = res_35599;
        } else {
            float x_35600 = *(__global float *) &V0_mem_38119[(res_35567 *
                                                               g_30887 +
                                                               res_35568) * 4];
            float x_35601 = *(__global float *) &S1_mem_38134[(i_35570 *
                                                               g_30887 +
                                                               res_35568) * 4];
            float y_35602 = *(__global float *) &S1_mem_38134[(i_35571 *
                                                               g_30887 +
                                                               res_35568) * 4];
            float x_35603 = x_35601 + y_35602;
            float y_35604 = *(__global float *) &S1_mem_38134[(res_35567 *
                                                               g_30887 +
                                                               i_35572) * 4];
            float x_35605 = x_35603 + y_35604;
            float y_35606 = *(__global float *) &S1_mem_38134[(res_35567 *
                                                               g_30887 +
                                                               i_35573) * 4];
            float y_35607 = x_35605 + y_35606;
            float y_35608 = res_30900 * y_35607;
            float x_35609 = x_35600 + y_35608;
            float res_35610 = x_35609 / arg_30902;
            float res_35611 = res_35569 * res_35610;
            
            res_35612 = res_35611;
        }
        res_35613 = res_35612;
    }
    // write kernel result
    {
        *(__global float *) &mem_38136[i_35427 * 4] = res_35613;
    }
}
__kernel void map_kernel_35616(char eq_x_z_30920, __global
                               unsigned char *S1_mem_38132, char eq_x_z_30916,
                               char eq_x_y_30924, int32_t res_30909,
                               float y_31410, __global
                               unsigned char *S1_mem_38138, int32_t y_30914,
                               char eq_x_y_30922, char eq_x_y_30918,
                               int32_t arg_30895, int32_t x_30903,
                               int32_t g_30887, __global
                               unsigned char *mem_38140)
{
    const uint kernel_thread_index_35616 = get_global_id(0);
    
    if (kernel_thread_index_35616 >= x_30903)
        return;
    
    int32_t i_35617;
    
    // compute thread index
    {
        i_35617 = kernel_thread_index_35616;
    }
    // read kernel parameters
    { }
    
    int32_t res_35619 = sdiv32(i_35617, g_30887);
    int32_t res_35620 = smod32(i_35617, g_30887);
    char x_35621 = sle32(1, res_35619);
    char y_35622 = sle32(res_35619, arg_30895);
    char x_35623 = x_35621 && y_35622;
    char y_35624 = sle32(1, res_35620);
    char x_35625 = x_35623 && y_35624;
    char y_35626 = sle32(res_35620, arg_30895);
    char res_35627 = x_35625 && y_35626;
    int32_t i_35628 = res_35619 + 1;
    int32_t i_35629 = res_35619 - 1;
    int32_t i_35630 = res_35620 + 1;
    int32_t i_35631 = res_35620 - 1;
    float res_35775;
    
    if (res_35627) {
        float x_35632 = *(__global float *) &S1_mem_38132[(i_35628 * g_30887 +
                                                           res_35620) * 4];
        float y_35633 = *(__global float *) &S1_mem_38132[(i_35629 * g_30887 +
                                                           res_35620) * 4];
        float x_35634 = x_35632 - y_35633;
        float y_35635 = *(__global float *) &S1_mem_38138[(res_35619 * g_30887 +
                                                           i_35630) * 4];
        float x_35636 = x_35634 + y_35635;
        float y_35637 = *(__global float *) &S1_mem_38138[(res_35619 * g_30887 +
                                                           i_35631) * 4];
        float y_35638 = x_35636 - y_35637;
        float x_35639 = -0.5F * y_35638;
        float res_35640 = x_35639 / y_31410;
        
        res_35775 = res_35640;
    } else {
        int32_t arg_35641 = sdiv32(res_35619, res_30909);
        int32_t arg_35642 = sdiv32(res_35620, res_30909);
        char x_35643 = arg_35641 == 0;
        char y_35644 = arg_35641 == y_30914;
        char x_35645 = x_35643 || y_35644;
        char x_35646 = arg_35642 == 0;
        char y_35647 = arg_35642 == y_30914;
        char y_35648 = x_35646 || y_35647;
        char res_35649 = x_35645 && y_35648;
        char cond_35650 = x_35643 && x_35646;
        char cond_35651 = x_35643 && y_35647;
        char cond_35652 = y_35644 && x_35646;
        int32_t res_35653;
        int32_t res_35654;
        
        if (cond_35652) {
            res_35653 = 1;
            res_35654 = 0;
        } else {
            res_35653 = arg_30895;
            res_35654 = y_30914;
        }
        
        int32_t res_35655;
        int32_t res_35656;
        int32_t res_35657;
        int32_t res_35658;
        
        if (cond_35651) {
            res_35655 = 1;
            res_35656 = y_30914;
            res_35657 = 0;
            res_35658 = arg_30895;
        } else {
            res_35655 = arg_30895;
            res_35656 = res_35654;
            res_35657 = y_30914;
            res_35658 = res_35653;
        }
        
        int32_t res_35659;
        int32_t res_35660;
        int32_t res_35661;
        int32_t res_35662;
        
        if (cond_35650) {
            res_35659 = 1;
            res_35660 = 0;
            res_35661 = 0;
            res_35662 = 1;
        } else {
            res_35659 = res_35655;
            res_35660 = res_35656;
            res_35661 = res_35657;
            res_35662 = res_35658;
        }
        
        char not_p_35663 = !cond_35651;
        char p_and_eq_x_y_35664 = not_p_35663 && eq_x_z_30916;
        char not_p_35665 = !cond_35650;
        char p_and_eq_x_y_35666 = not_p_35665 && p_and_eq_x_y_35664;
        char p_and_eq_x_y_35667 = cond_35651 && eq_x_y_30918;
        char p_and_eq_x_y_35668 = not_p_35663 && eq_x_z_30920;
        char eq_x_z_35669 = p_and_eq_x_y_35667 || p_and_eq_x_y_35668;
        char p_and_eq_x_y_35670 = cond_35650 && eq_x_y_30918;
        char p_and_eq_x_y_35671 = not_p_35665 && eq_x_z_35669;
        char cond_35672 = p_and_eq_x_y_35670 || p_and_eq_x_y_35671;
        char not_p_35673 = !cond_35652;
        char p_and_eq_x_y_35674 = not_p_35673 && eq_x_y_30922;
        char eq_x_z_35675 = cond_35652 || p_and_eq_x_y_35674;
        char p_and_eq_x_y_35676 = cond_35651 && eq_x_y_30922;
        char p_and_eq_x_y_35677 = not_p_35663 && eq_x_z_35675;
        char eq_x_z_35678 = p_and_eq_x_y_35676 || p_and_eq_x_y_35677;
        char p_and_eq_x_y_35679 = not_p_35665 && eq_x_z_35678;
        char cond_35680 = cond_35650 || p_and_eq_x_y_35679;
        char p_and_eq_x_y_35681 = cond_35652 && eq_x_y_30924;
        char eq_x_z_35682 = p_and_eq_x_y_35681 || not_p_35673;
        char p_and_eq_x_y_35683 = not_p_35663 && eq_x_z_35682;
        char eq_x_z_35684 = cond_35651 || p_and_eq_x_y_35683;
        char p_and_eq_x_y_35685 = cond_35650 && eq_x_y_30924;
        char p_and_eq_x_y_35686 = not_p_35665 && eq_x_z_35684;
        char cond_35687 = p_and_eq_x_y_35685 || p_and_eq_x_y_35686;
        int32_t res_35688;
        int32_t res_35689;
        
        if (cond_35687) {
            res_35688 = res_35659;
            res_35689 = arg_30895;
        } else {
            res_35688 = 0;
            res_35689 = 0;
        }
        
        int32_t res_35690;
        int32_t res_35691;
        
        if (cond_35680) {
            res_35690 = res_35659;
            res_35691 = 1;
        } else {
            res_35690 = res_35688;
            res_35691 = res_35689;
        }
        
        int32_t res_35692;
        int32_t res_35693;
        
        if (cond_35672) {
            res_35692 = arg_30895;
            res_35693 = res_35660;
        } else {
            res_35692 = res_35690;
            res_35693 = res_35691;
        }
        
        int32_t res_35694;
        int32_t res_35695;
        
        if (p_and_eq_x_y_35666) {
            res_35694 = 1;
            res_35695 = res_35660;
        } else {
            res_35694 = res_35692;
            res_35695 = res_35693;
        }
        
        int32_t i_35696 = res_35694 + 1;
        int32_t i_35697 = res_35694 - 1;
        int32_t i_35698 = res_35695 + 1;
        int32_t i_35699 = res_35695 - 1;
        char p_and_eq_x_y_35700 = not_p_35663 && eq_x_y_30922;
        char eq_x_z_35701 = cond_35651 || p_and_eq_x_y_35700;
        char p_and_eq_x_y_35702 = not_p_35665 && eq_x_z_35701;
        char cond_35703 = cond_35650 || p_and_eq_x_y_35702;
        char p_and_eq_x_y_35704 = cond_35651 && eq_x_y_30924;
        char eq_x_z_35705 = p_and_eq_x_y_35704 || not_p_35663;
        char p_and_eq_x_y_35706 = not_p_35665 && eq_x_z_35705;
        char cond_35707 = p_and_eq_x_y_35685 || p_and_eq_x_y_35706;
        char p_and_eq_x_y_35708 = not_p_35673 && eq_x_z_30916;
        char p_and_eq_x_y_35709 = cond_35651 && eq_x_z_30916;
        char p_and_eq_x_y_35710 = not_p_35663 && p_and_eq_x_y_35708;
        char eq_x_z_35711 = p_and_eq_x_y_35709 || p_and_eq_x_y_35710;
        char p_and_eq_x_y_35712 = not_p_35665 && eq_x_z_35711;
        char p_and_eq_x_y_35713 = cond_35652 && eq_x_y_30918;
        char p_and_eq_x_y_35714 = not_p_35673 && eq_x_z_30920;
        char eq_x_z_35715 = p_and_eq_x_y_35713 || p_and_eq_x_y_35714;
        char p_and_eq_x_y_35716 = cond_35651 && eq_x_z_30920;
        char p_and_eq_x_y_35717 = not_p_35663 && eq_x_z_35715;
        char eq_x_z_35718 = p_and_eq_x_y_35716 || p_and_eq_x_y_35717;
        char p_and_eq_x_y_35719 = not_p_35665 && eq_x_z_35718;
        char cond_35720 = p_and_eq_x_y_35670 || p_and_eq_x_y_35719;
        int32_t res_35721;
        int32_t res_35722;
        
        if (cond_35720) {
            res_35721 = res_35661;
            res_35722 = arg_30895;
        } else {
            res_35721 = 0;
            res_35722 = 0;
        }
        
        int32_t res_35723;
        int32_t res_35724;
        
        if (p_and_eq_x_y_35712) {
            res_35723 = res_35661;
            res_35724 = 1;
        } else {
            res_35723 = res_35721;
            res_35724 = res_35722;
        }
        
        int32_t res_35725;
        int32_t res_35726;
        
        if (cond_35707) {
            res_35725 = arg_30895;
            res_35726 = res_35662;
        } else {
            res_35725 = res_35723;
            res_35726 = res_35724;
        }
        
        int32_t res_35727;
        int32_t res_35728;
        
        if (cond_35703) {
            res_35727 = 1;
            res_35728 = res_35662;
        } else {
            res_35727 = res_35725;
            res_35728 = res_35726;
        }
        
        int32_t i_35729 = res_35727 + 1;
        int32_t i_35730 = res_35727 - 1;
        int32_t i_35731 = res_35728 + 1;
        int32_t i_35732 = res_35728 - 1;
        int32_t res_35733;
        int32_t res_35734;
        
        if (y_35647) {
            res_35733 = arg_35641;
            res_35734 = arg_30895;
        } else {
            res_35733 = 0;
            res_35734 = 0;
        }
        
        int32_t res_35735;
        int32_t res_35736;
        
        if (x_35646) {
            res_35735 = arg_35641;
            res_35736 = 1;
        } else {
            res_35735 = res_35733;
            res_35736 = res_35734;
        }
        
        int32_t res_35737;
        int32_t res_35738;
        
        if (y_35644) {
            res_35737 = arg_30895;
            res_35738 = arg_35642;
        } else {
            res_35737 = res_35735;
            res_35738 = res_35736;
        }
        
        int32_t res_35739;
        int32_t res_35740;
        
        if (x_35643) {
            res_35739 = 1;
            res_35740 = arg_35642;
        } else {
            res_35739 = res_35737;
            res_35740 = res_35738;
        }
        
        int32_t i_35741 = res_35739 + 1;
        int32_t i_35742 = res_35739 - 1;
        int32_t i_35743 = res_35740 + 1;
        int32_t i_35744 = res_35740 - 1;
        float res_35774;
        
        if (res_35649) {
            float x_35745 = *(__global float *) &S1_mem_38132[(i_35696 *
                                                               g_30887 +
                                                               res_35695) * 4];
            float y_35746 = *(__global float *) &S1_mem_38132[(i_35697 *
                                                               g_30887 +
                                                               res_35695) * 4];
            float x_35747 = x_35745 - y_35746;
            float y_35748 = *(__global float *) &S1_mem_38138[(res_35694 *
                                                               g_30887 +
                                                               i_35698) * 4];
            float x_35749 = x_35747 + y_35748;
            float y_35750 = *(__global float *) &S1_mem_38138[(res_35694 *
                                                               g_30887 +
                                                               i_35699) * 4];
            float y_35751 = x_35749 - y_35750;
            float x_35752 = -0.5F * y_35751;
            float res_35753 = x_35752 / y_31410;
            float x_35754 = *(__global float *) &S1_mem_38132[(i_35729 *
                                                               g_30887 +
                                                               res_35728) * 4];
            float y_35755 = *(__global float *) &S1_mem_38132[(i_35730 *
                                                               g_30887 +
                                                               res_35728) * 4];
            float x_35756 = x_35754 - y_35755;
            float y_35757 = *(__global float *) &S1_mem_38138[(res_35727 *
                                                               g_30887 +
                                                               i_35731) * 4];
            float x_35758 = x_35756 + y_35757;
            float y_35759 = *(__global float *) &S1_mem_38138[(res_35727 *
                                                               g_30887 +
                                                               i_35732) * 4];
            float y_35760 = x_35758 - y_35759;
            float x_35761 = -0.5F * y_35760;
            float res_35762 = x_35761 / y_31410;
            float y_35763 = res_35753 + res_35762;
            float res_35764 = 0.5F * y_35763;
            
            res_35774 = res_35764;
        } else {
            float x_35765 = *(__global float *) &S1_mem_38132[(i_35741 *
                                                               g_30887 +
                                                               res_35740) * 4];
            float y_35766 = *(__global float *) &S1_mem_38132[(i_35742 *
                                                               g_30887 +
                                                               res_35740) * 4];
            float x_35767 = x_35765 - y_35766;
            float y_35768 = *(__global float *) &S1_mem_38138[(res_35739 *
                                                               g_30887 +
                                                               i_35743) * 4];
            float x_35769 = x_35767 + y_35768;
            float y_35770 = *(__global float *) &S1_mem_38138[(res_35739 *
                                                               g_30887 +
                                                               i_35744) * 4];
            float y_35771 = x_35769 - y_35770;
            float x_35772 = -0.5F * y_35771;
            float res_35773 = x_35772 / y_31410;
            
            res_35774 = res_35773;
        }
        res_35775 = res_35774;
    }
    // write kernel result
    {
        *(__global float *) &mem_38140[i_35617 * 4] = res_35775;
    }
}
__kernel void map_kernel_35778(char eq_x_z_30920, __global
                               unsigned char *mem_38140, char eq_x_z_30916,
                               char eq_x_y_30924, int32_t res_30909,
                               int32_t y_30914, char eq_x_y_30922, __global
                               unsigned char *S1_mem_38142, char eq_x_y_30918,
                               int32_t arg_30895, int32_t x_30903,
                               int32_t g_30887, __global
                               unsigned char *mem_38144)
{
    const uint kernel_thread_index_35778 = get_global_id(0);
    
    if (kernel_thread_index_35778 >= x_30903)
        return;
    
    int32_t i_35779;
    
    // compute thread index
    {
        i_35779 = kernel_thread_index_35778;
    }
    // read kernel parameters
    { }
    
    int32_t res_35781 = sdiv32(i_35779, g_30887);
    int32_t res_35782 = smod32(i_35779, g_30887);
    char x_35783 = sle32(1, res_35781);
    char y_35784 = sle32(res_35781, arg_30895);
    char x_35785 = x_35783 && y_35784;
    char y_35786 = sle32(1, res_35782);
    char x_35787 = x_35785 && y_35786;
    char y_35788 = sle32(res_35782, arg_30895);
    char res_35789 = x_35787 && y_35788;
    int32_t x_35790 = res_35781 * g_30887;
    int32_t x_35791 = x_35790 + res_35782;
    int32_t i_35792 = res_35781 - 1;
    int32_t i_35793 = res_35781 + 1;
    int32_t i_35794 = res_35782 - 1;
    int32_t i_35795 = res_35782 + 1;
    float res_35964;
    
    if (res_35789) {
        float x_35796 = *(__global float *) &mem_38140[x_35791 * 4];
        float x_35797 = *(__global float *) &S1_mem_38142[(i_35792 * g_30887 +
                                                           res_35782) * 4];
        float y_35798 = *(__global float *) &S1_mem_38142[(i_35793 * g_30887 +
                                                           res_35782) * 4];
        float x_35799 = x_35797 + y_35798;
        float y_35800 = *(__global float *) &S1_mem_38142[(res_35781 * g_30887 +
                                                           i_35794) * 4];
        float x_35801 = x_35799 + y_35800;
        float y_35802 = *(__global float *) &S1_mem_38142[(res_35781 * g_30887 +
                                                           i_35795) * 4];
        float y_35803 = x_35801 + y_35802;
        float x_35804 = x_35796 + y_35803;
        float res_35805 = x_35804 / 4.0F;
        
        res_35964 = res_35805;
    } else {
        int32_t arg_35806 = sdiv32(res_35781, res_30909);
        int32_t arg_35807 = sdiv32(res_35782, res_30909);
        char x_35808 = arg_35806 == 0;
        char y_35809 = arg_35806 == y_30914;
        char x_35810 = x_35808 || y_35809;
        char x_35811 = arg_35807 == 0;
        char y_35812 = arg_35807 == y_30914;
        char y_35813 = x_35811 || y_35812;
        char res_35814 = x_35810 && y_35813;
        char cond_35815 = x_35808 && x_35811;
        char cond_35816 = x_35808 && y_35812;
        char cond_35817 = y_35809 && x_35811;
        int32_t res_35818;
        int32_t res_35819;
        
        if (cond_35817) {
            res_35818 = 1;
            res_35819 = 0;
        } else {
            res_35818 = arg_30895;
            res_35819 = y_30914;
        }
        
        int32_t res_35820;
        int32_t res_35821;
        int32_t res_35822;
        int32_t res_35823;
        
        if (cond_35816) {
            res_35820 = 1;
            res_35821 = y_30914;
            res_35822 = 0;
            res_35823 = arg_30895;
        } else {
            res_35820 = arg_30895;
            res_35821 = res_35819;
            res_35822 = y_30914;
            res_35823 = res_35818;
        }
        
        int32_t res_35824;
        int32_t res_35825;
        int32_t res_35826;
        int32_t res_35827;
        
        if (cond_35815) {
            res_35824 = 1;
            res_35825 = 0;
            res_35826 = 0;
            res_35827 = 1;
        } else {
            res_35824 = res_35820;
            res_35825 = res_35821;
            res_35826 = res_35822;
            res_35827 = res_35823;
        }
        
        char not_p_35828 = !cond_35816;
        char p_and_eq_x_y_35829 = not_p_35828 && eq_x_z_30916;
        char not_p_35830 = !cond_35815;
        char p_and_eq_x_y_35831 = not_p_35830 && p_and_eq_x_y_35829;
        char p_and_eq_x_y_35832 = cond_35816 && eq_x_y_30918;
        char p_and_eq_x_y_35833 = not_p_35828 && eq_x_z_30920;
        char eq_x_z_35834 = p_and_eq_x_y_35832 || p_and_eq_x_y_35833;
        char p_and_eq_x_y_35835 = cond_35815 && eq_x_y_30918;
        char p_and_eq_x_y_35836 = not_p_35830 && eq_x_z_35834;
        char cond_35837 = p_and_eq_x_y_35835 || p_and_eq_x_y_35836;
        char not_p_35838 = !cond_35817;
        char p_and_eq_x_y_35839 = not_p_35838 && eq_x_y_30922;
        char eq_x_z_35840 = cond_35817 || p_and_eq_x_y_35839;
        char p_and_eq_x_y_35841 = cond_35816 && eq_x_y_30922;
        char p_and_eq_x_y_35842 = not_p_35828 && eq_x_z_35840;
        char eq_x_z_35843 = p_and_eq_x_y_35841 || p_and_eq_x_y_35842;
        char p_and_eq_x_y_35844 = not_p_35830 && eq_x_z_35843;
        char cond_35845 = cond_35815 || p_and_eq_x_y_35844;
        char p_and_eq_x_y_35846 = cond_35817 && eq_x_y_30924;
        char eq_x_z_35847 = p_and_eq_x_y_35846 || not_p_35838;
        char p_and_eq_x_y_35848 = not_p_35828 && eq_x_z_35847;
        char eq_x_z_35849 = cond_35816 || p_and_eq_x_y_35848;
        char p_and_eq_x_y_35850 = cond_35815 && eq_x_y_30924;
        char p_and_eq_x_y_35851 = not_p_35830 && eq_x_z_35849;
        char cond_35852 = p_and_eq_x_y_35850 || p_and_eq_x_y_35851;
        int32_t res_35853;
        int32_t res_35854;
        float res_35855;
        
        if (cond_35852) {
            res_35853 = res_35824;
            res_35854 = arg_30895;
            res_35855 = 1.0F;
        } else {
            res_35853 = 0;
            res_35854 = 0;
            res_35855 = 0.0F;
        }
        
        int32_t res_35856;
        int32_t res_35857;
        float res_35858;
        
        if (cond_35845) {
            res_35856 = res_35824;
            res_35857 = 1;
            res_35858 = 1.0F;
        } else {
            res_35856 = res_35853;
            res_35857 = res_35854;
            res_35858 = res_35855;
        }
        
        int32_t res_35859;
        int32_t res_35860;
        float res_35861;
        
        if (cond_35837) {
            res_35859 = arg_30895;
            res_35860 = res_35825;
            res_35861 = 1.0F;
        } else {
            res_35859 = res_35856;
            res_35860 = res_35857;
            res_35861 = res_35858;
        }
        
        int32_t res_35862;
        int32_t res_35863;
        float res_35864;
        
        if (p_and_eq_x_y_35831) {
            res_35862 = 1;
            res_35863 = res_35825;
            res_35864 = 1.0F;
        } else {
            res_35862 = res_35859;
            res_35863 = res_35860;
            res_35864 = res_35861;
        }
        
        int32_t x_35865 = res_35862 * g_30887;
        int32_t x_35866 = x_35865 + res_35863;
        int32_t i_35867 = res_35862 - 1;
        int32_t i_35868 = res_35862 + 1;
        int32_t i_35869 = res_35863 - 1;
        int32_t i_35870 = res_35863 + 1;
        char p_and_eq_x_y_35871 = not_p_35828 && eq_x_y_30922;
        char eq_x_z_35872 = cond_35816 || p_and_eq_x_y_35871;
        char p_and_eq_x_y_35873 = not_p_35830 && eq_x_z_35872;
        char cond_35874 = cond_35815 || p_and_eq_x_y_35873;
        char p_and_eq_x_y_35875 = cond_35816 && eq_x_y_30924;
        char eq_x_z_35876 = p_and_eq_x_y_35875 || not_p_35828;
        char p_and_eq_x_y_35877 = not_p_35830 && eq_x_z_35876;
        char cond_35878 = p_and_eq_x_y_35850 || p_and_eq_x_y_35877;
        char p_and_eq_x_y_35879 = not_p_35838 && eq_x_z_30916;
        char p_and_eq_x_y_35880 = cond_35816 && eq_x_z_30916;
        char p_and_eq_x_y_35881 = not_p_35828 && p_and_eq_x_y_35879;
        char eq_x_z_35882 = p_and_eq_x_y_35880 || p_and_eq_x_y_35881;
        char p_and_eq_x_y_35883 = not_p_35830 && eq_x_z_35882;
        char p_and_eq_x_y_35884 = cond_35817 && eq_x_y_30918;
        char p_and_eq_x_y_35885 = not_p_35838 && eq_x_z_30920;
        char eq_x_z_35886 = p_and_eq_x_y_35884 || p_and_eq_x_y_35885;
        char p_and_eq_x_y_35887 = cond_35816 && eq_x_z_30920;
        char p_and_eq_x_y_35888 = not_p_35828 && eq_x_z_35886;
        char eq_x_z_35889 = p_and_eq_x_y_35887 || p_and_eq_x_y_35888;
        char p_and_eq_x_y_35890 = not_p_35830 && eq_x_z_35889;
        char cond_35891 = p_and_eq_x_y_35835 || p_and_eq_x_y_35890;
        int32_t res_35892;
        int32_t res_35893;
        float res_35894;
        
        if (cond_35891) {
            res_35892 = res_35826;
            res_35893 = arg_30895;
            res_35894 = 1.0F;
        } else {
            res_35892 = 0;
            res_35893 = 0;
            res_35894 = 0.0F;
        }
        
        int32_t res_35895;
        int32_t res_35896;
        float res_35897;
        
        if (p_and_eq_x_y_35883) {
            res_35895 = res_35826;
            res_35896 = 1;
            res_35897 = 1.0F;
        } else {
            res_35895 = res_35892;
            res_35896 = res_35893;
            res_35897 = res_35894;
        }
        
        int32_t res_35898;
        int32_t res_35899;
        float res_35900;
        
        if (cond_35878) {
            res_35898 = arg_30895;
            res_35899 = res_35827;
            res_35900 = 1.0F;
        } else {
            res_35898 = res_35895;
            res_35899 = res_35896;
            res_35900 = res_35897;
        }
        
        int32_t res_35901;
        int32_t res_35902;
        float res_35903;
        
        if (cond_35874) {
            res_35901 = 1;
            res_35902 = res_35827;
            res_35903 = 1.0F;
        } else {
            res_35901 = res_35898;
            res_35902 = res_35899;
            res_35903 = res_35900;
        }
        
        int32_t x_35904 = res_35901 * g_30887;
        int32_t x_35905 = x_35904 + res_35902;
        int32_t i_35906 = res_35901 - 1;
        int32_t i_35907 = res_35901 + 1;
        int32_t i_35908 = res_35902 - 1;
        int32_t i_35909 = res_35902 + 1;
        int32_t res_35910;
        int32_t res_35911;
        float res_35912;
        
        if (y_35812) {
            res_35910 = arg_35806;
            res_35911 = arg_30895;
            res_35912 = 1.0F;
        } else {
            res_35910 = 0;
            res_35911 = 0;
            res_35912 = 0.0F;
        }
        
        int32_t res_35913;
        int32_t res_35914;
        float res_35915;
        
        if (x_35811) {
            res_35913 = arg_35806;
            res_35914 = 1;
            res_35915 = 1.0F;
        } else {
            res_35913 = res_35910;
            res_35914 = res_35911;
            res_35915 = res_35912;
        }
        
        int32_t res_35916;
        int32_t res_35917;
        float res_35918;
        
        if (y_35809) {
            res_35916 = arg_30895;
            res_35917 = arg_35807;
            res_35918 = 1.0F;
        } else {
            res_35916 = res_35913;
            res_35917 = res_35914;
            res_35918 = res_35915;
        }
        
        int32_t res_35919;
        int32_t res_35920;
        float res_35921;
        
        if (x_35808) {
            res_35919 = 1;
            res_35920 = arg_35807;
            res_35921 = 1.0F;
        } else {
            res_35919 = res_35916;
            res_35920 = res_35917;
            res_35921 = res_35918;
        }
        
        int32_t x_35922 = res_35919 * g_30887;
        int32_t x_35923 = x_35922 + res_35920;
        int32_t i_35924 = res_35919 - 1;
        int32_t i_35925 = res_35919 + 1;
        int32_t i_35926 = res_35920 - 1;
        int32_t i_35927 = res_35920 + 1;
        float res_35963;
        
        if (res_35814) {
            float x_35928 = *(__global float *) &mem_38140[x_35866 * 4];
            float x_35929 = *(__global float *) &S1_mem_38142[(i_35867 *
                                                               g_30887 +
                                                               res_35863) * 4];
            float y_35930 = *(__global float *) &S1_mem_38142[(i_35868 *
                                                               g_30887 +
                                                               res_35863) * 4];
            float x_35931 = x_35929 + y_35930;
            float y_35932 = *(__global float *) &S1_mem_38142[(res_35862 *
                                                               g_30887 +
                                                               i_35869) * 4];
            float x_35933 = x_35931 + y_35932;
            float y_35934 = *(__global float *) &S1_mem_38142[(res_35862 *
                                                               g_30887 +
                                                               i_35870) * 4];
            float y_35935 = x_35933 + y_35934;
            float x_35936 = x_35928 + y_35935;
            float res_35937 = x_35936 / 4.0F;
            float res_35938 = res_35864 * res_35937;
            float x_35939 = *(__global float *) &mem_38140[x_35905 * 4];
            float x_35940 = *(__global float *) &S1_mem_38142[(i_35906 *
                                                               g_30887 +
                                                               res_35902) * 4];
            float y_35941 = *(__global float *) &S1_mem_38142[(i_35907 *
                                                               g_30887 +
                                                               res_35902) * 4];
            float x_35942 = x_35940 + y_35941;
            float y_35943 = *(__global float *) &S1_mem_38142[(res_35901 *
                                                               g_30887 +
                                                               i_35908) * 4];
            float x_35944 = x_35942 + y_35943;
            float y_35945 = *(__global float *) &S1_mem_38142[(res_35901 *
                                                               g_30887 +
                                                               i_35909) * 4];
            float y_35946 = x_35944 + y_35945;
            float x_35947 = x_35939 + y_35946;
            float res_35948 = x_35947 / 4.0F;
            float res_35949 = res_35903 * res_35948;
            float y_35950 = res_35938 + res_35949;
            float res_35951 = 0.5F * y_35950;
            
            res_35963 = res_35951;
        } else {
            float x_35952 = *(__global float *) &mem_38140[x_35923 * 4];
            float x_35953 = *(__global float *) &S1_mem_38142[(i_35924 *
                                                               g_30887 +
                                                               res_35920) * 4];
            float y_35954 = *(__global float *) &S1_mem_38142[(i_35925 *
                                                               g_30887 +
                                                               res_35920) * 4];
            float x_35955 = x_35953 + y_35954;
            float y_35956 = *(__global float *) &S1_mem_38142[(res_35919 *
                                                               g_30887 +
                                                               i_35926) * 4];
            float x_35957 = x_35955 + y_35956;
            float y_35958 = *(__global float *) &S1_mem_38142[(res_35919 *
                                                               g_30887 +
                                                               i_35927) * 4];
            float y_35959 = x_35957 + y_35958;
            float x_35960 = x_35952 + y_35959;
            float res_35961 = x_35960 / 4.0F;
            float res_35962 = res_35921 * res_35961;
            
            res_35963 = res_35962;
        }
        res_35964 = res_35963;
    }
    // write kernel result
    {
        *(__global float *) &mem_38144[i_35779 * 4] = res_35964;
    }
}
__kernel void map_kernel_35967(char eq_x_z_30920, __global
                               unsigned char *S1_mem_38132, char eq_x_z_30916,
                               char eq_x_y_30924, float x_31869,
                               int32_t res_30909, __global
                               unsigned char *S1_mem_38138, __global
                               unsigned char *S1_mem_38146, int32_t y_30914,
                               char eq_x_y_30922, char eq_x_y_30918,
                               int32_t arg_30895, int32_t x_30903,
                               int32_t g_30887, __global
                               unsigned char *mem_38148, __global
                               unsigned char *mem_38150)
{
    const uint kernel_thread_index_35967 = get_global_id(0);
    
    if (kernel_thread_index_35967 >= x_30903)
        return;
    
    int32_t i_35968;
    
    // compute thread index
    {
        i_35968 = kernel_thread_index_35967;
    }
    // read kernel parameters
    { }
    
    int32_t res_35970 = sdiv32(i_35968, g_30887);
    int32_t res_35971 = smod32(i_35968, g_30887);
    char x_35972 = sle32(1, res_35970);
    char y_35973 = sle32(res_35970, arg_30895);
    char x_35974 = x_35972 && y_35973;
    char y_35975 = sle32(1, res_35971);
    char x_35976 = x_35974 && y_35975;
    char y_35977 = sle32(res_35971, arg_30895);
    char res_35978 = x_35976 && y_35977;
    int32_t i_35979 = res_35970 + 1;
    int32_t i_35980 = res_35970 + -1;
    float res_36127;
    
    if (res_35978) {
        float x_35981 = *(__global float *) &S1_mem_38132[(res_35970 * g_30887 +
                                                           res_35971) * 4];
        float x_35982 = *(__global float *) &S1_mem_38146[(i_35979 * g_30887 +
                                                           res_35971) * 4];
        float y_35983 = *(__global float *) &S1_mem_38146[(i_35980 * g_30887 +
                                                           res_35971) * 4];
        float y_35984 = x_35982 - y_35983;
        float y_35985 = x_31869 * y_35984;
        float res_35986 = x_35981 - y_35985;
        
        res_36127 = res_35986;
    } else {
        int32_t arg_35987 = sdiv32(res_35970, res_30909);
        int32_t arg_35988 = sdiv32(res_35971, res_30909);
        int32_t arg_35989 = sdiv32(1, res_30909);
        int32_t arg_35990 = sdiv32(-1, res_30909);
        char x_35991 = arg_35987 == 0;
        char y_35992 = arg_35987 == y_30914;
        char x_35993 = x_35991 || y_35992;
        char x_35994 = arg_35988 == 0;
        char y_35995 = arg_35988 == y_30914;
        char y_35996 = x_35994 || y_35995;
        char res_35997 = x_35993 && y_35996;
        char cond_35998 = x_35991 && x_35994;
        char cond_35999 = x_35991 && y_35995;
        char cond_36000 = y_35992 && x_35994;
        int32_t res_36001;
        int32_t res_36002;
        
        if (cond_36000) {
            res_36001 = 1;
            res_36002 = 0;
        } else {
            res_36001 = arg_30895;
            res_36002 = y_30914;
        }
        
        int32_t res_36003;
        int32_t res_36004;
        int32_t res_36005;
        int32_t res_36006;
        
        if (cond_35999) {
            res_36003 = 1;
            res_36004 = y_30914;
            res_36005 = 0;
            res_36006 = arg_30895;
        } else {
            res_36003 = arg_30895;
            res_36004 = res_36002;
            res_36005 = y_30914;
            res_36006 = res_36001;
        }
        
        int32_t res_36007;
        int32_t res_36008;
        int32_t res_36009;
        int32_t res_36010;
        
        if (cond_35998) {
            res_36007 = 1;
            res_36008 = 0;
            res_36009 = 0;
            res_36010 = 1;
        } else {
            res_36007 = res_36003;
            res_36008 = res_36004;
            res_36009 = res_36005;
            res_36010 = res_36006;
        }
        
        char not_p_36011 = !cond_35999;
        char p_and_eq_x_y_36012 = not_p_36011 && eq_x_z_30916;
        char not_p_36013 = !cond_35998;
        char p_and_eq_x_y_36014 = not_p_36013 && p_and_eq_x_y_36012;
        char cond_36015 = arg_35989 == 1;
        float res_36016;
        
        if (cond_36015) {
            res_36016 = -1.0F;
        } else {
            res_36016 = 1.0F;
        }
        
        char p_and_eq_x_y_36017 = cond_35999 && eq_x_y_30918;
        char p_and_eq_x_y_36018 = not_p_36011 && eq_x_z_30920;
        char eq_x_z_36019 = p_and_eq_x_y_36017 || p_and_eq_x_y_36018;
        char p_and_eq_x_y_36020 = cond_35998 && eq_x_y_30918;
        char p_and_eq_x_y_36021 = not_p_36013 && eq_x_z_36019;
        char cond_36022 = p_and_eq_x_y_36020 || p_and_eq_x_y_36021;
        char not_p_36023 = !cond_36000;
        char p_and_eq_x_y_36024 = not_p_36023 && eq_x_y_30922;
        char eq_x_z_36025 = cond_36000 || p_and_eq_x_y_36024;
        char p_and_eq_x_y_36026 = cond_35999 && eq_x_y_30922;
        char p_and_eq_x_y_36027 = not_p_36011 && eq_x_z_36025;
        char eq_x_z_36028 = p_and_eq_x_y_36026 || p_and_eq_x_y_36027;
        char p_and_eq_x_y_36029 = not_p_36013 && eq_x_z_36028;
        char cond_36030 = cond_35998 || p_and_eq_x_y_36029;
        char cond_36031 = arg_35989 == 2;
        float res_36032;
        
        if (cond_36031) {
            res_36032 = -1.0F;
        } else {
            res_36032 = 1.0F;
        }
        
        char p_and_eq_x_y_36033 = cond_36000 && eq_x_y_30924;
        char eq_x_z_36034 = p_and_eq_x_y_36033 || not_p_36023;
        char p_and_eq_x_y_36035 = not_p_36011 && eq_x_z_36034;
        char eq_x_z_36036 = cond_35999 || p_and_eq_x_y_36035;
        char p_and_eq_x_y_36037 = cond_35998 && eq_x_y_30924;
        char p_and_eq_x_y_36038 = not_p_36013 && eq_x_z_36036;
        char cond_36039 = p_and_eq_x_y_36037 || p_and_eq_x_y_36038;
        int32_t res_36040;
        int32_t res_36041;
        float res_36042;
        
        if (cond_36039) {
            res_36040 = res_36007;
            res_36041 = arg_30895;
            res_36042 = res_36032;
        } else {
            res_36040 = 0;
            res_36041 = 0;
            res_36042 = 0.0F;
        }
        
        int32_t res_36043;
        int32_t res_36044;
        float res_36045;
        
        if (cond_36030) {
            res_36043 = res_36007;
            res_36044 = 1;
            res_36045 = res_36032;
        } else {
            res_36043 = res_36040;
            res_36044 = res_36041;
            res_36045 = res_36042;
        }
        
        int32_t res_36046;
        int32_t res_36047;
        float res_36048;
        
        if (cond_36022) {
            res_36046 = arg_30895;
            res_36047 = res_36008;
            res_36048 = res_36016;
        } else {
            res_36046 = res_36043;
            res_36047 = res_36044;
            res_36048 = res_36045;
        }
        
        int32_t res_36049;
        int32_t res_36050;
        float res_36051;
        
        if (p_and_eq_x_y_36014) {
            res_36049 = 1;
            res_36050 = res_36008;
            res_36051 = res_36016;
        } else {
            res_36049 = res_36046;
            res_36050 = res_36047;
            res_36051 = res_36048;
        }
        
        int32_t i_36052 = res_36049 + arg_35989;
        int32_t i_36053 = res_36049 + arg_35990;
        char p_and_eq_x_y_36054 = not_p_36011 && eq_x_y_30922;
        char eq_x_z_36055 = cond_35999 || p_and_eq_x_y_36054;
        char p_and_eq_x_y_36056 = not_p_36013 && eq_x_z_36055;
        char cond_36057 = cond_35998 || p_and_eq_x_y_36056;
        char p_and_eq_x_y_36058 = cond_35999 && eq_x_y_30924;
        char eq_x_z_36059 = p_and_eq_x_y_36058 || not_p_36011;
        char p_and_eq_x_y_36060 = not_p_36013 && eq_x_z_36059;
        char cond_36061 = p_and_eq_x_y_36037 || p_and_eq_x_y_36060;
        char p_and_eq_x_y_36062 = not_p_36023 && eq_x_z_30916;
        char p_and_eq_x_y_36063 = cond_35999 && eq_x_z_30916;
        char p_and_eq_x_y_36064 = not_p_36011 && p_and_eq_x_y_36062;
        char eq_x_z_36065 = p_and_eq_x_y_36063 || p_and_eq_x_y_36064;
        char p_and_eq_x_y_36066 = not_p_36013 && eq_x_z_36065;
        char p_and_eq_x_y_36067 = cond_36000 && eq_x_y_30918;
        char p_and_eq_x_y_36068 = not_p_36023 && eq_x_z_30920;
        char eq_x_z_36069 = p_and_eq_x_y_36067 || p_and_eq_x_y_36068;
        char p_and_eq_x_y_36070 = cond_35999 && eq_x_z_30920;
        char p_and_eq_x_y_36071 = not_p_36011 && eq_x_z_36069;
        char eq_x_z_36072 = p_and_eq_x_y_36070 || p_and_eq_x_y_36071;
        char p_and_eq_x_y_36073 = not_p_36013 && eq_x_z_36072;
        char cond_36074 = p_and_eq_x_y_36020 || p_and_eq_x_y_36073;
        int32_t res_36075;
        int32_t res_36076;
        float res_36077;
        
        if (cond_36074) {
            res_36075 = res_36009;
            res_36076 = arg_30895;
            res_36077 = res_36032;
        } else {
            res_36075 = 0;
            res_36076 = 0;
            res_36077 = 0.0F;
        }
        
        int32_t res_36078;
        int32_t res_36079;
        float res_36080;
        
        if (p_and_eq_x_y_36066) {
            res_36078 = res_36009;
            res_36079 = 1;
            res_36080 = res_36032;
        } else {
            res_36078 = res_36075;
            res_36079 = res_36076;
            res_36080 = res_36077;
        }
        
        int32_t res_36081;
        int32_t res_36082;
        float res_36083;
        
        if (cond_36061) {
            res_36081 = arg_30895;
            res_36082 = res_36010;
            res_36083 = res_36016;
        } else {
            res_36081 = res_36078;
            res_36082 = res_36079;
            res_36083 = res_36080;
        }
        
        int32_t res_36084;
        int32_t res_36085;
        float res_36086;
        
        if (cond_36057) {
            res_36084 = 1;
            res_36085 = res_36010;
            res_36086 = res_36016;
        } else {
            res_36084 = res_36081;
            res_36085 = res_36082;
            res_36086 = res_36083;
        }
        
        int32_t i_36087 = res_36084 + arg_35989;
        int32_t i_36088 = res_36084 + arg_35990;
        int32_t res_36089;
        int32_t res_36090;
        float res_36091;
        
        if (y_35995) {
            res_36089 = arg_35987;
            res_36090 = arg_30895;
            res_36091 = res_36032;
        } else {
            res_36089 = 0;
            res_36090 = 0;
            res_36091 = 0.0F;
        }
        
        int32_t res_36092;
        int32_t res_36093;
        float res_36094;
        
        if (x_35994) {
            res_36092 = arg_35987;
            res_36093 = 1;
            res_36094 = res_36032;
        } else {
            res_36092 = res_36089;
            res_36093 = res_36090;
            res_36094 = res_36091;
        }
        
        int32_t res_36095;
        int32_t res_36096;
        float res_36097;
        
        if (y_35992) {
            res_36095 = arg_30895;
            res_36096 = arg_35988;
            res_36097 = res_36016;
        } else {
            res_36095 = res_36092;
            res_36096 = res_36093;
            res_36097 = res_36094;
        }
        
        int32_t res_36098;
        int32_t res_36099;
        float res_36100;
        
        if (x_35991) {
            res_36098 = 1;
            res_36099 = arg_35988;
            res_36100 = res_36016;
        } else {
            res_36098 = res_36095;
            res_36099 = res_36096;
            res_36100 = res_36097;
        }
        
        int32_t i_36101 = res_36098 + arg_35989;
        int32_t i_36102 = res_36098 + arg_35990;
        float res_36126;
        
        if (res_35997) {
            float x_36103 = *(__global float *) &S1_mem_38132[(res_36049 *
                                                               g_30887 +
                                                               res_36050) * 4];
            float x_36104 = *(__global float *) &S1_mem_38146[(i_36052 *
                                                               g_30887 +
                                                               res_36050) * 4];
            float y_36105 = *(__global float *) &S1_mem_38146[(i_36053 *
                                                               g_30887 +
                                                               res_36050) * 4];
            float y_36106 = x_36104 - y_36105;
            float y_36107 = x_31869 * y_36106;
            float res_36108 = x_36103 - y_36107;
            float res_36109 = res_36051 * res_36108;
            float x_36110 = *(__global float *) &S1_mem_38132[(res_36084 *
                                                               g_30887 +
                                                               res_36085) * 4];
            float x_36111 = *(__global float *) &S1_mem_38146[(i_36087 *
                                                               g_30887 +
                                                               res_36085) * 4];
            float y_36112 = *(__global float *) &S1_mem_38146[(i_36088 *
                                                               g_30887 +
                                                               res_36085) * 4];
            float y_36113 = x_36111 - y_36112;
            float y_36114 = x_31869 * y_36113;
            float res_36115 = x_36110 - y_36114;
            float res_36116 = res_36086 * res_36115;
            float y_36117 = res_36109 + res_36116;
            float res_36118 = 0.5F * y_36117;
            
            res_36126 = res_36118;
        } else {
            float x_36119 = *(__global float *) &S1_mem_38132[(res_36098 *
                                                               g_30887 +
                                                               res_36099) * 4];
            float x_36120 = *(__global float *) &S1_mem_38146[(i_36101 *
                                                               g_30887 +
                                                               res_36099) * 4];
            float y_36121 = *(__global float *) &S1_mem_38146[(i_36102 *
                                                               g_30887 +
                                                               res_36099) * 4];
            float y_36122 = x_36120 - y_36121;
            float y_36123 = x_31869 * y_36122;
            float res_36124 = x_36119 - y_36123;
            float res_36125 = res_36100 * res_36124;
            
            res_36126 = res_36125;
        }
        res_36127 = res_36126;
    }
    
    int32_t i_36128 = res_35971 + 1;
    int32_t i_36129 = res_35971 + -1;
    float res_36277;
    
    if (res_35978) {
        float x_36130 = *(__global float *) &S1_mem_38138[(res_35970 * g_30887 +
                                                           res_35971) * 4];
        float x_36131 = *(__global float *) &S1_mem_38146[(res_35970 * g_30887 +
                                                           i_36128) * 4];
        float y_36132 = *(__global float *) &S1_mem_38146[(res_35970 * g_30887 +
                                                           i_36129) * 4];
        float y_36133 = x_36131 - y_36132;
        float y_36134 = x_31869 * y_36133;
        float res_36135 = x_36130 - y_36134;
        
        res_36277 = res_36135;
    } else {
        int32_t arg_36136 = sdiv32(res_35970, res_30909);
        int32_t arg_36137 = sdiv32(res_35971, res_30909);
        int32_t arg_36138 = sdiv32(1, res_30909);
        int32_t arg_36139 = sdiv32(-1, res_30909);
        int32_t arg_36140 = sdiv32(2, res_30909);
        char x_36141 = arg_36136 == 0;
        char y_36142 = arg_36136 == y_30914;
        char x_36143 = x_36141 || y_36142;
        char x_36144 = arg_36137 == 0;
        char y_36145 = arg_36137 == y_30914;
        char y_36146 = x_36144 || y_36145;
        char res_36147 = x_36143 && y_36146;
        char cond_36148 = x_36141 && x_36144;
        char cond_36149 = x_36141 && y_36145;
        char cond_36150 = y_36142 && x_36144;
        int32_t res_36151;
        int32_t res_36152;
        
        if (cond_36150) {
            res_36151 = 1;
            res_36152 = 0;
        } else {
            res_36151 = arg_30895;
            res_36152 = y_30914;
        }
        
        int32_t res_36153;
        int32_t res_36154;
        int32_t res_36155;
        int32_t res_36156;
        
        if (cond_36149) {
            res_36153 = 1;
            res_36154 = y_30914;
            res_36155 = 0;
            res_36156 = arg_30895;
        } else {
            res_36153 = arg_30895;
            res_36154 = res_36152;
            res_36155 = y_30914;
            res_36156 = res_36151;
        }
        
        int32_t res_36157;
        int32_t res_36158;
        int32_t res_36159;
        int32_t res_36160;
        
        if (cond_36148) {
            res_36157 = 1;
            res_36158 = 0;
            res_36159 = 0;
            res_36160 = 1;
        } else {
            res_36157 = res_36153;
            res_36158 = res_36154;
            res_36159 = res_36155;
            res_36160 = res_36156;
        }
        
        char not_p_36161 = !cond_36149;
        char p_and_eq_x_y_36162 = not_p_36161 && eq_x_z_30916;
        char not_p_36163 = !cond_36148;
        char p_and_eq_x_y_36164 = not_p_36163 && p_and_eq_x_y_36162;
        char cond_36165 = arg_36140 == 1;
        float res_36166;
        
        if (cond_36165) {
            res_36166 = -1.0F;
        } else {
            res_36166 = 1.0F;
        }
        
        char p_and_eq_x_y_36167 = cond_36149 && eq_x_y_30918;
        char p_and_eq_x_y_36168 = not_p_36161 && eq_x_z_30920;
        char eq_x_z_36169 = p_and_eq_x_y_36167 || p_and_eq_x_y_36168;
        char p_and_eq_x_y_36170 = cond_36148 && eq_x_y_30918;
        char p_and_eq_x_y_36171 = not_p_36163 && eq_x_z_36169;
        char cond_36172 = p_and_eq_x_y_36170 || p_and_eq_x_y_36171;
        char not_p_36173 = !cond_36150;
        char p_and_eq_x_y_36174 = not_p_36173 && eq_x_y_30922;
        char eq_x_z_36175 = cond_36150 || p_and_eq_x_y_36174;
        char p_and_eq_x_y_36176 = cond_36149 && eq_x_y_30922;
        char p_and_eq_x_y_36177 = not_p_36161 && eq_x_z_36175;
        char eq_x_z_36178 = p_and_eq_x_y_36176 || p_and_eq_x_y_36177;
        char p_and_eq_x_y_36179 = not_p_36163 && eq_x_z_36178;
        char cond_36180 = cond_36148 || p_and_eq_x_y_36179;
        char cond_36181 = arg_36140 == 2;
        float res_36182;
        
        if (cond_36181) {
            res_36182 = -1.0F;
        } else {
            res_36182 = 1.0F;
        }
        
        char p_and_eq_x_y_36183 = cond_36150 && eq_x_y_30924;
        char eq_x_z_36184 = p_and_eq_x_y_36183 || not_p_36173;
        char p_and_eq_x_y_36185 = not_p_36161 && eq_x_z_36184;
        char eq_x_z_36186 = cond_36149 || p_and_eq_x_y_36185;
        char p_and_eq_x_y_36187 = cond_36148 && eq_x_y_30924;
        char p_and_eq_x_y_36188 = not_p_36163 && eq_x_z_36186;
        char cond_36189 = p_and_eq_x_y_36187 || p_and_eq_x_y_36188;
        int32_t res_36190;
        int32_t res_36191;
        float res_36192;
        
        if (cond_36189) {
            res_36190 = res_36157;
            res_36191 = arg_30895;
            res_36192 = res_36182;
        } else {
            res_36190 = 0;
            res_36191 = 0;
            res_36192 = 0.0F;
        }
        
        int32_t res_36193;
        int32_t res_36194;
        float res_36195;
        
        if (cond_36180) {
            res_36193 = res_36157;
            res_36194 = 1;
            res_36195 = res_36182;
        } else {
            res_36193 = res_36190;
            res_36194 = res_36191;
            res_36195 = res_36192;
        }
        
        int32_t res_36196;
        int32_t res_36197;
        float res_36198;
        
        if (cond_36172) {
            res_36196 = arg_30895;
            res_36197 = res_36158;
            res_36198 = res_36166;
        } else {
            res_36196 = res_36193;
            res_36197 = res_36194;
            res_36198 = res_36195;
        }
        
        int32_t res_36199;
        int32_t res_36200;
        float res_36201;
        
        if (p_and_eq_x_y_36164) {
            res_36199 = 1;
            res_36200 = res_36158;
            res_36201 = res_36166;
        } else {
            res_36199 = res_36196;
            res_36200 = res_36197;
            res_36201 = res_36198;
        }
        
        int32_t i_36202 = res_36200 + arg_36138;
        int32_t i_36203 = res_36200 + arg_36139;
        char p_and_eq_x_y_36204 = not_p_36161 && eq_x_y_30922;
        char eq_x_z_36205 = cond_36149 || p_and_eq_x_y_36204;
        char p_and_eq_x_y_36206 = not_p_36163 && eq_x_z_36205;
        char cond_36207 = cond_36148 || p_and_eq_x_y_36206;
        char p_and_eq_x_y_36208 = cond_36149 && eq_x_y_30924;
        char eq_x_z_36209 = p_and_eq_x_y_36208 || not_p_36161;
        char p_and_eq_x_y_36210 = not_p_36163 && eq_x_z_36209;
        char cond_36211 = p_and_eq_x_y_36187 || p_and_eq_x_y_36210;
        char p_and_eq_x_y_36212 = not_p_36173 && eq_x_z_30916;
        char p_and_eq_x_y_36213 = cond_36149 && eq_x_z_30916;
        char p_and_eq_x_y_36214 = not_p_36161 && p_and_eq_x_y_36212;
        char eq_x_z_36215 = p_and_eq_x_y_36213 || p_and_eq_x_y_36214;
        char p_and_eq_x_y_36216 = not_p_36163 && eq_x_z_36215;
        char p_and_eq_x_y_36217 = cond_36150 && eq_x_y_30918;
        char p_and_eq_x_y_36218 = not_p_36173 && eq_x_z_30920;
        char eq_x_z_36219 = p_and_eq_x_y_36217 || p_and_eq_x_y_36218;
        char p_and_eq_x_y_36220 = cond_36149 && eq_x_z_30920;
        char p_and_eq_x_y_36221 = not_p_36161 && eq_x_z_36219;
        char eq_x_z_36222 = p_and_eq_x_y_36220 || p_and_eq_x_y_36221;
        char p_and_eq_x_y_36223 = not_p_36163 && eq_x_z_36222;
        char cond_36224 = p_and_eq_x_y_36170 || p_and_eq_x_y_36223;
        int32_t res_36225;
        int32_t res_36226;
        float res_36227;
        
        if (cond_36224) {
            res_36225 = res_36159;
            res_36226 = arg_30895;
            res_36227 = res_36182;
        } else {
            res_36225 = 0;
            res_36226 = 0;
            res_36227 = 0.0F;
        }
        
        int32_t res_36228;
        int32_t res_36229;
        float res_36230;
        
        if (p_and_eq_x_y_36216) {
            res_36228 = res_36159;
            res_36229 = 1;
            res_36230 = res_36182;
        } else {
            res_36228 = res_36225;
            res_36229 = res_36226;
            res_36230 = res_36227;
        }
        
        int32_t res_36231;
        int32_t res_36232;
        float res_36233;
        
        if (cond_36211) {
            res_36231 = arg_30895;
            res_36232 = res_36160;
            res_36233 = res_36166;
        } else {
            res_36231 = res_36228;
            res_36232 = res_36229;
            res_36233 = res_36230;
        }
        
        int32_t res_36234;
        int32_t res_36235;
        float res_36236;
        
        if (cond_36207) {
            res_36234 = 1;
            res_36235 = res_36160;
            res_36236 = res_36166;
        } else {
            res_36234 = res_36231;
            res_36235 = res_36232;
            res_36236 = res_36233;
        }
        
        int32_t i_36237 = res_36235 + arg_36138;
        int32_t i_36238 = res_36235 + arg_36139;
        int32_t res_36239;
        int32_t res_36240;
        float res_36241;
        
        if (y_36145) {
            res_36239 = arg_36136;
            res_36240 = arg_30895;
            res_36241 = res_36182;
        } else {
            res_36239 = 0;
            res_36240 = 0;
            res_36241 = 0.0F;
        }
        
        int32_t res_36242;
        int32_t res_36243;
        float res_36244;
        
        if (x_36144) {
            res_36242 = arg_36136;
            res_36243 = 1;
            res_36244 = res_36182;
        } else {
            res_36242 = res_36239;
            res_36243 = res_36240;
            res_36244 = res_36241;
        }
        
        int32_t res_36245;
        int32_t res_36246;
        float res_36247;
        
        if (y_36142) {
            res_36245 = arg_30895;
            res_36246 = arg_36137;
            res_36247 = res_36166;
        } else {
            res_36245 = res_36242;
            res_36246 = res_36243;
            res_36247 = res_36244;
        }
        
        int32_t res_36248;
        int32_t res_36249;
        float res_36250;
        
        if (x_36141) {
            res_36248 = 1;
            res_36249 = arg_36137;
            res_36250 = res_36166;
        } else {
            res_36248 = res_36245;
            res_36249 = res_36246;
            res_36250 = res_36247;
        }
        
        int32_t i_36251 = res_36249 + arg_36138;
        int32_t i_36252 = res_36249 + arg_36139;
        float res_36276;
        
        if (res_36147) {
            float x_36253 = *(__global float *) &S1_mem_38138[(res_36199 *
                                                               g_30887 +
                                                               res_36200) * 4];
            float x_36254 = *(__global float *) &S1_mem_38146[(res_36199 *
                                                               g_30887 +
                                                               i_36202) * 4];
            float y_36255 = *(__global float *) &S1_mem_38146[(res_36199 *
                                                               g_30887 +
                                                               i_36203) * 4];
            float y_36256 = x_36254 - y_36255;
            float y_36257 = x_31869 * y_36256;
            float res_36258 = x_36253 - y_36257;
            float res_36259 = res_36201 * res_36258;
            float x_36260 = *(__global float *) &S1_mem_38138[(res_36234 *
                                                               g_30887 +
                                                               res_36235) * 4];
            float x_36261 = *(__global float *) &S1_mem_38146[(res_36234 *
                                                               g_30887 +
                                                               i_36237) * 4];
            float y_36262 = *(__global float *) &S1_mem_38146[(res_36234 *
                                                               g_30887 +
                                                               i_36238) * 4];
            float y_36263 = x_36261 - y_36262;
            float y_36264 = x_31869 * y_36263;
            float res_36265 = x_36260 - y_36264;
            float res_36266 = res_36236 * res_36265;
            float y_36267 = res_36259 + res_36266;
            float res_36268 = 0.5F * y_36267;
            
            res_36276 = res_36268;
        } else {
            float x_36269 = *(__global float *) &S1_mem_38138[(res_36248 *
                                                               g_30887 +
                                                               res_36249) * 4];
            float x_36270 = *(__global float *) &S1_mem_38146[(res_36248 *
                                                               g_30887 +
                                                               i_36251) * 4];
            float y_36271 = *(__global float *) &S1_mem_38146[(res_36248 *
                                                               g_30887 +
                                                               i_36252) * 4];
            float y_36272 = x_36270 - y_36271;
            float y_36273 = x_31869 * y_36272;
            float res_36274 = x_36269 - y_36273;
            float res_36275 = res_36250 * res_36274;
            
            res_36276 = res_36275;
        }
        res_36277 = res_36276;
    }
    // write kernel result
    {
        *(__global float *) &mem_38148[i_35968 * 4] = res_36277;
        *(__global float *) &mem_38150[i_35968 * 4] = res_36127;
    }
}
__kernel void map_kernel_36280(float res_32512, char eq_x_z_30920, __global
                               unsigned char *mem_38148, char eq_x_z_30916,
                               float y_32516, char eq_x_y_30924,
                               int32_t res_30909, int32_t y_30914,
                               char eq_x_y_30922, __global
                               unsigned char *mem_38150, char eq_x_y_30918,
                               int32_t arg_30895, int32_t x_30903,
                               int32_t g_30887, __global
                               unsigned char *mem_38152, __global
                               unsigned char *mem_38154)
{
    const uint kernel_thread_index_36280 = get_global_id(0);
    
    if (kernel_thread_index_36280 >= x_30903)
        return;
    
    int32_t i_36281;
    
    // compute thread index
    {
        i_36281 = kernel_thread_index_36280;
    }
    // read kernel parameters
    { }
    
    int32_t res_36283 = sdiv32(i_36281, g_30887);
    int32_t res_36284 = smod32(i_36281, g_30887);
    char x_36285 = sle32(1, res_36283);
    char y_36286 = sle32(res_36283, arg_30895);
    char x_36287 = x_36285 && y_36286;
    char y_36288 = sle32(1, res_36284);
    char x_36289 = x_36287 && y_36288;
    char y_36290 = sle32(res_36284, arg_30895);
    char res_36291 = x_36289 && y_36290;
    float x_36292 = sitofp_i32_f32(res_36283);
    int32_t x_36293 = res_36283 * g_30887;
    int32_t x_36294 = x_36293 + res_36284;
    float x_36295 = sitofp_i32_f32(res_36284);
    float res_36595;
    
    if (res_36291) {
        float y_36296 = *(__global float *) &mem_38150[x_36294 * 4];
        float y_36297 = res_32512 * y_36296;
        float res_36298 = x_36292 - y_36297;
        float y_36299 = *(__global float *) &mem_38148[x_36294 * 4];
        float y_36300 = res_32512 * y_36299;
        float res_36301 = x_36295 - y_36300;
        char cond_36302 = res_36298 < 0.5F;
        float res_36303;
        
        if (cond_36302) {
            res_36303 = 0.5F;
        } else {
            res_36303 = res_36298;
        }
        
        char cond_36304 = y_32516 < res_36303;
        float res_36305;
        
        if (cond_36304) {
            res_36305 = y_32516;
        } else {
            res_36305 = res_36303;
        }
        
        int32_t res_36306 = fptosi_f32_i32(res_36305);
        int32_t res_36307 = res_36306 + 1;
        char cond_36308 = res_36301 < 0.5F;
        float res_36309;
        
        if (cond_36308) {
            res_36309 = 0.5F;
        } else {
            res_36309 = res_36301;
        }
        
        char cond_36310 = y_32516 < res_36309;
        float res_36311;
        
        if (cond_36310) {
            res_36311 = y_32516;
        } else {
            res_36311 = res_36309;
        }
        
        int32_t res_36312 = fptosi_f32_i32(res_36311);
        int32_t res_36313 = res_36312 + 1;
        float y_36314 = sitofp_i32_f32(res_36306);
        float res_36315 = res_36305 - y_36314;
        float res_36316 = 1.0F - res_36315;
        float y_36317 = sitofp_i32_f32(res_36312);
        float res_36318 = res_36311 - y_36317;
        float res_36319 = 1.0F - res_36318;
        int32_t x_36320 = res_36306 * g_30887;
        int32_t x_36321 = x_36320 + res_36312;
        float y_36322 = *(__global float *) &mem_38150[x_36321 * 4];
        float x_36323 = res_36319 * y_36322;
        int32_t x_36324 = x_36320 + res_36313;
        float y_36325 = *(__global float *) &mem_38150[x_36324 * 4];
        float y_36326 = res_36318 * y_36325;
        float y_36327 = x_36323 + y_36326;
        float x_36328 = res_36316 * y_36327;
        int32_t x_36329 = res_36307 * g_30887;
        int32_t x_36330 = x_36329 + res_36312;
        float y_36331 = *(__global float *) &mem_38150[x_36330 * 4];
        float x_36332 = res_36319 * y_36331;
        int32_t x_36333 = x_36329 + res_36313;
        float y_36334 = *(__global float *) &mem_38150[x_36333 * 4];
        float y_36335 = res_36318 * y_36334;
        float y_36336 = x_36332 + y_36335;
        float y_36337 = res_36315 * y_36336;
        float res_36338 = x_36328 + y_36337;
        
        res_36595 = res_36338;
    } else {
        int32_t arg_36339 = sdiv32(res_36283, res_30909);
        int32_t arg_36340 = sdiv32(res_36284, res_30909);
        int32_t arg_36341 = sdiv32(1, res_30909);
        char x_36342 = arg_36339 == 0;
        char y_36343 = arg_36339 == y_30914;
        char x_36344 = x_36342 || y_36343;
        char x_36345 = arg_36340 == 0;
        char y_36346 = arg_36340 == y_30914;
        char y_36347 = x_36345 || y_36346;
        char res_36348 = x_36344 && y_36347;
        char cond_36349 = x_36342 && x_36345;
        char cond_36350 = x_36342 && y_36346;
        char cond_36351 = y_36343 && x_36345;
        int32_t res_36352;
        int32_t res_36353;
        
        if (cond_36351) {
            res_36352 = 1;
            res_36353 = 0;
        } else {
            res_36352 = arg_30895;
            res_36353 = y_30914;
        }
        
        int32_t res_36354;
        int32_t res_36355;
        int32_t res_36356;
        int32_t res_36357;
        
        if (cond_36350) {
            res_36354 = 1;
            res_36355 = y_30914;
            res_36356 = 0;
            res_36357 = arg_30895;
        } else {
            res_36354 = arg_30895;
            res_36355 = res_36353;
            res_36356 = y_30914;
            res_36357 = res_36352;
        }
        
        int32_t res_36358;
        int32_t res_36359;
        int32_t res_36360;
        int32_t res_36361;
        
        if (cond_36349) {
            res_36358 = 1;
            res_36359 = 0;
            res_36360 = 0;
            res_36361 = 1;
        } else {
            res_36358 = res_36354;
            res_36359 = res_36355;
            res_36360 = res_36356;
            res_36361 = res_36357;
        }
        
        char not_p_36362 = !cond_36350;
        char p_and_eq_x_y_36363 = not_p_36362 && eq_x_z_30916;
        char not_p_36364 = !cond_36349;
        char p_and_eq_x_y_36365 = not_p_36364 && p_and_eq_x_y_36363;
        char cond_36366 = arg_36341 == 1;
        float res_36367;
        
        if (cond_36366) {
            res_36367 = -1.0F;
        } else {
            res_36367 = 1.0F;
        }
        
        char p_and_eq_x_y_36368 = cond_36350 && eq_x_y_30918;
        char p_and_eq_x_y_36369 = not_p_36362 && eq_x_z_30920;
        char eq_x_z_36370 = p_and_eq_x_y_36368 || p_and_eq_x_y_36369;
        char p_and_eq_x_y_36371 = cond_36349 && eq_x_y_30918;
        char p_and_eq_x_y_36372 = not_p_36364 && eq_x_z_36370;
        char cond_36373 = p_and_eq_x_y_36371 || p_and_eq_x_y_36372;
        char not_p_36374 = !cond_36351;
        char p_and_eq_x_y_36375 = not_p_36374 && eq_x_y_30922;
        char eq_x_z_36376 = cond_36351 || p_and_eq_x_y_36375;
        char p_and_eq_x_y_36377 = cond_36350 && eq_x_y_30922;
        char p_and_eq_x_y_36378 = not_p_36362 && eq_x_z_36376;
        char eq_x_z_36379 = p_and_eq_x_y_36377 || p_and_eq_x_y_36378;
        char p_and_eq_x_y_36380 = not_p_36364 && eq_x_z_36379;
        char cond_36381 = cond_36349 || p_and_eq_x_y_36380;
        char cond_36382 = arg_36341 == 2;
        float res_36383;
        
        if (cond_36382) {
            res_36383 = -1.0F;
        } else {
            res_36383 = 1.0F;
        }
        
        char p_and_eq_x_y_36384 = cond_36351 && eq_x_y_30924;
        char eq_x_z_36385 = p_and_eq_x_y_36384 || not_p_36374;
        char p_and_eq_x_y_36386 = not_p_36362 && eq_x_z_36385;
        char eq_x_z_36387 = cond_36350 || p_and_eq_x_y_36386;
        char p_and_eq_x_y_36388 = cond_36349 && eq_x_y_30924;
        char p_and_eq_x_y_36389 = not_p_36364 && eq_x_z_36387;
        char cond_36390 = p_and_eq_x_y_36388 || p_and_eq_x_y_36389;
        int32_t res_36391;
        int32_t res_36392;
        float res_36393;
        
        if (cond_36390) {
            res_36391 = res_36358;
            res_36392 = arg_30895;
            res_36393 = res_36383;
        } else {
            res_36391 = 0;
            res_36392 = 0;
            res_36393 = 0.0F;
        }
        
        int32_t res_36394;
        int32_t res_36395;
        float res_36396;
        
        if (cond_36381) {
            res_36394 = res_36358;
            res_36395 = 1;
            res_36396 = res_36383;
        } else {
            res_36394 = res_36391;
            res_36395 = res_36392;
            res_36396 = res_36393;
        }
        
        int32_t res_36397;
        int32_t res_36398;
        float res_36399;
        
        if (cond_36373) {
            res_36397 = arg_30895;
            res_36398 = res_36359;
            res_36399 = res_36367;
        } else {
            res_36397 = res_36394;
            res_36398 = res_36395;
            res_36399 = res_36396;
        }
        
        int32_t res_36400;
        int32_t res_36401;
        float res_36402;
        
        if (p_and_eq_x_y_36365) {
            res_36400 = 1;
            res_36401 = res_36359;
            res_36402 = res_36367;
        } else {
            res_36400 = res_36397;
            res_36401 = res_36398;
            res_36402 = res_36399;
        }
        
        float x_36403 = sitofp_i32_f32(res_36400);
        int32_t x_36404 = res_36400 * g_30887;
        int32_t x_36405 = x_36404 + res_36401;
        float x_36406 = sitofp_i32_f32(res_36401);
        char p_and_eq_x_y_36407 = not_p_36362 && eq_x_y_30922;
        char eq_x_z_36408 = cond_36350 || p_and_eq_x_y_36407;
        char p_and_eq_x_y_36409 = not_p_36364 && eq_x_z_36408;
        char cond_36410 = cond_36349 || p_and_eq_x_y_36409;
        char p_and_eq_x_y_36411 = cond_36350 && eq_x_y_30924;
        char eq_x_z_36412 = p_and_eq_x_y_36411 || not_p_36362;
        char p_and_eq_x_y_36413 = not_p_36364 && eq_x_z_36412;
        char cond_36414 = p_and_eq_x_y_36388 || p_and_eq_x_y_36413;
        char p_and_eq_x_y_36415 = not_p_36374 && eq_x_z_30916;
        char p_and_eq_x_y_36416 = cond_36350 && eq_x_z_30916;
        char p_and_eq_x_y_36417 = not_p_36362 && p_and_eq_x_y_36415;
        char eq_x_z_36418 = p_and_eq_x_y_36416 || p_and_eq_x_y_36417;
        char p_and_eq_x_y_36419 = not_p_36364 && eq_x_z_36418;
        char p_and_eq_x_y_36420 = cond_36351 && eq_x_y_30918;
        char p_and_eq_x_y_36421 = not_p_36374 && eq_x_z_30920;
        char eq_x_z_36422 = p_and_eq_x_y_36420 || p_and_eq_x_y_36421;
        char p_and_eq_x_y_36423 = cond_36350 && eq_x_z_30920;
        char p_and_eq_x_y_36424 = not_p_36362 && eq_x_z_36422;
        char eq_x_z_36425 = p_and_eq_x_y_36423 || p_and_eq_x_y_36424;
        char p_and_eq_x_y_36426 = not_p_36364 && eq_x_z_36425;
        char cond_36427 = p_and_eq_x_y_36371 || p_and_eq_x_y_36426;
        int32_t res_36428;
        int32_t res_36429;
        float res_36430;
        
        if (cond_36427) {
            res_36428 = res_36360;
            res_36429 = arg_30895;
            res_36430 = res_36383;
        } else {
            res_36428 = 0;
            res_36429 = 0;
            res_36430 = 0.0F;
        }
        
        int32_t res_36431;
        int32_t res_36432;
        float res_36433;
        
        if (p_and_eq_x_y_36419) {
            res_36431 = res_36360;
            res_36432 = 1;
            res_36433 = res_36383;
        } else {
            res_36431 = res_36428;
            res_36432 = res_36429;
            res_36433 = res_36430;
        }
        
        int32_t res_36434;
        int32_t res_36435;
        float res_36436;
        
        if (cond_36414) {
            res_36434 = arg_30895;
            res_36435 = res_36361;
            res_36436 = res_36367;
        } else {
            res_36434 = res_36431;
            res_36435 = res_36432;
            res_36436 = res_36433;
        }
        
        int32_t res_36437;
        int32_t res_36438;
        float res_36439;
        
        if (cond_36410) {
            res_36437 = 1;
            res_36438 = res_36361;
            res_36439 = res_36367;
        } else {
            res_36437 = res_36434;
            res_36438 = res_36435;
            res_36439 = res_36436;
        }
        
        float x_36440 = sitofp_i32_f32(res_36437);
        int32_t x_36441 = res_36437 * g_30887;
        int32_t x_36442 = x_36441 + res_36438;
        float x_36443 = sitofp_i32_f32(res_36438);
        int32_t res_36444;
        int32_t res_36445;
        float res_36446;
        
        if (y_36346) {
            res_36444 = arg_36339;
            res_36445 = arg_30895;
            res_36446 = res_36383;
        } else {
            res_36444 = 0;
            res_36445 = 0;
            res_36446 = 0.0F;
        }
        
        int32_t res_36447;
        int32_t res_36448;
        float res_36449;
        
        if (x_36345) {
            res_36447 = arg_36339;
            res_36448 = 1;
            res_36449 = res_36383;
        } else {
            res_36447 = res_36444;
            res_36448 = res_36445;
            res_36449 = res_36446;
        }
        
        int32_t res_36450;
        int32_t res_36451;
        float res_36452;
        
        if (y_36343) {
            res_36450 = arg_30895;
            res_36451 = arg_36340;
            res_36452 = res_36367;
        } else {
            res_36450 = res_36447;
            res_36451 = res_36448;
            res_36452 = res_36449;
        }
        
        int32_t res_36453;
        int32_t res_36454;
        float res_36455;
        
        if (x_36342) {
            res_36453 = 1;
            res_36454 = arg_36340;
            res_36455 = res_36367;
        } else {
            res_36453 = res_36450;
            res_36454 = res_36451;
            res_36455 = res_36452;
        }
        
        float x_36456 = sitofp_i32_f32(res_36453);
        int32_t x_36457 = res_36453 * g_30887;
        int32_t x_36458 = x_36457 + res_36454;
        float x_36459 = sitofp_i32_f32(res_36454);
        float res_36594;
        
        if (res_36348) {
            float y_36460 = *(__global float *) &mem_38150[x_36405 * 4];
            float y_36461 = res_32512 * y_36460;
            float res_36462 = x_36403 - y_36461;
            float y_36463 = *(__global float *) &mem_38148[x_36405 * 4];
            float y_36464 = res_32512 * y_36463;
            float res_36465 = x_36406 - y_36464;
            char cond_36466 = res_36462 < 0.5F;
            float res_36467;
            
            if (cond_36466) {
                res_36467 = 0.5F;
            } else {
                res_36467 = res_36462;
            }
            
            char cond_36468 = y_32516 < res_36467;
            float res_36469;
            
            if (cond_36468) {
                res_36469 = y_32516;
            } else {
                res_36469 = res_36467;
            }
            
            int32_t res_36470 = fptosi_f32_i32(res_36469);
            int32_t res_36471 = res_36470 + 1;
            char cond_36472 = res_36465 < 0.5F;
            float res_36473;
            
            if (cond_36472) {
                res_36473 = 0.5F;
            } else {
                res_36473 = res_36465;
            }
            
            char cond_36474 = y_32516 < res_36473;
            float res_36475;
            
            if (cond_36474) {
                res_36475 = y_32516;
            } else {
                res_36475 = res_36473;
            }
            
            int32_t res_36476 = fptosi_f32_i32(res_36475);
            int32_t res_36477 = res_36476 + 1;
            float y_36478 = sitofp_i32_f32(res_36470);
            float res_36479 = res_36469 - y_36478;
            float res_36480 = 1.0F - res_36479;
            float y_36481 = sitofp_i32_f32(res_36476);
            float res_36482 = res_36475 - y_36481;
            float res_36483 = 1.0F - res_36482;
            int32_t x_36484 = res_36470 * g_30887;
            int32_t x_36485 = x_36484 + res_36476;
            float y_36486 = *(__global float *) &mem_38150[x_36485 * 4];
            float x_36487 = res_36483 * y_36486;
            int32_t x_36488 = x_36484 + res_36477;
            float y_36489 = *(__global float *) &mem_38150[x_36488 * 4];
            float y_36490 = res_36482 * y_36489;
            float y_36491 = x_36487 + y_36490;
            float x_36492 = res_36480 * y_36491;
            int32_t x_36493 = res_36471 * g_30887;
            int32_t x_36494 = x_36493 + res_36476;
            float y_36495 = *(__global float *) &mem_38150[x_36494 * 4];
            float x_36496 = res_36483 * y_36495;
            int32_t x_36497 = x_36493 + res_36477;
            float y_36498 = *(__global float *) &mem_38150[x_36497 * 4];
            float y_36499 = res_36482 * y_36498;
            float y_36500 = x_36496 + y_36499;
            float y_36501 = res_36479 * y_36500;
            float res_36502 = x_36492 + y_36501;
            float res_36503 = res_36402 * res_36502;
            float y_36504 = *(__global float *) &mem_38150[x_36442 * 4];
            float y_36505 = res_32512 * y_36504;
            float res_36506 = x_36440 - y_36505;
            float y_36507 = *(__global float *) &mem_38148[x_36442 * 4];
            float y_36508 = res_32512 * y_36507;
            float res_36509 = x_36443 - y_36508;
            char cond_36510 = res_36506 < 0.5F;
            float res_36511;
            
            if (cond_36510) {
                res_36511 = 0.5F;
            } else {
                res_36511 = res_36506;
            }
            
            char cond_36512 = y_32516 < res_36511;
            float res_36513;
            
            if (cond_36512) {
                res_36513 = y_32516;
            } else {
                res_36513 = res_36511;
            }
            
            int32_t res_36514 = fptosi_f32_i32(res_36513);
            int32_t res_36515 = res_36514 + 1;
            char cond_36516 = res_36509 < 0.5F;
            float res_36517;
            
            if (cond_36516) {
                res_36517 = 0.5F;
            } else {
                res_36517 = res_36509;
            }
            
            char cond_36518 = y_32516 < res_36517;
            float res_36519;
            
            if (cond_36518) {
                res_36519 = y_32516;
            } else {
                res_36519 = res_36517;
            }
            
            int32_t res_36520 = fptosi_f32_i32(res_36519);
            int32_t res_36521 = res_36520 + 1;
            float y_36522 = sitofp_i32_f32(res_36514);
            float res_36523 = res_36513 - y_36522;
            float res_36524 = 1.0F - res_36523;
            float y_36525 = sitofp_i32_f32(res_36520);
            float res_36526 = res_36519 - y_36525;
            float res_36527 = 1.0F - res_36526;
            int32_t x_36528 = res_36514 * g_30887;
            int32_t x_36529 = x_36528 + res_36520;
            float y_36530 = *(__global float *) &mem_38150[x_36529 * 4];
            float x_36531 = res_36527 * y_36530;
            int32_t x_36532 = x_36528 + res_36521;
            float y_36533 = *(__global float *) &mem_38150[x_36532 * 4];
            float y_36534 = res_36526 * y_36533;
            float y_36535 = x_36531 + y_36534;
            float x_36536 = res_36524 * y_36535;
            int32_t x_36537 = res_36515 * g_30887;
            int32_t x_36538 = x_36537 + res_36520;
            float y_36539 = *(__global float *) &mem_38150[x_36538 * 4];
            float x_36540 = res_36527 * y_36539;
            int32_t x_36541 = x_36537 + res_36521;
            float y_36542 = *(__global float *) &mem_38150[x_36541 * 4];
            float y_36543 = res_36526 * y_36542;
            float y_36544 = x_36540 + y_36543;
            float y_36545 = res_36523 * y_36544;
            float res_36546 = x_36536 + y_36545;
            float res_36547 = res_36439 * res_36546;
            float y_36548 = res_36503 + res_36547;
            float res_36549 = 0.5F * y_36548;
            
            res_36594 = res_36549;
        } else {
            float y_36550 = *(__global float *) &mem_38150[x_36458 * 4];
            float y_36551 = res_32512 * y_36550;
            float res_36552 = x_36456 - y_36551;
            float y_36553 = *(__global float *) &mem_38148[x_36458 * 4];
            float y_36554 = res_32512 * y_36553;
            float res_36555 = x_36459 - y_36554;
            char cond_36556 = res_36552 < 0.5F;
            float res_36557;
            
            if (cond_36556) {
                res_36557 = 0.5F;
            } else {
                res_36557 = res_36552;
            }
            
            char cond_36558 = y_32516 < res_36557;
            float res_36559;
            
            if (cond_36558) {
                res_36559 = y_32516;
            } else {
                res_36559 = res_36557;
            }
            
            int32_t res_36560 = fptosi_f32_i32(res_36559);
            int32_t res_36561 = res_36560 + 1;
            char cond_36562 = res_36555 < 0.5F;
            float res_36563;
            
            if (cond_36562) {
                res_36563 = 0.5F;
            } else {
                res_36563 = res_36555;
            }
            
            char cond_36564 = y_32516 < res_36563;
            float res_36565;
            
            if (cond_36564) {
                res_36565 = y_32516;
            } else {
                res_36565 = res_36563;
            }
            
            int32_t res_36566 = fptosi_f32_i32(res_36565);
            int32_t res_36567 = res_36566 + 1;
            float y_36568 = sitofp_i32_f32(res_36560);
            float res_36569 = res_36559 - y_36568;
            float res_36570 = 1.0F - res_36569;
            float y_36571 = sitofp_i32_f32(res_36566);
            float res_36572 = res_36565 - y_36571;
            float res_36573 = 1.0F - res_36572;
            int32_t x_36574 = res_36560 * g_30887;
            int32_t x_36575 = x_36574 + res_36566;
            float y_36576 = *(__global float *) &mem_38150[x_36575 * 4];
            float x_36577 = res_36573 * y_36576;
            int32_t x_36578 = x_36574 + res_36567;
            float y_36579 = *(__global float *) &mem_38150[x_36578 * 4];
            float y_36580 = res_36572 * y_36579;
            float y_36581 = x_36577 + y_36580;
            float x_36582 = res_36570 * y_36581;
            int32_t x_36583 = res_36561 * g_30887;
            int32_t x_36584 = x_36583 + res_36566;
            float y_36585 = *(__global float *) &mem_38150[x_36584 * 4];
            float x_36586 = res_36573 * y_36585;
            int32_t x_36587 = x_36583 + res_36567;
            float y_36588 = *(__global float *) &mem_38150[x_36587 * 4];
            float y_36589 = res_36572 * y_36588;
            float y_36590 = x_36586 + y_36589;
            float y_36591 = res_36569 * y_36590;
            float res_36592 = x_36582 + y_36591;
            float res_36593 = res_36455 * res_36592;
            
            res_36594 = res_36593;
        }
        res_36595 = res_36594;
    }
    
    float res_36895;
    
    if (res_36291) {
        float y_36596 = *(__global float *) &mem_38150[x_36294 * 4];
        float y_36597 = res_32512 * y_36596;
        float res_36598 = x_36292 - y_36597;
        float y_36599 = *(__global float *) &mem_38148[x_36294 * 4];
        float y_36600 = res_32512 * y_36599;
        float res_36601 = x_36295 - y_36600;
        char cond_36602 = res_36598 < 0.5F;
        float res_36603;
        
        if (cond_36602) {
            res_36603 = 0.5F;
        } else {
            res_36603 = res_36598;
        }
        
        char cond_36604 = y_32516 < res_36603;
        float res_36605;
        
        if (cond_36604) {
            res_36605 = y_32516;
        } else {
            res_36605 = res_36603;
        }
        
        int32_t res_36606 = fptosi_f32_i32(res_36605);
        int32_t res_36607 = res_36606 + 1;
        char cond_36608 = res_36601 < 0.5F;
        float res_36609;
        
        if (cond_36608) {
            res_36609 = 0.5F;
        } else {
            res_36609 = res_36601;
        }
        
        char cond_36610 = y_32516 < res_36609;
        float res_36611;
        
        if (cond_36610) {
            res_36611 = y_32516;
        } else {
            res_36611 = res_36609;
        }
        
        int32_t res_36612 = fptosi_f32_i32(res_36611);
        int32_t res_36613 = res_36612 + 1;
        float y_36614 = sitofp_i32_f32(res_36606);
        float res_36615 = res_36605 - y_36614;
        float res_36616 = 1.0F - res_36615;
        float y_36617 = sitofp_i32_f32(res_36612);
        float res_36618 = res_36611 - y_36617;
        float res_36619 = 1.0F - res_36618;
        int32_t x_36620 = res_36606 * g_30887;
        int32_t x_36621 = x_36620 + res_36612;
        float y_36622 = *(__global float *) &mem_38148[x_36621 * 4];
        float x_36623 = res_36619 * y_36622;
        int32_t x_36624 = x_36620 + res_36613;
        float y_36625 = *(__global float *) &mem_38148[x_36624 * 4];
        float y_36626 = res_36618 * y_36625;
        float y_36627 = x_36623 + y_36626;
        float x_36628 = res_36616 * y_36627;
        int32_t x_36629 = res_36607 * g_30887;
        int32_t x_36630 = x_36629 + res_36612;
        float y_36631 = *(__global float *) &mem_38148[x_36630 * 4];
        float x_36632 = res_36619 * y_36631;
        int32_t x_36633 = x_36629 + res_36613;
        float y_36634 = *(__global float *) &mem_38148[x_36633 * 4];
        float y_36635 = res_36618 * y_36634;
        float y_36636 = x_36632 + y_36635;
        float y_36637 = res_36615 * y_36636;
        float res_36638 = x_36628 + y_36637;
        
        res_36895 = res_36638;
    } else {
        int32_t arg_36639 = sdiv32(res_36283, res_30909);
        int32_t arg_36640 = sdiv32(res_36284, res_30909);
        int32_t arg_36641 = sdiv32(2, res_30909);
        char x_36642 = arg_36639 == 0;
        char y_36643 = arg_36639 == y_30914;
        char x_36644 = x_36642 || y_36643;
        char x_36645 = arg_36640 == 0;
        char y_36646 = arg_36640 == y_30914;
        char y_36647 = x_36645 || y_36646;
        char res_36648 = x_36644 && y_36647;
        char cond_36649 = x_36642 && x_36645;
        char cond_36650 = x_36642 && y_36646;
        char cond_36651 = y_36643 && x_36645;
        int32_t res_36652;
        int32_t res_36653;
        
        if (cond_36651) {
            res_36652 = 1;
            res_36653 = 0;
        } else {
            res_36652 = arg_30895;
            res_36653 = y_30914;
        }
        
        int32_t res_36654;
        int32_t res_36655;
        int32_t res_36656;
        int32_t res_36657;
        
        if (cond_36650) {
            res_36654 = 1;
            res_36655 = y_30914;
            res_36656 = 0;
            res_36657 = arg_30895;
        } else {
            res_36654 = arg_30895;
            res_36655 = res_36653;
            res_36656 = y_30914;
            res_36657 = res_36652;
        }
        
        int32_t res_36658;
        int32_t res_36659;
        int32_t res_36660;
        int32_t res_36661;
        
        if (cond_36649) {
            res_36658 = 1;
            res_36659 = 0;
            res_36660 = 0;
            res_36661 = 1;
        } else {
            res_36658 = res_36654;
            res_36659 = res_36655;
            res_36660 = res_36656;
            res_36661 = res_36657;
        }
        
        char not_p_36662 = !cond_36650;
        char p_and_eq_x_y_36663 = not_p_36662 && eq_x_z_30916;
        char not_p_36664 = !cond_36649;
        char p_and_eq_x_y_36665 = not_p_36664 && p_and_eq_x_y_36663;
        char cond_36666 = arg_36641 == 1;
        float res_36667;
        
        if (cond_36666) {
            res_36667 = -1.0F;
        } else {
            res_36667 = 1.0F;
        }
        
        char p_and_eq_x_y_36668 = cond_36650 && eq_x_y_30918;
        char p_and_eq_x_y_36669 = not_p_36662 && eq_x_z_30920;
        char eq_x_z_36670 = p_and_eq_x_y_36668 || p_and_eq_x_y_36669;
        char p_and_eq_x_y_36671 = cond_36649 && eq_x_y_30918;
        char p_and_eq_x_y_36672 = not_p_36664 && eq_x_z_36670;
        char cond_36673 = p_and_eq_x_y_36671 || p_and_eq_x_y_36672;
        char not_p_36674 = !cond_36651;
        char p_and_eq_x_y_36675 = not_p_36674 && eq_x_y_30922;
        char eq_x_z_36676 = cond_36651 || p_and_eq_x_y_36675;
        char p_and_eq_x_y_36677 = cond_36650 && eq_x_y_30922;
        char p_and_eq_x_y_36678 = not_p_36662 && eq_x_z_36676;
        char eq_x_z_36679 = p_and_eq_x_y_36677 || p_and_eq_x_y_36678;
        char p_and_eq_x_y_36680 = not_p_36664 && eq_x_z_36679;
        char cond_36681 = cond_36649 || p_and_eq_x_y_36680;
        char cond_36682 = arg_36641 == 2;
        float res_36683;
        
        if (cond_36682) {
            res_36683 = -1.0F;
        } else {
            res_36683 = 1.0F;
        }
        
        char p_and_eq_x_y_36684 = cond_36651 && eq_x_y_30924;
        char eq_x_z_36685 = p_and_eq_x_y_36684 || not_p_36674;
        char p_and_eq_x_y_36686 = not_p_36662 && eq_x_z_36685;
        char eq_x_z_36687 = cond_36650 || p_and_eq_x_y_36686;
        char p_and_eq_x_y_36688 = cond_36649 && eq_x_y_30924;
        char p_and_eq_x_y_36689 = not_p_36664 && eq_x_z_36687;
        char cond_36690 = p_and_eq_x_y_36688 || p_and_eq_x_y_36689;
        int32_t res_36691;
        int32_t res_36692;
        float res_36693;
        
        if (cond_36690) {
            res_36691 = res_36658;
            res_36692 = arg_30895;
            res_36693 = res_36683;
        } else {
            res_36691 = 0;
            res_36692 = 0;
            res_36693 = 0.0F;
        }
        
        int32_t res_36694;
        int32_t res_36695;
        float res_36696;
        
        if (cond_36681) {
            res_36694 = res_36658;
            res_36695 = 1;
            res_36696 = res_36683;
        } else {
            res_36694 = res_36691;
            res_36695 = res_36692;
            res_36696 = res_36693;
        }
        
        int32_t res_36697;
        int32_t res_36698;
        float res_36699;
        
        if (cond_36673) {
            res_36697 = arg_30895;
            res_36698 = res_36659;
            res_36699 = res_36667;
        } else {
            res_36697 = res_36694;
            res_36698 = res_36695;
            res_36699 = res_36696;
        }
        
        int32_t res_36700;
        int32_t res_36701;
        float res_36702;
        
        if (p_and_eq_x_y_36665) {
            res_36700 = 1;
            res_36701 = res_36659;
            res_36702 = res_36667;
        } else {
            res_36700 = res_36697;
            res_36701 = res_36698;
            res_36702 = res_36699;
        }
        
        float x_36703 = sitofp_i32_f32(res_36700);
        int32_t x_36704 = res_36700 * g_30887;
        int32_t x_36705 = x_36704 + res_36701;
        float x_36706 = sitofp_i32_f32(res_36701);
        char p_and_eq_x_y_36707 = not_p_36662 && eq_x_y_30922;
        char eq_x_z_36708 = cond_36650 || p_and_eq_x_y_36707;
        char p_and_eq_x_y_36709 = not_p_36664 && eq_x_z_36708;
        char cond_36710 = cond_36649 || p_and_eq_x_y_36709;
        char p_and_eq_x_y_36711 = cond_36650 && eq_x_y_30924;
        char eq_x_z_36712 = p_and_eq_x_y_36711 || not_p_36662;
        char p_and_eq_x_y_36713 = not_p_36664 && eq_x_z_36712;
        char cond_36714 = p_and_eq_x_y_36688 || p_and_eq_x_y_36713;
        char p_and_eq_x_y_36715 = not_p_36674 && eq_x_z_30916;
        char p_and_eq_x_y_36716 = cond_36650 && eq_x_z_30916;
        char p_and_eq_x_y_36717 = not_p_36662 && p_and_eq_x_y_36715;
        char eq_x_z_36718 = p_and_eq_x_y_36716 || p_and_eq_x_y_36717;
        char p_and_eq_x_y_36719 = not_p_36664 && eq_x_z_36718;
        char p_and_eq_x_y_36720 = cond_36651 && eq_x_y_30918;
        char p_and_eq_x_y_36721 = not_p_36674 && eq_x_z_30920;
        char eq_x_z_36722 = p_and_eq_x_y_36720 || p_and_eq_x_y_36721;
        char p_and_eq_x_y_36723 = cond_36650 && eq_x_z_30920;
        char p_and_eq_x_y_36724 = not_p_36662 && eq_x_z_36722;
        char eq_x_z_36725 = p_and_eq_x_y_36723 || p_and_eq_x_y_36724;
        char p_and_eq_x_y_36726 = not_p_36664 && eq_x_z_36725;
        char cond_36727 = p_and_eq_x_y_36671 || p_and_eq_x_y_36726;
        int32_t res_36728;
        int32_t res_36729;
        float res_36730;
        
        if (cond_36727) {
            res_36728 = res_36660;
            res_36729 = arg_30895;
            res_36730 = res_36683;
        } else {
            res_36728 = 0;
            res_36729 = 0;
            res_36730 = 0.0F;
        }
        
        int32_t res_36731;
        int32_t res_36732;
        float res_36733;
        
        if (p_and_eq_x_y_36719) {
            res_36731 = res_36660;
            res_36732 = 1;
            res_36733 = res_36683;
        } else {
            res_36731 = res_36728;
            res_36732 = res_36729;
            res_36733 = res_36730;
        }
        
        int32_t res_36734;
        int32_t res_36735;
        float res_36736;
        
        if (cond_36714) {
            res_36734 = arg_30895;
            res_36735 = res_36661;
            res_36736 = res_36667;
        } else {
            res_36734 = res_36731;
            res_36735 = res_36732;
            res_36736 = res_36733;
        }
        
        int32_t res_36737;
        int32_t res_36738;
        float res_36739;
        
        if (cond_36710) {
            res_36737 = 1;
            res_36738 = res_36661;
            res_36739 = res_36667;
        } else {
            res_36737 = res_36734;
            res_36738 = res_36735;
            res_36739 = res_36736;
        }
        
        float x_36740 = sitofp_i32_f32(res_36737);
        int32_t x_36741 = res_36737 * g_30887;
        int32_t x_36742 = x_36741 + res_36738;
        float x_36743 = sitofp_i32_f32(res_36738);
        int32_t res_36744;
        int32_t res_36745;
        float res_36746;
        
        if (y_36646) {
            res_36744 = arg_36639;
            res_36745 = arg_30895;
            res_36746 = res_36683;
        } else {
            res_36744 = 0;
            res_36745 = 0;
            res_36746 = 0.0F;
        }
        
        int32_t res_36747;
        int32_t res_36748;
        float res_36749;
        
        if (x_36645) {
            res_36747 = arg_36639;
            res_36748 = 1;
            res_36749 = res_36683;
        } else {
            res_36747 = res_36744;
            res_36748 = res_36745;
            res_36749 = res_36746;
        }
        
        int32_t res_36750;
        int32_t res_36751;
        float res_36752;
        
        if (y_36643) {
            res_36750 = arg_30895;
            res_36751 = arg_36640;
            res_36752 = res_36667;
        } else {
            res_36750 = res_36747;
            res_36751 = res_36748;
            res_36752 = res_36749;
        }
        
        int32_t res_36753;
        int32_t res_36754;
        float res_36755;
        
        if (x_36642) {
            res_36753 = 1;
            res_36754 = arg_36640;
            res_36755 = res_36667;
        } else {
            res_36753 = res_36750;
            res_36754 = res_36751;
            res_36755 = res_36752;
        }
        
        float x_36756 = sitofp_i32_f32(res_36753);
        int32_t x_36757 = res_36753 * g_30887;
        int32_t x_36758 = x_36757 + res_36754;
        float x_36759 = sitofp_i32_f32(res_36754);
        float res_36894;
        
        if (res_36648) {
            float y_36760 = *(__global float *) &mem_38150[x_36705 * 4];
            float y_36761 = res_32512 * y_36760;
            float res_36762 = x_36703 - y_36761;
            float y_36763 = *(__global float *) &mem_38148[x_36705 * 4];
            float y_36764 = res_32512 * y_36763;
            float res_36765 = x_36706 - y_36764;
            char cond_36766 = res_36762 < 0.5F;
            float res_36767;
            
            if (cond_36766) {
                res_36767 = 0.5F;
            } else {
                res_36767 = res_36762;
            }
            
            char cond_36768 = y_32516 < res_36767;
            float res_36769;
            
            if (cond_36768) {
                res_36769 = y_32516;
            } else {
                res_36769 = res_36767;
            }
            
            int32_t res_36770 = fptosi_f32_i32(res_36769);
            int32_t res_36771 = res_36770 + 1;
            char cond_36772 = res_36765 < 0.5F;
            float res_36773;
            
            if (cond_36772) {
                res_36773 = 0.5F;
            } else {
                res_36773 = res_36765;
            }
            
            char cond_36774 = y_32516 < res_36773;
            float res_36775;
            
            if (cond_36774) {
                res_36775 = y_32516;
            } else {
                res_36775 = res_36773;
            }
            
            int32_t res_36776 = fptosi_f32_i32(res_36775);
            int32_t res_36777 = res_36776 + 1;
            float y_36778 = sitofp_i32_f32(res_36770);
            float res_36779 = res_36769 - y_36778;
            float res_36780 = 1.0F - res_36779;
            float y_36781 = sitofp_i32_f32(res_36776);
            float res_36782 = res_36775 - y_36781;
            float res_36783 = 1.0F - res_36782;
            int32_t x_36784 = res_36770 * g_30887;
            int32_t x_36785 = x_36784 + res_36776;
            float y_36786 = *(__global float *) &mem_38148[x_36785 * 4];
            float x_36787 = res_36783 * y_36786;
            int32_t x_36788 = x_36784 + res_36777;
            float y_36789 = *(__global float *) &mem_38148[x_36788 * 4];
            float y_36790 = res_36782 * y_36789;
            float y_36791 = x_36787 + y_36790;
            float x_36792 = res_36780 * y_36791;
            int32_t x_36793 = res_36771 * g_30887;
            int32_t x_36794 = x_36793 + res_36776;
            float y_36795 = *(__global float *) &mem_38148[x_36794 * 4];
            float x_36796 = res_36783 * y_36795;
            int32_t x_36797 = x_36793 + res_36777;
            float y_36798 = *(__global float *) &mem_38148[x_36797 * 4];
            float y_36799 = res_36782 * y_36798;
            float y_36800 = x_36796 + y_36799;
            float y_36801 = res_36779 * y_36800;
            float res_36802 = x_36792 + y_36801;
            float res_36803 = res_36702 * res_36802;
            float y_36804 = *(__global float *) &mem_38150[x_36742 * 4];
            float y_36805 = res_32512 * y_36804;
            float res_36806 = x_36740 - y_36805;
            float y_36807 = *(__global float *) &mem_38148[x_36742 * 4];
            float y_36808 = res_32512 * y_36807;
            float res_36809 = x_36743 - y_36808;
            char cond_36810 = res_36806 < 0.5F;
            float res_36811;
            
            if (cond_36810) {
                res_36811 = 0.5F;
            } else {
                res_36811 = res_36806;
            }
            
            char cond_36812 = y_32516 < res_36811;
            float res_36813;
            
            if (cond_36812) {
                res_36813 = y_32516;
            } else {
                res_36813 = res_36811;
            }
            
            int32_t res_36814 = fptosi_f32_i32(res_36813);
            int32_t res_36815 = res_36814 + 1;
            char cond_36816 = res_36809 < 0.5F;
            float res_36817;
            
            if (cond_36816) {
                res_36817 = 0.5F;
            } else {
                res_36817 = res_36809;
            }
            
            char cond_36818 = y_32516 < res_36817;
            float res_36819;
            
            if (cond_36818) {
                res_36819 = y_32516;
            } else {
                res_36819 = res_36817;
            }
            
            int32_t res_36820 = fptosi_f32_i32(res_36819);
            int32_t res_36821 = res_36820 + 1;
            float y_36822 = sitofp_i32_f32(res_36814);
            float res_36823 = res_36813 - y_36822;
            float res_36824 = 1.0F - res_36823;
            float y_36825 = sitofp_i32_f32(res_36820);
            float res_36826 = res_36819 - y_36825;
            float res_36827 = 1.0F - res_36826;
            int32_t x_36828 = res_36814 * g_30887;
            int32_t x_36829 = x_36828 + res_36820;
            float y_36830 = *(__global float *) &mem_38148[x_36829 * 4];
            float x_36831 = res_36827 * y_36830;
            int32_t x_36832 = x_36828 + res_36821;
            float y_36833 = *(__global float *) &mem_38148[x_36832 * 4];
            float y_36834 = res_36826 * y_36833;
            float y_36835 = x_36831 + y_36834;
            float x_36836 = res_36824 * y_36835;
            int32_t x_36837 = res_36815 * g_30887;
            int32_t x_36838 = x_36837 + res_36820;
            float y_36839 = *(__global float *) &mem_38148[x_36838 * 4];
            float x_36840 = res_36827 * y_36839;
            int32_t x_36841 = x_36837 + res_36821;
            float y_36842 = *(__global float *) &mem_38148[x_36841 * 4];
            float y_36843 = res_36826 * y_36842;
            float y_36844 = x_36840 + y_36843;
            float y_36845 = res_36823 * y_36844;
            float res_36846 = x_36836 + y_36845;
            float res_36847 = res_36739 * res_36846;
            float y_36848 = res_36803 + res_36847;
            float res_36849 = 0.5F * y_36848;
            
            res_36894 = res_36849;
        } else {
            float y_36850 = *(__global float *) &mem_38150[x_36758 * 4];
            float y_36851 = res_32512 * y_36850;
            float res_36852 = x_36756 - y_36851;
            float y_36853 = *(__global float *) &mem_38148[x_36758 * 4];
            float y_36854 = res_32512 * y_36853;
            float res_36855 = x_36759 - y_36854;
            char cond_36856 = res_36852 < 0.5F;
            float res_36857;
            
            if (cond_36856) {
                res_36857 = 0.5F;
            } else {
                res_36857 = res_36852;
            }
            
            char cond_36858 = y_32516 < res_36857;
            float res_36859;
            
            if (cond_36858) {
                res_36859 = y_32516;
            } else {
                res_36859 = res_36857;
            }
            
            int32_t res_36860 = fptosi_f32_i32(res_36859);
            int32_t res_36861 = res_36860 + 1;
            char cond_36862 = res_36855 < 0.5F;
            float res_36863;
            
            if (cond_36862) {
                res_36863 = 0.5F;
            } else {
                res_36863 = res_36855;
            }
            
            char cond_36864 = y_32516 < res_36863;
            float res_36865;
            
            if (cond_36864) {
                res_36865 = y_32516;
            } else {
                res_36865 = res_36863;
            }
            
            int32_t res_36866 = fptosi_f32_i32(res_36865);
            int32_t res_36867 = res_36866 + 1;
            float y_36868 = sitofp_i32_f32(res_36860);
            float res_36869 = res_36859 - y_36868;
            float res_36870 = 1.0F - res_36869;
            float y_36871 = sitofp_i32_f32(res_36866);
            float res_36872 = res_36865 - y_36871;
            float res_36873 = 1.0F - res_36872;
            int32_t x_36874 = res_36860 * g_30887;
            int32_t x_36875 = x_36874 + res_36866;
            float y_36876 = *(__global float *) &mem_38148[x_36875 * 4];
            float x_36877 = res_36873 * y_36876;
            int32_t x_36878 = x_36874 + res_36867;
            float y_36879 = *(__global float *) &mem_38148[x_36878 * 4];
            float y_36880 = res_36872 * y_36879;
            float y_36881 = x_36877 + y_36880;
            float x_36882 = res_36870 * y_36881;
            int32_t x_36883 = res_36861 * g_30887;
            int32_t x_36884 = x_36883 + res_36866;
            float y_36885 = *(__global float *) &mem_38148[x_36884 * 4];
            float x_36886 = res_36873 * y_36885;
            int32_t x_36887 = x_36883 + res_36867;
            float y_36888 = *(__global float *) &mem_38148[x_36887 * 4];
            float y_36889 = res_36872 * y_36888;
            float y_36890 = x_36886 + y_36889;
            float y_36891 = res_36869 * y_36890;
            float res_36892 = x_36882 + y_36891;
            float res_36893 = res_36755 * res_36892;
            
            res_36894 = res_36893;
        }
        res_36895 = res_36894;
    }
    // write kernel result
    {
        *(__global float *) &mem_38152[i_36281 * 4] = res_36895;
        *(__global float *) &mem_38154[i_36281 * 4] = res_36595;
    }
}
__kernel void map_kernel_36898(char eq_x_z_30920, __global
                               unsigned char *mem_38152, char eq_x_z_30916,
                               char eq_x_y_30924, int32_t res_30909,
                               float y_31410, int32_t y_30914,
                               char eq_x_y_30922, __global
                               unsigned char *mem_38154, char eq_x_y_30918,
                               int32_t arg_30895, int32_t x_30903,
                               int32_t g_30887, __global
                               unsigned char *mem_38156)
{
    const uint kernel_thread_index_36898 = get_global_id(0);
    
    if (kernel_thread_index_36898 >= x_30903)
        return;
    
    int32_t i_36899;
    
    // compute thread index
    {
        i_36899 = kernel_thread_index_36898;
    }
    // read kernel parameters
    { }
    
    int32_t res_36901 = sdiv32(i_36899, g_30887);
    int32_t res_36902 = smod32(i_36899, g_30887);
    char x_36903 = sle32(1, res_36901);
    char y_36904 = sle32(res_36901, arg_30895);
    char x_36905 = x_36903 && y_36904;
    char y_36906 = sle32(1, res_36902);
    char x_36907 = x_36905 && y_36906;
    char y_36908 = sle32(res_36902, arg_30895);
    char res_36909 = x_36907 && y_36908;
    int32_t i_36910 = res_36901 + 1;
    int32_t x_36911 = i_36910 * g_30887;
    int32_t x_36912 = x_36911 + res_36902;
    int32_t i_36913 = res_36901 - 1;
    int32_t x_36914 = i_36913 * g_30887;
    int32_t x_36915 = x_36914 + res_36902;
    int32_t i_36916 = res_36902 + 1;
    int32_t x_36917 = res_36901 * g_30887;
    int32_t x_36918 = x_36917 + i_36916;
    int32_t i_36919 = res_36902 - 1;
    int32_t x_36920 = x_36917 + i_36919;
    float res_37085;
    
    if (res_36909) {
        float x_36921 = *(__global float *) &mem_38154[x_36912 * 4];
        float y_36922 = *(__global float *) &mem_38154[x_36915 * 4];
        float x_36923 = x_36921 - y_36922;
        float y_36924 = *(__global float *) &mem_38152[x_36918 * 4];
        float x_36925 = x_36923 + y_36924;
        float y_36926 = *(__global float *) &mem_38152[x_36920 * 4];
        float y_36927 = x_36925 - y_36926;
        float x_36928 = -0.5F * y_36927;
        float res_36929 = x_36928 / y_31410;
        
        res_37085 = res_36929;
    } else {
        int32_t arg_36930 = sdiv32(res_36901, res_30909);
        int32_t arg_36931 = sdiv32(res_36902, res_30909);
        char x_36932 = arg_36930 == 0;
        char y_36933 = arg_36930 == y_30914;
        char x_36934 = x_36932 || y_36933;
        char x_36935 = arg_36931 == 0;
        char y_36936 = arg_36931 == y_30914;
        char y_36937 = x_36935 || y_36936;
        char res_36938 = x_36934 && y_36937;
        char cond_36939 = x_36932 && x_36935;
        char cond_36940 = x_36932 && y_36936;
        char cond_36941 = y_36933 && x_36935;
        int32_t res_36942;
        int32_t res_36943;
        
        if (cond_36941) {
            res_36942 = 1;
            res_36943 = 0;
        } else {
            res_36942 = arg_30895;
            res_36943 = y_30914;
        }
        
        int32_t res_36944;
        int32_t res_36945;
        int32_t res_36946;
        int32_t res_36947;
        
        if (cond_36940) {
            res_36944 = 1;
            res_36945 = y_30914;
            res_36946 = 0;
            res_36947 = arg_30895;
        } else {
            res_36944 = arg_30895;
            res_36945 = res_36943;
            res_36946 = y_30914;
            res_36947 = res_36942;
        }
        
        int32_t res_36948;
        int32_t res_36949;
        int32_t res_36950;
        int32_t res_36951;
        
        if (cond_36939) {
            res_36948 = 1;
            res_36949 = 0;
            res_36950 = 0;
            res_36951 = 1;
        } else {
            res_36948 = res_36944;
            res_36949 = res_36945;
            res_36950 = res_36946;
            res_36951 = res_36947;
        }
        
        char not_p_36952 = !cond_36940;
        char p_and_eq_x_y_36953 = not_p_36952 && eq_x_z_30916;
        char not_p_36954 = !cond_36939;
        char p_and_eq_x_y_36955 = not_p_36954 && p_and_eq_x_y_36953;
        char p_and_eq_x_y_36956 = cond_36940 && eq_x_y_30918;
        char p_and_eq_x_y_36957 = not_p_36952 && eq_x_z_30920;
        char eq_x_z_36958 = p_and_eq_x_y_36956 || p_and_eq_x_y_36957;
        char p_and_eq_x_y_36959 = cond_36939 && eq_x_y_30918;
        char p_and_eq_x_y_36960 = not_p_36954 && eq_x_z_36958;
        char cond_36961 = p_and_eq_x_y_36959 || p_and_eq_x_y_36960;
        char not_p_36962 = !cond_36941;
        char p_and_eq_x_y_36963 = not_p_36962 && eq_x_y_30922;
        char eq_x_z_36964 = cond_36941 || p_and_eq_x_y_36963;
        char p_and_eq_x_y_36965 = cond_36940 && eq_x_y_30922;
        char p_and_eq_x_y_36966 = not_p_36952 && eq_x_z_36964;
        char eq_x_z_36967 = p_and_eq_x_y_36965 || p_and_eq_x_y_36966;
        char p_and_eq_x_y_36968 = not_p_36954 && eq_x_z_36967;
        char cond_36969 = cond_36939 || p_and_eq_x_y_36968;
        char p_and_eq_x_y_36970 = cond_36941 && eq_x_y_30924;
        char eq_x_z_36971 = p_and_eq_x_y_36970 || not_p_36962;
        char p_and_eq_x_y_36972 = not_p_36952 && eq_x_z_36971;
        char eq_x_z_36973 = cond_36940 || p_and_eq_x_y_36972;
        char p_and_eq_x_y_36974 = cond_36939 && eq_x_y_30924;
        char p_and_eq_x_y_36975 = not_p_36954 && eq_x_z_36973;
        char cond_36976 = p_and_eq_x_y_36974 || p_and_eq_x_y_36975;
        int32_t res_36977;
        int32_t res_36978;
        
        if (cond_36976) {
            res_36977 = res_36948;
            res_36978 = arg_30895;
        } else {
            res_36977 = 0;
            res_36978 = 0;
        }
        
        int32_t res_36979;
        int32_t res_36980;
        
        if (cond_36969) {
            res_36979 = res_36948;
            res_36980 = 1;
        } else {
            res_36979 = res_36977;
            res_36980 = res_36978;
        }
        
        int32_t res_36981;
        int32_t res_36982;
        
        if (cond_36961) {
            res_36981 = arg_30895;
            res_36982 = res_36949;
        } else {
            res_36981 = res_36979;
            res_36982 = res_36980;
        }
        
        int32_t res_36983;
        int32_t res_36984;
        
        if (p_and_eq_x_y_36955) {
            res_36983 = 1;
            res_36984 = res_36949;
        } else {
            res_36983 = res_36981;
            res_36984 = res_36982;
        }
        
        int32_t i_36985 = res_36983 + 1;
        int32_t x_36986 = i_36985 * g_30887;
        int32_t x_36987 = x_36986 + res_36984;
        int32_t i_36988 = res_36983 - 1;
        int32_t x_36989 = i_36988 * g_30887;
        int32_t x_36990 = x_36989 + res_36984;
        int32_t i_36991 = res_36984 + 1;
        int32_t x_36992 = res_36983 * g_30887;
        int32_t x_36993 = x_36992 + i_36991;
        int32_t i_36994 = res_36984 - 1;
        int32_t x_36995 = x_36992 + i_36994;
        char p_and_eq_x_y_36996 = not_p_36952 && eq_x_y_30922;
        char eq_x_z_36997 = cond_36940 || p_and_eq_x_y_36996;
        char p_and_eq_x_y_36998 = not_p_36954 && eq_x_z_36997;
        char cond_36999 = cond_36939 || p_and_eq_x_y_36998;
        char p_and_eq_x_y_37000 = cond_36940 && eq_x_y_30924;
        char eq_x_z_37001 = p_and_eq_x_y_37000 || not_p_36952;
        char p_and_eq_x_y_37002 = not_p_36954 && eq_x_z_37001;
        char cond_37003 = p_and_eq_x_y_36974 || p_and_eq_x_y_37002;
        char p_and_eq_x_y_37004 = not_p_36962 && eq_x_z_30916;
        char p_and_eq_x_y_37005 = cond_36940 && eq_x_z_30916;
        char p_and_eq_x_y_37006 = not_p_36952 && p_and_eq_x_y_37004;
        char eq_x_z_37007 = p_and_eq_x_y_37005 || p_and_eq_x_y_37006;
        char p_and_eq_x_y_37008 = not_p_36954 && eq_x_z_37007;
        char p_and_eq_x_y_37009 = cond_36941 && eq_x_y_30918;
        char p_and_eq_x_y_37010 = not_p_36962 && eq_x_z_30920;
        char eq_x_z_37011 = p_and_eq_x_y_37009 || p_and_eq_x_y_37010;
        char p_and_eq_x_y_37012 = cond_36940 && eq_x_z_30920;
        char p_and_eq_x_y_37013 = not_p_36952 && eq_x_z_37011;
        char eq_x_z_37014 = p_and_eq_x_y_37012 || p_and_eq_x_y_37013;
        char p_and_eq_x_y_37015 = not_p_36954 && eq_x_z_37014;
        char cond_37016 = p_and_eq_x_y_36959 || p_and_eq_x_y_37015;
        int32_t res_37017;
        int32_t res_37018;
        
        if (cond_37016) {
            res_37017 = res_36950;
            res_37018 = arg_30895;
        } else {
            res_37017 = 0;
            res_37018 = 0;
        }
        
        int32_t res_37019;
        int32_t res_37020;
        
        if (p_and_eq_x_y_37008) {
            res_37019 = res_36950;
            res_37020 = 1;
        } else {
            res_37019 = res_37017;
            res_37020 = res_37018;
        }
        
        int32_t res_37021;
        int32_t res_37022;
        
        if (cond_37003) {
            res_37021 = arg_30895;
            res_37022 = res_36951;
        } else {
            res_37021 = res_37019;
            res_37022 = res_37020;
        }
        
        int32_t res_37023;
        int32_t res_37024;
        
        if (cond_36999) {
            res_37023 = 1;
            res_37024 = res_36951;
        } else {
            res_37023 = res_37021;
            res_37024 = res_37022;
        }
        
        int32_t i_37025 = res_37023 + 1;
        int32_t x_37026 = i_37025 * g_30887;
        int32_t x_37027 = x_37026 + res_37024;
        int32_t i_37028 = res_37023 - 1;
        int32_t x_37029 = i_37028 * g_30887;
        int32_t x_37030 = x_37029 + res_37024;
        int32_t i_37031 = res_37024 + 1;
        int32_t x_37032 = res_37023 * g_30887;
        int32_t x_37033 = x_37032 + i_37031;
        int32_t i_37034 = res_37024 - 1;
        int32_t x_37035 = x_37032 + i_37034;
        int32_t res_37036;
        int32_t res_37037;
        
        if (y_36936) {
            res_37036 = arg_36930;
            res_37037 = arg_30895;
        } else {
            res_37036 = 0;
            res_37037 = 0;
        }
        
        int32_t res_37038;
        int32_t res_37039;
        
        if (x_36935) {
            res_37038 = arg_36930;
            res_37039 = 1;
        } else {
            res_37038 = res_37036;
            res_37039 = res_37037;
        }
        
        int32_t res_37040;
        int32_t res_37041;
        
        if (y_36933) {
            res_37040 = arg_30895;
            res_37041 = arg_36931;
        } else {
            res_37040 = res_37038;
            res_37041 = res_37039;
        }
        
        int32_t res_37042;
        int32_t res_37043;
        
        if (x_36932) {
            res_37042 = 1;
            res_37043 = arg_36931;
        } else {
            res_37042 = res_37040;
            res_37043 = res_37041;
        }
        
        int32_t i_37044 = res_37042 + 1;
        int32_t x_37045 = i_37044 * g_30887;
        int32_t x_37046 = x_37045 + res_37043;
        int32_t i_37047 = res_37042 - 1;
        int32_t x_37048 = i_37047 * g_30887;
        int32_t x_37049 = x_37048 + res_37043;
        int32_t i_37050 = res_37043 + 1;
        int32_t x_37051 = res_37042 * g_30887;
        int32_t x_37052 = x_37051 + i_37050;
        int32_t i_37053 = res_37043 - 1;
        int32_t x_37054 = x_37051 + i_37053;
        float res_37084;
        
        if (res_36938) {
            float x_37055 = *(__global float *) &mem_38154[x_36987 * 4];
            float y_37056 = *(__global float *) &mem_38154[x_36990 * 4];
            float x_37057 = x_37055 - y_37056;
            float y_37058 = *(__global float *) &mem_38152[x_36993 * 4];
            float x_37059 = x_37057 + y_37058;
            float y_37060 = *(__global float *) &mem_38152[x_36995 * 4];
            float y_37061 = x_37059 - y_37060;
            float x_37062 = -0.5F * y_37061;
            float res_37063 = x_37062 / y_31410;
            float x_37064 = *(__global float *) &mem_38154[x_37027 * 4];
            float y_37065 = *(__global float *) &mem_38154[x_37030 * 4];
            float x_37066 = x_37064 - y_37065;
            float y_37067 = *(__global float *) &mem_38152[x_37033 * 4];
            float x_37068 = x_37066 + y_37067;
            float y_37069 = *(__global float *) &mem_38152[x_37035 * 4];
            float y_37070 = x_37068 - y_37069;
            float x_37071 = -0.5F * y_37070;
            float res_37072 = x_37071 / y_31410;
            float y_37073 = res_37063 + res_37072;
            float res_37074 = 0.5F * y_37073;
            
            res_37084 = res_37074;
        } else {
            float x_37075 = *(__global float *) &mem_38154[x_37046 * 4];
            float y_37076 = *(__global float *) &mem_38154[x_37049 * 4];
            float x_37077 = x_37075 - y_37076;
            float y_37078 = *(__global float *) &mem_38152[x_37052 * 4];
            float x_37079 = x_37077 + y_37078;
            float y_37080 = *(__global float *) &mem_38152[x_37054 * 4];
            float y_37081 = x_37079 - y_37080;
            float x_37082 = -0.5F * y_37081;
            float res_37083 = x_37082 / y_31410;
            
            res_37084 = res_37083;
        }
        res_37085 = res_37084;
    }
    // write kernel result
    {
        *(__global float *) &mem_38156[i_36899 * 4] = res_37085;
    }
}
__kernel void map_kernel_37088(char eq_x_z_30920, char eq_x_z_30916,
                               char eq_x_y_30924, __global
                               unsigned char *mem_38156, int32_t res_30909,
                               int32_t y_30914, char eq_x_y_30922,
                               char eq_x_y_30918, __global
                               unsigned char *S1_mem_38158, int32_t arg_30895,
                               int32_t x_30903, int32_t g_30887, __global
                               unsigned char *mem_38160)
{
    const uint kernel_thread_index_37088 = get_global_id(0);
    
    if (kernel_thread_index_37088 >= x_30903)
        return;
    
    int32_t i_37089;
    
    // compute thread index
    {
        i_37089 = kernel_thread_index_37088;
    }
    // read kernel parameters
    { }
    
    int32_t res_37091 = sdiv32(i_37089, g_30887);
    int32_t res_37092 = smod32(i_37089, g_30887);
    char x_37093 = sle32(1, res_37091);
    char y_37094 = sle32(res_37091, arg_30895);
    char x_37095 = x_37093 && y_37094;
    char y_37096 = sle32(1, res_37092);
    char x_37097 = x_37095 && y_37096;
    char y_37098 = sle32(res_37092, arg_30895);
    char res_37099 = x_37097 && y_37098;
    int32_t x_37100 = res_37091 * g_30887;
    int32_t x_37101 = x_37100 + res_37092;
    int32_t i_37102 = res_37091 - 1;
    int32_t i_37103 = res_37091 + 1;
    int32_t i_37104 = res_37092 - 1;
    int32_t i_37105 = res_37092 + 1;
    float res_37274;
    
    if (res_37099) {
        float x_37106 = *(__global float *) &mem_38156[x_37101 * 4];
        float x_37107 = *(__global float *) &S1_mem_38158[(i_37102 * g_30887 +
                                                           res_37092) * 4];
        float y_37108 = *(__global float *) &S1_mem_38158[(i_37103 * g_30887 +
                                                           res_37092) * 4];
        float x_37109 = x_37107 + y_37108;
        float y_37110 = *(__global float *) &S1_mem_38158[(res_37091 * g_30887 +
                                                           i_37104) * 4];
        float x_37111 = x_37109 + y_37110;
        float y_37112 = *(__global float *) &S1_mem_38158[(res_37091 * g_30887 +
                                                           i_37105) * 4];
        float y_37113 = x_37111 + y_37112;
        float x_37114 = x_37106 + y_37113;
        float res_37115 = x_37114 / 4.0F;
        
        res_37274 = res_37115;
    } else {
        int32_t arg_37116 = sdiv32(res_37091, res_30909);
        int32_t arg_37117 = sdiv32(res_37092, res_30909);
        char x_37118 = arg_37116 == 0;
        char y_37119 = arg_37116 == y_30914;
        char x_37120 = x_37118 || y_37119;
        char x_37121 = arg_37117 == 0;
        char y_37122 = arg_37117 == y_30914;
        char y_37123 = x_37121 || y_37122;
        char res_37124 = x_37120 && y_37123;
        char cond_37125 = x_37118 && x_37121;
        char cond_37126 = x_37118 && y_37122;
        char cond_37127 = y_37119 && x_37121;
        int32_t res_37128;
        int32_t res_37129;
        
        if (cond_37127) {
            res_37128 = 1;
            res_37129 = 0;
        } else {
            res_37128 = arg_30895;
            res_37129 = y_30914;
        }
        
        int32_t res_37130;
        int32_t res_37131;
        int32_t res_37132;
        int32_t res_37133;
        
        if (cond_37126) {
            res_37130 = 1;
            res_37131 = y_30914;
            res_37132 = 0;
            res_37133 = arg_30895;
        } else {
            res_37130 = arg_30895;
            res_37131 = res_37129;
            res_37132 = y_30914;
            res_37133 = res_37128;
        }
        
        int32_t res_37134;
        int32_t res_37135;
        int32_t res_37136;
        int32_t res_37137;
        
        if (cond_37125) {
            res_37134 = 1;
            res_37135 = 0;
            res_37136 = 0;
            res_37137 = 1;
        } else {
            res_37134 = res_37130;
            res_37135 = res_37131;
            res_37136 = res_37132;
            res_37137 = res_37133;
        }
        
        char not_p_37138 = !cond_37126;
        char p_and_eq_x_y_37139 = not_p_37138 && eq_x_z_30916;
        char not_p_37140 = !cond_37125;
        char p_and_eq_x_y_37141 = not_p_37140 && p_and_eq_x_y_37139;
        char p_and_eq_x_y_37142 = cond_37126 && eq_x_y_30918;
        char p_and_eq_x_y_37143 = not_p_37138 && eq_x_z_30920;
        char eq_x_z_37144 = p_and_eq_x_y_37142 || p_and_eq_x_y_37143;
        char p_and_eq_x_y_37145 = cond_37125 && eq_x_y_30918;
        char p_and_eq_x_y_37146 = not_p_37140 && eq_x_z_37144;
        char cond_37147 = p_and_eq_x_y_37145 || p_and_eq_x_y_37146;
        char not_p_37148 = !cond_37127;
        char p_and_eq_x_y_37149 = not_p_37148 && eq_x_y_30922;
        char eq_x_z_37150 = cond_37127 || p_and_eq_x_y_37149;
        char p_and_eq_x_y_37151 = cond_37126 && eq_x_y_30922;
        char p_and_eq_x_y_37152 = not_p_37138 && eq_x_z_37150;
        char eq_x_z_37153 = p_and_eq_x_y_37151 || p_and_eq_x_y_37152;
        char p_and_eq_x_y_37154 = not_p_37140 && eq_x_z_37153;
        char cond_37155 = cond_37125 || p_and_eq_x_y_37154;
        char p_and_eq_x_y_37156 = cond_37127 && eq_x_y_30924;
        char eq_x_z_37157 = p_and_eq_x_y_37156 || not_p_37148;
        char p_and_eq_x_y_37158 = not_p_37138 && eq_x_z_37157;
        char eq_x_z_37159 = cond_37126 || p_and_eq_x_y_37158;
        char p_and_eq_x_y_37160 = cond_37125 && eq_x_y_30924;
        char p_and_eq_x_y_37161 = not_p_37140 && eq_x_z_37159;
        char cond_37162 = p_and_eq_x_y_37160 || p_and_eq_x_y_37161;
        int32_t res_37163;
        int32_t res_37164;
        float res_37165;
        
        if (cond_37162) {
            res_37163 = res_37134;
            res_37164 = arg_30895;
            res_37165 = 1.0F;
        } else {
            res_37163 = 0;
            res_37164 = 0;
            res_37165 = 0.0F;
        }
        
        int32_t res_37166;
        int32_t res_37167;
        float res_37168;
        
        if (cond_37155) {
            res_37166 = res_37134;
            res_37167 = 1;
            res_37168 = 1.0F;
        } else {
            res_37166 = res_37163;
            res_37167 = res_37164;
            res_37168 = res_37165;
        }
        
        int32_t res_37169;
        int32_t res_37170;
        float res_37171;
        
        if (cond_37147) {
            res_37169 = arg_30895;
            res_37170 = res_37135;
            res_37171 = 1.0F;
        } else {
            res_37169 = res_37166;
            res_37170 = res_37167;
            res_37171 = res_37168;
        }
        
        int32_t res_37172;
        int32_t res_37173;
        float res_37174;
        
        if (p_and_eq_x_y_37141) {
            res_37172 = 1;
            res_37173 = res_37135;
            res_37174 = 1.0F;
        } else {
            res_37172 = res_37169;
            res_37173 = res_37170;
            res_37174 = res_37171;
        }
        
        int32_t x_37175 = res_37172 * g_30887;
        int32_t x_37176 = x_37175 + res_37173;
        int32_t i_37177 = res_37172 - 1;
        int32_t i_37178 = res_37172 + 1;
        int32_t i_37179 = res_37173 - 1;
        int32_t i_37180 = res_37173 + 1;
        char p_and_eq_x_y_37181 = not_p_37138 && eq_x_y_30922;
        char eq_x_z_37182 = cond_37126 || p_and_eq_x_y_37181;
        char p_and_eq_x_y_37183 = not_p_37140 && eq_x_z_37182;
        char cond_37184 = cond_37125 || p_and_eq_x_y_37183;
        char p_and_eq_x_y_37185 = cond_37126 && eq_x_y_30924;
        char eq_x_z_37186 = p_and_eq_x_y_37185 || not_p_37138;
        char p_and_eq_x_y_37187 = not_p_37140 && eq_x_z_37186;
        char cond_37188 = p_and_eq_x_y_37160 || p_and_eq_x_y_37187;
        char p_and_eq_x_y_37189 = not_p_37148 && eq_x_z_30916;
        char p_and_eq_x_y_37190 = cond_37126 && eq_x_z_30916;
        char p_and_eq_x_y_37191 = not_p_37138 && p_and_eq_x_y_37189;
        char eq_x_z_37192 = p_and_eq_x_y_37190 || p_and_eq_x_y_37191;
        char p_and_eq_x_y_37193 = not_p_37140 && eq_x_z_37192;
        char p_and_eq_x_y_37194 = cond_37127 && eq_x_y_30918;
        char p_and_eq_x_y_37195 = not_p_37148 && eq_x_z_30920;
        char eq_x_z_37196 = p_and_eq_x_y_37194 || p_and_eq_x_y_37195;
        char p_and_eq_x_y_37197 = cond_37126 && eq_x_z_30920;
        char p_and_eq_x_y_37198 = not_p_37138 && eq_x_z_37196;
        char eq_x_z_37199 = p_and_eq_x_y_37197 || p_and_eq_x_y_37198;
        char p_and_eq_x_y_37200 = not_p_37140 && eq_x_z_37199;
        char cond_37201 = p_and_eq_x_y_37145 || p_and_eq_x_y_37200;
        int32_t res_37202;
        int32_t res_37203;
        float res_37204;
        
        if (cond_37201) {
            res_37202 = res_37136;
            res_37203 = arg_30895;
            res_37204 = 1.0F;
        } else {
            res_37202 = 0;
            res_37203 = 0;
            res_37204 = 0.0F;
        }
        
        int32_t res_37205;
        int32_t res_37206;
        float res_37207;
        
        if (p_and_eq_x_y_37193) {
            res_37205 = res_37136;
            res_37206 = 1;
            res_37207 = 1.0F;
        } else {
            res_37205 = res_37202;
            res_37206 = res_37203;
            res_37207 = res_37204;
        }
        
        int32_t res_37208;
        int32_t res_37209;
        float res_37210;
        
        if (cond_37188) {
            res_37208 = arg_30895;
            res_37209 = res_37137;
            res_37210 = 1.0F;
        } else {
            res_37208 = res_37205;
            res_37209 = res_37206;
            res_37210 = res_37207;
        }
        
        int32_t res_37211;
        int32_t res_37212;
        float res_37213;
        
        if (cond_37184) {
            res_37211 = 1;
            res_37212 = res_37137;
            res_37213 = 1.0F;
        } else {
            res_37211 = res_37208;
            res_37212 = res_37209;
            res_37213 = res_37210;
        }
        
        int32_t x_37214 = res_37211 * g_30887;
        int32_t x_37215 = x_37214 + res_37212;
        int32_t i_37216 = res_37211 - 1;
        int32_t i_37217 = res_37211 + 1;
        int32_t i_37218 = res_37212 - 1;
        int32_t i_37219 = res_37212 + 1;
        int32_t res_37220;
        int32_t res_37221;
        float res_37222;
        
        if (y_37122) {
            res_37220 = arg_37116;
            res_37221 = arg_30895;
            res_37222 = 1.0F;
        } else {
            res_37220 = 0;
            res_37221 = 0;
            res_37222 = 0.0F;
        }
        
        int32_t res_37223;
        int32_t res_37224;
        float res_37225;
        
        if (x_37121) {
            res_37223 = arg_37116;
            res_37224 = 1;
            res_37225 = 1.0F;
        } else {
            res_37223 = res_37220;
            res_37224 = res_37221;
            res_37225 = res_37222;
        }
        
        int32_t res_37226;
        int32_t res_37227;
        float res_37228;
        
        if (y_37119) {
            res_37226 = arg_30895;
            res_37227 = arg_37117;
            res_37228 = 1.0F;
        } else {
            res_37226 = res_37223;
            res_37227 = res_37224;
            res_37228 = res_37225;
        }
        
        int32_t res_37229;
        int32_t res_37230;
        float res_37231;
        
        if (x_37118) {
            res_37229 = 1;
            res_37230 = arg_37117;
            res_37231 = 1.0F;
        } else {
            res_37229 = res_37226;
            res_37230 = res_37227;
            res_37231 = res_37228;
        }
        
        int32_t x_37232 = res_37229 * g_30887;
        int32_t x_37233 = x_37232 + res_37230;
        int32_t i_37234 = res_37229 - 1;
        int32_t i_37235 = res_37229 + 1;
        int32_t i_37236 = res_37230 - 1;
        int32_t i_37237 = res_37230 + 1;
        float res_37273;
        
        if (res_37124) {
            float x_37238 = *(__global float *) &mem_38156[x_37176 * 4];
            float x_37239 = *(__global float *) &S1_mem_38158[(i_37177 *
                                                               g_30887 +
                                                               res_37173) * 4];
            float y_37240 = *(__global float *) &S1_mem_38158[(i_37178 *
                                                               g_30887 +
                                                               res_37173) * 4];
            float x_37241 = x_37239 + y_37240;
            float y_37242 = *(__global float *) &S1_mem_38158[(res_37172 *
                                                               g_30887 +
                                                               i_37179) * 4];
            float x_37243 = x_37241 + y_37242;
            float y_37244 = *(__global float *) &S1_mem_38158[(res_37172 *
                                                               g_30887 +
                                                               i_37180) * 4];
            float y_37245 = x_37243 + y_37244;
            float x_37246 = x_37238 + y_37245;
            float res_37247 = x_37246 / 4.0F;
            float res_37248 = res_37174 * res_37247;
            float x_37249 = *(__global float *) &mem_38156[x_37215 * 4];
            float x_37250 = *(__global float *) &S1_mem_38158[(i_37216 *
                                                               g_30887 +
                                                               res_37212) * 4];
            float y_37251 = *(__global float *) &S1_mem_38158[(i_37217 *
                                                               g_30887 +
                                                               res_37212) * 4];
            float x_37252 = x_37250 + y_37251;
            float y_37253 = *(__global float *) &S1_mem_38158[(res_37211 *
                                                               g_30887 +
                                                               i_37218) * 4];
            float x_37254 = x_37252 + y_37253;
            float y_37255 = *(__global float *) &S1_mem_38158[(res_37211 *
                                                               g_30887 +
                                                               i_37219) * 4];
            float y_37256 = x_37254 + y_37255;
            float x_37257 = x_37249 + y_37256;
            float res_37258 = x_37257 / 4.0F;
            float res_37259 = res_37213 * res_37258;
            float y_37260 = res_37248 + res_37259;
            float res_37261 = 0.5F * y_37260;
            
            res_37273 = res_37261;
        } else {
            float x_37262 = *(__global float *) &mem_38156[x_37233 * 4];
            float x_37263 = *(__global float *) &S1_mem_38158[(i_37234 *
                                                               g_30887 +
                                                               res_37230) * 4];
            float y_37264 = *(__global float *) &S1_mem_38158[(i_37235 *
                                                               g_30887 +
                                                               res_37230) * 4];
            float x_37265 = x_37263 + y_37264;
            float y_37266 = *(__global float *) &S1_mem_38158[(res_37229 *
                                                               g_30887 +
                                                               i_37236) * 4];
            float x_37267 = x_37265 + y_37266;
            float y_37268 = *(__global float *) &S1_mem_38158[(res_37229 *
                                                               g_30887 +
                                                               i_37237) * 4];
            float y_37269 = x_37267 + y_37268;
            float x_37270 = x_37262 + y_37269;
            float res_37271 = x_37270 / 4.0F;
            float res_37272 = res_37231 * res_37271;
            
            res_37273 = res_37272;
        }
        res_37274 = res_37273;
    }
    // write kernel result
    {
        *(__global float *) &mem_38160[i_37089 * 4] = res_37274;
    }
}
__kernel void map_kernel_37277(char eq_x_z_30920, char eq_x_z_30916,
                               char eq_x_y_30924, float x_31869,
                               int32_t res_30909, int32_t y_30914,
                               char eq_x_y_30922, __global
                               unsigned char *mem_38154, __global
                               unsigned char *S1_mem_38162, char eq_x_y_30918,
                               int32_t arg_30895, int32_t x_30903,
                               int32_t g_30887, __global
                               unsigned char *mem_38164)
{
    const uint kernel_thread_index_37277 = get_global_id(0);
    
    if (kernel_thread_index_37277 >= x_30903)
        return;
    
    int32_t i_37278;
    
    // compute thread index
    {
        i_37278 = kernel_thread_index_37277;
    }
    // read kernel parameters
    { }
    
    int32_t res_37280 = sdiv32(i_37278, g_30887);
    int32_t res_37281 = smod32(i_37278, g_30887);
    char x_37282 = sle32(1, res_37280);
    char y_37283 = sle32(res_37280, arg_30895);
    char x_37284 = x_37282 && y_37283;
    char y_37285 = sle32(1, res_37281);
    char x_37286 = x_37284 && y_37285;
    char y_37287 = sle32(res_37281, arg_30895);
    char res_37288 = x_37286 && y_37287;
    int32_t x_37289 = res_37280 * g_30887;
    int32_t x_37290 = x_37289 + res_37281;
    int32_t i_37291 = res_37280 + 1;
    int32_t i_37292 = res_37280 + -1;
    float res_37445;
    
    if (res_37288) {
        float x_37293 = *(__global float *) &mem_38154[x_37290 * 4];
        float x_37294 = *(__global float *) &S1_mem_38162[(i_37291 * g_30887 +
                                                           res_37281) * 4];
        float y_37295 = *(__global float *) &S1_mem_38162[(i_37292 * g_30887 +
                                                           res_37281) * 4];
        float y_37296 = x_37294 - y_37295;
        float y_37297 = x_31869 * y_37296;
        float res_37298 = x_37293 - y_37297;
        
        res_37445 = res_37298;
    } else {
        int32_t arg_37299 = sdiv32(res_37280, res_30909);
        int32_t arg_37300 = sdiv32(res_37281, res_30909);
        int32_t arg_37301 = sdiv32(1, res_30909);
        int32_t arg_37302 = sdiv32(-1, res_30909);
        char x_37303 = arg_37299 == 0;
        char y_37304 = arg_37299 == y_30914;
        char x_37305 = x_37303 || y_37304;
        char x_37306 = arg_37300 == 0;
        char y_37307 = arg_37300 == y_30914;
        char y_37308 = x_37306 || y_37307;
        char res_37309 = x_37305 && y_37308;
        char cond_37310 = x_37303 && x_37306;
        char cond_37311 = x_37303 && y_37307;
        char cond_37312 = y_37304 && x_37306;
        int32_t res_37313;
        int32_t res_37314;
        
        if (cond_37312) {
            res_37313 = 1;
            res_37314 = 0;
        } else {
            res_37313 = arg_30895;
            res_37314 = y_30914;
        }
        
        int32_t res_37315;
        int32_t res_37316;
        int32_t res_37317;
        int32_t res_37318;
        
        if (cond_37311) {
            res_37315 = 1;
            res_37316 = y_30914;
            res_37317 = 0;
            res_37318 = arg_30895;
        } else {
            res_37315 = arg_30895;
            res_37316 = res_37314;
            res_37317 = y_30914;
            res_37318 = res_37313;
        }
        
        int32_t res_37319;
        int32_t res_37320;
        int32_t res_37321;
        int32_t res_37322;
        
        if (cond_37310) {
            res_37319 = 1;
            res_37320 = 0;
            res_37321 = 0;
            res_37322 = 1;
        } else {
            res_37319 = res_37315;
            res_37320 = res_37316;
            res_37321 = res_37317;
            res_37322 = res_37318;
        }
        
        char not_p_37323 = !cond_37311;
        char p_and_eq_x_y_37324 = not_p_37323 && eq_x_z_30916;
        char not_p_37325 = !cond_37310;
        char p_and_eq_x_y_37326 = not_p_37325 && p_and_eq_x_y_37324;
        char cond_37327 = arg_37301 == 1;
        float res_37328;
        
        if (cond_37327) {
            res_37328 = -1.0F;
        } else {
            res_37328 = 1.0F;
        }
        
        char p_and_eq_x_y_37329 = cond_37311 && eq_x_y_30918;
        char p_and_eq_x_y_37330 = not_p_37323 && eq_x_z_30920;
        char eq_x_z_37331 = p_and_eq_x_y_37329 || p_and_eq_x_y_37330;
        char p_and_eq_x_y_37332 = cond_37310 && eq_x_y_30918;
        char p_and_eq_x_y_37333 = not_p_37325 && eq_x_z_37331;
        char cond_37334 = p_and_eq_x_y_37332 || p_and_eq_x_y_37333;
        char not_p_37335 = !cond_37312;
        char p_and_eq_x_y_37336 = not_p_37335 && eq_x_y_30922;
        char eq_x_z_37337 = cond_37312 || p_and_eq_x_y_37336;
        char p_and_eq_x_y_37338 = cond_37311 && eq_x_y_30922;
        char p_and_eq_x_y_37339 = not_p_37323 && eq_x_z_37337;
        char eq_x_z_37340 = p_and_eq_x_y_37338 || p_and_eq_x_y_37339;
        char p_and_eq_x_y_37341 = not_p_37325 && eq_x_z_37340;
        char cond_37342 = cond_37310 || p_and_eq_x_y_37341;
        char cond_37343 = arg_37301 == 2;
        float res_37344;
        
        if (cond_37343) {
            res_37344 = -1.0F;
        } else {
            res_37344 = 1.0F;
        }
        
        char p_and_eq_x_y_37345 = cond_37312 && eq_x_y_30924;
        char eq_x_z_37346 = p_and_eq_x_y_37345 || not_p_37335;
        char p_and_eq_x_y_37347 = not_p_37323 && eq_x_z_37346;
        char eq_x_z_37348 = cond_37311 || p_and_eq_x_y_37347;
        char p_and_eq_x_y_37349 = cond_37310 && eq_x_y_30924;
        char p_and_eq_x_y_37350 = not_p_37325 && eq_x_z_37348;
        char cond_37351 = p_and_eq_x_y_37349 || p_and_eq_x_y_37350;
        int32_t res_37352;
        int32_t res_37353;
        float res_37354;
        
        if (cond_37351) {
            res_37352 = res_37319;
            res_37353 = arg_30895;
            res_37354 = res_37344;
        } else {
            res_37352 = 0;
            res_37353 = 0;
            res_37354 = 0.0F;
        }
        
        int32_t res_37355;
        int32_t res_37356;
        float res_37357;
        
        if (cond_37342) {
            res_37355 = res_37319;
            res_37356 = 1;
            res_37357 = res_37344;
        } else {
            res_37355 = res_37352;
            res_37356 = res_37353;
            res_37357 = res_37354;
        }
        
        int32_t res_37358;
        int32_t res_37359;
        float res_37360;
        
        if (cond_37334) {
            res_37358 = arg_30895;
            res_37359 = res_37320;
            res_37360 = res_37328;
        } else {
            res_37358 = res_37355;
            res_37359 = res_37356;
            res_37360 = res_37357;
        }
        
        int32_t res_37361;
        int32_t res_37362;
        float res_37363;
        
        if (p_and_eq_x_y_37326) {
            res_37361 = 1;
            res_37362 = res_37320;
            res_37363 = res_37328;
        } else {
            res_37361 = res_37358;
            res_37362 = res_37359;
            res_37363 = res_37360;
        }
        
        int32_t x_37364 = res_37361 * g_30887;
        int32_t x_37365 = x_37364 + res_37362;
        int32_t i_37366 = res_37361 + arg_37301;
        int32_t i_37367 = res_37361 + arg_37302;
        char p_and_eq_x_y_37368 = not_p_37323 && eq_x_y_30922;
        char eq_x_z_37369 = cond_37311 || p_and_eq_x_y_37368;
        char p_and_eq_x_y_37370 = not_p_37325 && eq_x_z_37369;
        char cond_37371 = cond_37310 || p_and_eq_x_y_37370;
        char p_and_eq_x_y_37372 = cond_37311 && eq_x_y_30924;
        char eq_x_z_37373 = p_and_eq_x_y_37372 || not_p_37323;
        char p_and_eq_x_y_37374 = not_p_37325 && eq_x_z_37373;
        char cond_37375 = p_and_eq_x_y_37349 || p_and_eq_x_y_37374;
        char p_and_eq_x_y_37376 = not_p_37335 && eq_x_z_30916;
        char p_and_eq_x_y_37377 = cond_37311 && eq_x_z_30916;
        char p_and_eq_x_y_37378 = not_p_37323 && p_and_eq_x_y_37376;
        char eq_x_z_37379 = p_and_eq_x_y_37377 || p_and_eq_x_y_37378;
        char p_and_eq_x_y_37380 = not_p_37325 && eq_x_z_37379;
        char p_and_eq_x_y_37381 = cond_37312 && eq_x_y_30918;
        char p_and_eq_x_y_37382 = not_p_37335 && eq_x_z_30920;
        char eq_x_z_37383 = p_and_eq_x_y_37381 || p_and_eq_x_y_37382;
        char p_and_eq_x_y_37384 = cond_37311 && eq_x_z_30920;
        char p_and_eq_x_y_37385 = not_p_37323 && eq_x_z_37383;
        char eq_x_z_37386 = p_and_eq_x_y_37384 || p_and_eq_x_y_37385;
        char p_and_eq_x_y_37387 = not_p_37325 && eq_x_z_37386;
        char cond_37388 = p_and_eq_x_y_37332 || p_and_eq_x_y_37387;
        int32_t res_37389;
        int32_t res_37390;
        float res_37391;
        
        if (cond_37388) {
            res_37389 = res_37321;
            res_37390 = arg_30895;
            res_37391 = res_37344;
        } else {
            res_37389 = 0;
            res_37390 = 0;
            res_37391 = 0.0F;
        }
        
        int32_t res_37392;
        int32_t res_37393;
        float res_37394;
        
        if (p_and_eq_x_y_37380) {
            res_37392 = res_37321;
            res_37393 = 1;
            res_37394 = res_37344;
        } else {
            res_37392 = res_37389;
            res_37393 = res_37390;
            res_37394 = res_37391;
        }
        
        int32_t res_37395;
        int32_t res_37396;
        float res_37397;
        
        if (cond_37375) {
            res_37395 = arg_30895;
            res_37396 = res_37322;
            res_37397 = res_37328;
        } else {
            res_37395 = res_37392;
            res_37396 = res_37393;
            res_37397 = res_37394;
        }
        
        int32_t res_37398;
        int32_t res_37399;
        float res_37400;
        
        if (cond_37371) {
            res_37398 = 1;
            res_37399 = res_37322;
            res_37400 = res_37328;
        } else {
            res_37398 = res_37395;
            res_37399 = res_37396;
            res_37400 = res_37397;
        }
        
        int32_t x_37401 = res_37398 * g_30887;
        int32_t x_37402 = x_37401 + res_37399;
        int32_t i_37403 = res_37398 + arg_37301;
        int32_t i_37404 = res_37398 + arg_37302;
        int32_t res_37405;
        int32_t res_37406;
        float res_37407;
        
        if (y_37307) {
            res_37405 = arg_37299;
            res_37406 = arg_30895;
            res_37407 = res_37344;
        } else {
            res_37405 = 0;
            res_37406 = 0;
            res_37407 = 0.0F;
        }
        
        int32_t res_37408;
        int32_t res_37409;
        float res_37410;
        
        if (x_37306) {
            res_37408 = arg_37299;
            res_37409 = 1;
            res_37410 = res_37344;
        } else {
            res_37408 = res_37405;
            res_37409 = res_37406;
            res_37410 = res_37407;
        }
        
        int32_t res_37411;
        int32_t res_37412;
        float res_37413;
        
        if (y_37304) {
            res_37411 = arg_30895;
            res_37412 = arg_37300;
            res_37413 = res_37328;
        } else {
            res_37411 = res_37408;
            res_37412 = res_37409;
            res_37413 = res_37410;
        }
        
        int32_t res_37414;
        int32_t res_37415;
        float res_37416;
        
        if (x_37303) {
            res_37414 = 1;
            res_37415 = arg_37300;
            res_37416 = res_37328;
        } else {
            res_37414 = res_37411;
            res_37415 = res_37412;
            res_37416 = res_37413;
        }
        
        int32_t x_37417 = res_37414 * g_30887;
        int32_t x_37418 = x_37417 + res_37415;
        int32_t i_37419 = res_37414 + arg_37301;
        int32_t i_37420 = res_37414 + arg_37302;
        float res_37444;
        
        if (res_37309) {
            float x_37421 = *(__global float *) &mem_38154[x_37365 * 4];
            float x_37422 = *(__global float *) &S1_mem_38162[(i_37366 *
                                                               g_30887 +
                                                               res_37362) * 4];
            float y_37423 = *(__global float *) &S1_mem_38162[(i_37367 *
                                                               g_30887 +
                                                               res_37362) * 4];
            float y_37424 = x_37422 - y_37423;
            float y_37425 = x_31869 * y_37424;
            float res_37426 = x_37421 - y_37425;
            float res_37427 = res_37363 * res_37426;
            float x_37428 = *(__global float *) &mem_38154[x_37402 * 4];
            float x_37429 = *(__global float *) &S1_mem_38162[(i_37403 *
                                                               g_30887 +
                                                               res_37399) * 4];
            float y_37430 = *(__global float *) &S1_mem_38162[(i_37404 *
                                                               g_30887 +
                                                               res_37399) * 4];
            float y_37431 = x_37429 - y_37430;
            float y_37432 = x_31869 * y_37431;
            float res_37433 = x_37428 - y_37432;
            float res_37434 = res_37400 * res_37433;
            float y_37435 = res_37427 + res_37434;
            float res_37436 = 0.5F * y_37435;
            
            res_37444 = res_37436;
        } else {
            float x_37437 = *(__global float *) &mem_38154[x_37418 * 4];
            float x_37438 = *(__global float *) &S1_mem_38162[(i_37419 *
                                                               g_30887 +
                                                               res_37415) * 4];
            float y_37439 = *(__global float *) &S1_mem_38162[(i_37420 *
                                                               g_30887 +
                                                               res_37415) * 4];
            float y_37440 = x_37438 - y_37439;
            float y_37441 = x_31869 * y_37440;
            float res_37442 = x_37437 - y_37441;
            float res_37443 = res_37416 * res_37442;
            
            res_37444 = res_37443;
        }
        res_37445 = res_37444;
    }
    // write kernel result
    {
        *(__global float *) &mem_38164[i_37278 * 4] = res_37445;
    }
}
__kernel void map_kernel_37448(char eq_x_z_30920, __global
                               unsigned char *mem_38152, char eq_x_z_30916,
                               char eq_x_y_30924, float x_31869,
                               int32_t res_30909, int32_t y_30914,
                               char eq_x_y_30922, __global
                               unsigned char *S1_mem_38162, char eq_x_y_30918,
                               int32_t arg_30895, int32_t x_30903,
                               int32_t g_30887, __global
                               unsigned char *mem_38166)
{
    const uint kernel_thread_index_37448 = get_global_id(0);
    
    if (kernel_thread_index_37448 >= x_30903)
        return;
    
    int32_t i_37449;
    
    // compute thread index
    {
        i_37449 = kernel_thread_index_37448;
    }
    // read kernel parameters
    { }
    
    int32_t res_37451 = sdiv32(i_37449, g_30887);
    int32_t res_37452 = smod32(i_37449, g_30887);
    char x_37453 = sle32(1, res_37451);
    char y_37454 = sle32(res_37451, arg_30895);
    char x_37455 = x_37453 && y_37454;
    char y_37456 = sle32(1, res_37452);
    char x_37457 = x_37455 && y_37456;
    char y_37458 = sle32(res_37452, arg_30895);
    char res_37459 = x_37457 && y_37458;
    int32_t x_37460 = res_37451 * g_30887;
    int32_t x_37461 = x_37460 + res_37452;
    int32_t i_37462 = res_37452 + 1;
    int32_t i_37463 = res_37452 + -1;
    float res_37617;
    
    if (res_37459) {
        float x_37464 = *(__global float *) &mem_38152[x_37461 * 4];
        float x_37465 = *(__global float *) &S1_mem_38162[(res_37451 * g_30887 +
                                                           i_37462) * 4];
        float y_37466 = *(__global float *) &S1_mem_38162[(res_37451 * g_30887 +
                                                           i_37463) * 4];
        float y_37467 = x_37465 - y_37466;
        float y_37468 = x_31869 * y_37467;
        float res_37469 = x_37464 - y_37468;
        
        res_37617 = res_37469;
    } else {
        int32_t arg_37470 = sdiv32(res_37451, res_30909);
        int32_t arg_37471 = sdiv32(res_37452, res_30909);
        int32_t arg_37472 = sdiv32(1, res_30909);
        int32_t arg_37473 = sdiv32(-1, res_30909);
        int32_t arg_37474 = sdiv32(2, res_30909);
        char x_37475 = arg_37470 == 0;
        char y_37476 = arg_37470 == y_30914;
        char x_37477 = x_37475 || y_37476;
        char x_37478 = arg_37471 == 0;
        char y_37479 = arg_37471 == y_30914;
        char y_37480 = x_37478 || y_37479;
        char res_37481 = x_37477 && y_37480;
        char cond_37482 = x_37475 && x_37478;
        char cond_37483 = x_37475 && y_37479;
        char cond_37484 = y_37476 && x_37478;
        int32_t res_37485;
        int32_t res_37486;
        
        if (cond_37484) {
            res_37485 = 1;
            res_37486 = 0;
        } else {
            res_37485 = arg_30895;
            res_37486 = y_30914;
        }
        
        int32_t res_37487;
        int32_t res_37488;
        int32_t res_37489;
        int32_t res_37490;
        
        if (cond_37483) {
            res_37487 = 1;
            res_37488 = y_30914;
            res_37489 = 0;
            res_37490 = arg_30895;
        } else {
            res_37487 = arg_30895;
            res_37488 = res_37486;
            res_37489 = y_30914;
            res_37490 = res_37485;
        }
        
        int32_t res_37491;
        int32_t res_37492;
        int32_t res_37493;
        int32_t res_37494;
        
        if (cond_37482) {
            res_37491 = 1;
            res_37492 = 0;
            res_37493 = 0;
            res_37494 = 1;
        } else {
            res_37491 = res_37487;
            res_37492 = res_37488;
            res_37493 = res_37489;
            res_37494 = res_37490;
        }
        
        char not_p_37495 = !cond_37483;
        char p_and_eq_x_y_37496 = not_p_37495 && eq_x_z_30916;
        char not_p_37497 = !cond_37482;
        char p_and_eq_x_y_37498 = not_p_37497 && p_and_eq_x_y_37496;
        char cond_37499 = arg_37474 == 1;
        float res_37500;
        
        if (cond_37499) {
            res_37500 = -1.0F;
        } else {
            res_37500 = 1.0F;
        }
        
        char p_and_eq_x_y_37501 = cond_37483 && eq_x_y_30918;
        char p_and_eq_x_y_37502 = not_p_37495 && eq_x_z_30920;
        char eq_x_z_37503 = p_and_eq_x_y_37501 || p_and_eq_x_y_37502;
        char p_and_eq_x_y_37504 = cond_37482 && eq_x_y_30918;
        char p_and_eq_x_y_37505 = not_p_37497 && eq_x_z_37503;
        char cond_37506 = p_and_eq_x_y_37504 || p_and_eq_x_y_37505;
        char not_p_37507 = !cond_37484;
        char p_and_eq_x_y_37508 = not_p_37507 && eq_x_y_30922;
        char eq_x_z_37509 = cond_37484 || p_and_eq_x_y_37508;
        char p_and_eq_x_y_37510 = cond_37483 && eq_x_y_30922;
        char p_and_eq_x_y_37511 = not_p_37495 && eq_x_z_37509;
        char eq_x_z_37512 = p_and_eq_x_y_37510 || p_and_eq_x_y_37511;
        char p_and_eq_x_y_37513 = not_p_37497 && eq_x_z_37512;
        char cond_37514 = cond_37482 || p_and_eq_x_y_37513;
        char cond_37515 = arg_37474 == 2;
        float res_37516;
        
        if (cond_37515) {
            res_37516 = -1.0F;
        } else {
            res_37516 = 1.0F;
        }
        
        char p_and_eq_x_y_37517 = cond_37484 && eq_x_y_30924;
        char eq_x_z_37518 = p_and_eq_x_y_37517 || not_p_37507;
        char p_and_eq_x_y_37519 = not_p_37495 && eq_x_z_37518;
        char eq_x_z_37520 = cond_37483 || p_and_eq_x_y_37519;
        char p_and_eq_x_y_37521 = cond_37482 && eq_x_y_30924;
        char p_and_eq_x_y_37522 = not_p_37497 && eq_x_z_37520;
        char cond_37523 = p_and_eq_x_y_37521 || p_and_eq_x_y_37522;
        int32_t res_37524;
        int32_t res_37525;
        float res_37526;
        
        if (cond_37523) {
            res_37524 = res_37491;
            res_37525 = arg_30895;
            res_37526 = res_37516;
        } else {
            res_37524 = 0;
            res_37525 = 0;
            res_37526 = 0.0F;
        }
        
        int32_t res_37527;
        int32_t res_37528;
        float res_37529;
        
        if (cond_37514) {
            res_37527 = res_37491;
            res_37528 = 1;
            res_37529 = res_37516;
        } else {
            res_37527 = res_37524;
            res_37528 = res_37525;
            res_37529 = res_37526;
        }
        
        int32_t res_37530;
        int32_t res_37531;
        float res_37532;
        
        if (cond_37506) {
            res_37530 = arg_30895;
            res_37531 = res_37492;
            res_37532 = res_37500;
        } else {
            res_37530 = res_37527;
            res_37531 = res_37528;
            res_37532 = res_37529;
        }
        
        int32_t res_37533;
        int32_t res_37534;
        float res_37535;
        
        if (p_and_eq_x_y_37498) {
            res_37533 = 1;
            res_37534 = res_37492;
            res_37535 = res_37500;
        } else {
            res_37533 = res_37530;
            res_37534 = res_37531;
            res_37535 = res_37532;
        }
        
        int32_t x_37536 = res_37533 * g_30887;
        int32_t x_37537 = x_37536 + res_37534;
        int32_t i_37538 = res_37534 + arg_37472;
        int32_t i_37539 = res_37534 + arg_37473;
        char p_and_eq_x_y_37540 = not_p_37495 && eq_x_y_30922;
        char eq_x_z_37541 = cond_37483 || p_and_eq_x_y_37540;
        char p_and_eq_x_y_37542 = not_p_37497 && eq_x_z_37541;
        char cond_37543 = cond_37482 || p_and_eq_x_y_37542;
        char p_and_eq_x_y_37544 = cond_37483 && eq_x_y_30924;
        char eq_x_z_37545 = p_and_eq_x_y_37544 || not_p_37495;
        char p_and_eq_x_y_37546 = not_p_37497 && eq_x_z_37545;
        char cond_37547 = p_and_eq_x_y_37521 || p_and_eq_x_y_37546;
        char p_and_eq_x_y_37548 = not_p_37507 && eq_x_z_30916;
        char p_and_eq_x_y_37549 = cond_37483 && eq_x_z_30916;
        char p_and_eq_x_y_37550 = not_p_37495 && p_and_eq_x_y_37548;
        char eq_x_z_37551 = p_and_eq_x_y_37549 || p_and_eq_x_y_37550;
        char p_and_eq_x_y_37552 = not_p_37497 && eq_x_z_37551;
        char p_and_eq_x_y_37553 = cond_37484 && eq_x_y_30918;
        char p_and_eq_x_y_37554 = not_p_37507 && eq_x_z_30920;
        char eq_x_z_37555 = p_and_eq_x_y_37553 || p_and_eq_x_y_37554;
        char p_and_eq_x_y_37556 = cond_37483 && eq_x_z_30920;
        char p_and_eq_x_y_37557 = not_p_37495 && eq_x_z_37555;
        char eq_x_z_37558 = p_and_eq_x_y_37556 || p_and_eq_x_y_37557;
        char p_and_eq_x_y_37559 = not_p_37497 && eq_x_z_37558;
        char cond_37560 = p_and_eq_x_y_37504 || p_and_eq_x_y_37559;
        int32_t res_37561;
        int32_t res_37562;
        float res_37563;
        
        if (cond_37560) {
            res_37561 = res_37493;
            res_37562 = arg_30895;
            res_37563 = res_37516;
        } else {
            res_37561 = 0;
            res_37562 = 0;
            res_37563 = 0.0F;
        }
        
        int32_t res_37564;
        int32_t res_37565;
        float res_37566;
        
        if (p_and_eq_x_y_37552) {
            res_37564 = res_37493;
            res_37565 = 1;
            res_37566 = res_37516;
        } else {
            res_37564 = res_37561;
            res_37565 = res_37562;
            res_37566 = res_37563;
        }
        
        int32_t res_37567;
        int32_t res_37568;
        float res_37569;
        
        if (cond_37547) {
            res_37567 = arg_30895;
            res_37568 = res_37494;
            res_37569 = res_37500;
        } else {
            res_37567 = res_37564;
            res_37568 = res_37565;
            res_37569 = res_37566;
        }
        
        int32_t res_37570;
        int32_t res_37571;
        float res_37572;
        
        if (cond_37543) {
            res_37570 = 1;
            res_37571 = res_37494;
            res_37572 = res_37500;
        } else {
            res_37570 = res_37567;
            res_37571 = res_37568;
            res_37572 = res_37569;
        }
        
        int32_t x_37573 = res_37570 * g_30887;
        int32_t x_37574 = x_37573 + res_37571;
        int32_t i_37575 = res_37571 + arg_37472;
        int32_t i_37576 = res_37571 + arg_37473;
        int32_t res_37577;
        int32_t res_37578;
        float res_37579;
        
        if (y_37479) {
            res_37577 = arg_37470;
            res_37578 = arg_30895;
            res_37579 = res_37516;
        } else {
            res_37577 = 0;
            res_37578 = 0;
            res_37579 = 0.0F;
        }
        
        int32_t res_37580;
        int32_t res_37581;
        float res_37582;
        
        if (x_37478) {
            res_37580 = arg_37470;
            res_37581 = 1;
            res_37582 = res_37516;
        } else {
            res_37580 = res_37577;
            res_37581 = res_37578;
            res_37582 = res_37579;
        }
        
        int32_t res_37583;
        int32_t res_37584;
        float res_37585;
        
        if (y_37476) {
            res_37583 = arg_30895;
            res_37584 = arg_37471;
            res_37585 = res_37500;
        } else {
            res_37583 = res_37580;
            res_37584 = res_37581;
            res_37585 = res_37582;
        }
        
        int32_t res_37586;
        int32_t res_37587;
        float res_37588;
        
        if (x_37475) {
            res_37586 = 1;
            res_37587 = arg_37471;
            res_37588 = res_37500;
        } else {
            res_37586 = res_37583;
            res_37587 = res_37584;
            res_37588 = res_37585;
        }
        
        int32_t x_37589 = res_37586 * g_30887;
        int32_t x_37590 = x_37589 + res_37587;
        int32_t i_37591 = res_37587 + arg_37472;
        int32_t i_37592 = res_37587 + arg_37473;
        float res_37616;
        
        if (res_37481) {
            float x_37593 = *(__global float *) &mem_38152[x_37537 * 4];
            float x_37594 = *(__global float *) &S1_mem_38162[(res_37533 *
                                                               g_30887 +
                                                               i_37538) * 4];
            float y_37595 = *(__global float *) &S1_mem_38162[(res_37533 *
                                                               g_30887 +
                                                               i_37539) * 4];
            float y_37596 = x_37594 - y_37595;
            float y_37597 = x_31869 * y_37596;
            float res_37598 = x_37593 - y_37597;
            float res_37599 = res_37535 * res_37598;
            float x_37600 = *(__global float *) &mem_38152[x_37574 * 4];
            float x_37601 = *(__global float *) &S1_mem_38162[(res_37570 *
                                                               g_30887 +
                                                               i_37575) * 4];
            float y_37602 = *(__global float *) &S1_mem_38162[(res_37570 *
                                                               g_30887 +
                                                               i_37576) * 4];
            float y_37603 = x_37601 - y_37602;
            float y_37604 = x_31869 * y_37603;
            float res_37605 = x_37600 - y_37604;
            float res_37606 = res_37572 * res_37605;
            float y_37607 = res_37599 + res_37606;
            float res_37608 = 0.5F * y_37607;
            
            res_37616 = res_37608;
        } else {
            float x_37609 = *(__global float *) &mem_38152[x_37590 * 4];
            float x_37610 = *(__global float *) &S1_mem_38162[(res_37586 *
                                                               g_30887 +
                                                               i_37591) * 4];
            float y_37611 = *(__global float *) &S1_mem_38162[(res_37586 *
                                                               g_30887 +
                                                               i_37592) * 4];
            float y_37612 = x_37610 - y_37611;
            float y_37613 = x_31869 * y_37612;
            float res_37614 = x_37609 - y_37613;
            float res_37615 = res_37588 * res_37614;
            
            res_37616 = res_37615;
        }
        res_37617 = res_37616;
    }
    // write kernel result
    {
        *(__global float *) &mem_38166[i_37449 * 4] = res_37617;
    }
}
__kernel void map_kernel_37620(char eq_x_z_30920, __global
                               unsigned char *S1_mem_38168, char eq_x_z_30916,
                               char eq_x_y_30924, float res_34621,
                               int32_t res_30909, __global
                               unsigned char *D0_mem_38121, int32_t y_30914,
                               char eq_x_y_30922, char eq_x_y_30918,
                               int32_t arg_30895, int32_t x_30903,
                               float arg_34623, int32_t g_30887, __global
                               unsigned char *mem_38170)
{
    const uint kernel_thread_index_37620 = get_global_id(0);
    
    if (kernel_thread_index_37620 >= x_30903)
        return;
    
    int32_t i_37621;
    
    // compute thread index
    {
        i_37621 = kernel_thread_index_37620;
    }
    // read kernel parameters
    { }
    
    int32_t res_37623 = sdiv32(i_37621, g_30887);
    int32_t res_37624 = smod32(i_37621, g_30887);
    char x_37625 = sle32(1, res_37623);
    char y_37626 = sle32(res_37623, arg_30895);
    char x_37627 = x_37625 && y_37626;
    char y_37628 = sle32(1, res_37624);
    char x_37629 = x_37627 && y_37628;
    char y_37630 = sle32(res_37624, arg_30895);
    char res_37631 = x_37629 && y_37630;
    int32_t i_37632 = res_37623 - 1;
    int32_t i_37633 = res_37623 + 1;
    int32_t i_37634 = res_37624 - 1;
    int32_t i_37635 = res_37624 + 1;
    float res_37802;
    
    if (res_37631) {
        float x_37636 = *(__global float *) &D0_mem_38121[(res_37623 * g_30887 +
                                                           res_37624) * 4];
        float x_37637 = *(__global float *) &S1_mem_38168[(i_37632 * g_30887 +
                                                           res_37624) * 4];
        float y_37638 = *(__global float *) &S1_mem_38168[(i_37633 * g_30887 +
                                                           res_37624) * 4];
        float x_37639 = x_37637 + y_37638;
        float y_37640 = *(__global float *) &S1_mem_38168[(res_37623 * g_30887 +
                                                           i_37634) * 4];
        float x_37641 = x_37639 + y_37640;
        float y_37642 = *(__global float *) &S1_mem_38168[(res_37623 * g_30887 +
                                                           i_37635) * 4];
        float y_37643 = x_37641 + y_37642;
        float y_37644 = res_34621 * y_37643;
        float x_37645 = x_37636 + y_37644;
        float res_37646 = x_37645 / arg_34623;
        
        res_37802 = res_37646;
    } else {
        int32_t arg_37647 = sdiv32(res_37623, res_30909);
        int32_t arg_37648 = sdiv32(res_37624, res_30909);
        char x_37649 = arg_37647 == 0;
        char y_37650 = arg_37647 == y_30914;
        char x_37651 = x_37649 || y_37650;
        char x_37652 = arg_37648 == 0;
        char y_37653 = arg_37648 == y_30914;
        char y_37654 = x_37652 || y_37653;
        char res_37655 = x_37651 && y_37654;
        char cond_37656 = x_37649 && x_37652;
        char cond_37657 = x_37649 && y_37653;
        char cond_37658 = y_37650 && x_37652;
        int32_t res_37659;
        int32_t res_37660;
        
        if (cond_37658) {
            res_37659 = 1;
            res_37660 = 0;
        } else {
            res_37659 = arg_30895;
            res_37660 = y_30914;
        }
        
        int32_t res_37661;
        int32_t res_37662;
        int32_t res_37663;
        int32_t res_37664;
        
        if (cond_37657) {
            res_37661 = 1;
            res_37662 = y_30914;
            res_37663 = 0;
            res_37664 = arg_30895;
        } else {
            res_37661 = arg_30895;
            res_37662 = res_37660;
            res_37663 = y_30914;
            res_37664 = res_37659;
        }
        
        int32_t res_37665;
        int32_t res_37666;
        int32_t res_37667;
        int32_t res_37668;
        
        if (cond_37656) {
            res_37665 = 1;
            res_37666 = 0;
            res_37667 = 0;
            res_37668 = 1;
        } else {
            res_37665 = res_37661;
            res_37666 = res_37662;
            res_37667 = res_37663;
            res_37668 = res_37664;
        }
        
        char not_p_37669 = !cond_37657;
        char p_and_eq_x_y_37670 = not_p_37669 && eq_x_z_30916;
        char not_p_37671 = !cond_37656;
        char p_and_eq_x_y_37672 = not_p_37671 && p_and_eq_x_y_37670;
        char p_and_eq_x_y_37673 = cond_37657 && eq_x_y_30918;
        char p_and_eq_x_y_37674 = not_p_37669 && eq_x_z_30920;
        char eq_x_z_37675 = p_and_eq_x_y_37673 || p_and_eq_x_y_37674;
        char p_and_eq_x_y_37676 = cond_37656 && eq_x_y_30918;
        char p_and_eq_x_y_37677 = not_p_37671 && eq_x_z_37675;
        char cond_37678 = p_and_eq_x_y_37676 || p_and_eq_x_y_37677;
        char not_p_37679 = !cond_37658;
        char p_and_eq_x_y_37680 = not_p_37679 && eq_x_y_30922;
        char eq_x_z_37681 = cond_37658 || p_and_eq_x_y_37680;
        char p_and_eq_x_y_37682 = cond_37657 && eq_x_y_30922;
        char p_and_eq_x_y_37683 = not_p_37669 && eq_x_z_37681;
        char eq_x_z_37684 = p_and_eq_x_y_37682 || p_and_eq_x_y_37683;
        char p_and_eq_x_y_37685 = not_p_37671 && eq_x_z_37684;
        char cond_37686 = cond_37656 || p_and_eq_x_y_37685;
        char p_and_eq_x_y_37687 = cond_37658 && eq_x_y_30924;
        char eq_x_z_37688 = p_and_eq_x_y_37687 || not_p_37679;
        char p_and_eq_x_y_37689 = not_p_37669 && eq_x_z_37688;
        char eq_x_z_37690 = cond_37657 || p_and_eq_x_y_37689;
        char p_and_eq_x_y_37691 = cond_37656 && eq_x_y_30924;
        char p_and_eq_x_y_37692 = not_p_37671 && eq_x_z_37690;
        char cond_37693 = p_and_eq_x_y_37691 || p_and_eq_x_y_37692;
        int32_t res_37694;
        int32_t res_37695;
        float res_37696;
        
        if (cond_37693) {
            res_37694 = res_37665;
            res_37695 = arg_30895;
            res_37696 = 1.0F;
        } else {
            res_37694 = 0;
            res_37695 = 0;
            res_37696 = 0.0F;
        }
        
        int32_t res_37697;
        int32_t res_37698;
        float res_37699;
        
        if (cond_37686) {
            res_37697 = res_37665;
            res_37698 = 1;
            res_37699 = 1.0F;
        } else {
            res_37697 = res_37694;
            res_37698 = res_37695;
            res_37699 = res_37696;
        }
        
        int32_t res_37700;
        int32_t res_37701;
        float res_37702;
        
        if (cond_37678) {
            res_37700 = arg_30895;
            res_37701 = res_37666;
            res_37702 = 1.0F;
        } else {
            res_37700 = res_37697;
            res_37701 = res_37698;
            res_37702 = res_37699;
        }
        
        int32_t res_37703;
        int32_t res_37704;
        float res_37705;
        
        if (p_and_eq_x_y_37672) {
            res_37703 = 1;
            res_37704 = res_37666;
            res_37705 = 1.0F;
        } else {
            res_37703 = res_37700;
            res_37704 = res_37701;
            res_37705 = res_37702;
        }
        
        int32_t i_37706 = res_37703 - 1;
        int32_t i_37707 = res_37703 + 1;
        int32_t i_37708 = res_37704 - 1;
        int32_t i_37709 = res_37704 + 1;
        char p_and_eq_x_y_37710 = not_p_37669 && eq_x_y_30922;
        char eq_x_z_37711 = cond_37657 || p_and_eq_x_y_37710;
        char p_and_eq_x_y_37712 = not_p_37671 && eq_x_z_37711;
        char cond_37713 = cond_37656 || p_and_eq_x_y_37712;
        char p_and_eq_x_y_37714 = cond_37657 && eq_x_y_30924;
        char eq_x_z_37715 = p_and_eq_x_y_37714 || not_p_37669;
        char p_and_eq_x_y_37716 = not_p_37671 && eq_x_z_37715;
        char cond_37717 = p_and_eq_x_y_37691 || p_and_eq_x_y_37716;
        char p_and_eq_x_y_37718 = not_p_37679 && eq_x_z_30916;
        char p_and_eq_x_y_37719 = cond_37657 && eq_x_z_30916;
        char p_and_eq_x_y_37720 = not_p_37669 && p_and_eq_x_y_37718;
        char eq_x_z_37721 = p_and_eq_x_y_37719 || p_and_eq_x_y_37720;
        char p_and_eq_x_y_37722 = not_p_37671 && eq_x_z_37721;
        char p_and_eq_x_y_37723 = cond_37658 && eq_x_y_30918;
        char p_and_eq_x_y_37724 = not_p_37679 && eq_x_z_30920;
        char eq_x_z_37725 = p_and_eq_x_y_37723 || p_and_eq_x_y_37724;
        char p_and_eq_x_y_37726 = cond_37657 && eq_x_z_30920;
        char p_and_eq_x_y_37727 = not_p_37669 && eq_x_z_37725;
        char eq_x_z_37728 = p_and_eq_x_y_37726 || p_and_eq_x_y_37727;
        char p_and_eq_x_y_37729 = not_p_37671 && eq_x_z_37728;
        char cond_37730 = p_and_eq_x_y_37676 || p_and_eq_x_y_37729;
        int32_t res_37731;
        int32_t res_37732;
        float res_37733;
        
        if (cond_37730) {
            res_37731 = res_37667;
            res_37732 = arg_30895;
            res_37733 = 1.0F;
        } else {
            res_37731 = 0;
            res_37732 = 0;
            res_37733 = 0.0F;
        }
        
        int32_t res_37734;
        int32_t res_37735;
        float res_37736;
        
        if (p_and_eq_x_y_37722) {
            res_37734 = res_37667;
            res_37735 = 1;
            res_37736 = 1.0F;
        } else {
            res_37734 = res_37731;
            res_37735 = res_37732;
            res_37736 = res_37733;
        }
        
        int32_t res_37737;
        int32_t res_37738;
        float res_37739;
        
        if (cond_37717) {
            res_37737 = arg_30895;
            res_37738 = res_37668;
            res_37739 = 1.0F;
        } else {
            res_37737 = res_37734;
            res_37738 = res_37735;
            res_37739 = res_37736;
        }
        
        int32_t res_37740;
        int32_t res_37741;
        float res_37742;
        
        if (cond_37713) {
            res_37740 = 1;
            res_37741 = res_37668;
            res_37742 = 1.0F;
        } else {
            res_37740 = res_37737;
            res_37741 = res_37738;
            res_37742 = res_37739;
        }
        
        int32_t i_37743 = res_37740 - 1;
        int32_t i_37744 = res_37740 + 1;
        int32_t i_37745 = res_37741 - 1;
        int32_t i_37746 = res_37741 + 1;
        int32_t res_37747;
        int32_t res_37748;
        float res_37749;
        
        if (y_37653) {
            res_37747 = arg_37647;
            res_37748 = arg_30895;
            res_37749 = 1.0F;
        } else {
            res_37747 = 0;
            res_37748 = 0;
            res_37749 = 0.0F;
        }
        
        int32_t res_37750;
        int32_t res_37751;
        float res_37752;
        
        if (x_37652) {
            res_37750 = arg_37647;
            res_37751 = 1;
            res_37752 = 1.0F;
        } else {
            res_37750 = res_37747;
            res_37751 = res_37748;
            res_37752 = res_37749;
        }
        
        int32_t res_37753;
        int32_t res_37754;
        float res_37755;
        
        if (y_37650) {
            res_37753 = arg_30895;
            res_37754 = arg_37648;
            res_37755 = 1.0F;
        } else {
            res_37753 = res_37750;
            res_37754 = res_37751;
            res_37755 = res_37752;
        }
        
        int32_t res_37756;
        int32_t res_37757;
        float res_37758;
        
        if (x_37649) {
            res_37756 = 1;
            res_37757 = arg_37648;
            res_37758 = 1.0F;
        } else {
            res_37756 = res_37753;
            res_37757 = res_37754;
            res_37758 = res_37755;
        }
        
        int32_t i_37759 = res_37756 - 1;
        int32_t i_37760 = res_37756 + 1;
        int32_t i_37761 = res_37757 - 1;
        int32_t i_37762 = res_37757 + 1;
        float res_37801;
        
        if (res_37655) {
            float x_37763 = *(__global float *) &D0_mem_38121[(res_37703 *
                                                               g_30887 +
                                                               res_37704) * 4];
            float x_37764 = *(__global float *) &S1_mem_38168[(i_37706 *
                                                               g_30887 +
                                                               res_37704) * 4];
            float y_37765 = *(__global float *) &S1_mem_38168[(i_37707 *
                                                               g_30887 +
                                                               res_37704) * 4];
            float x_37766 = x_37764 + y_37765;
            float y_37767 = *(__global float *) &S1_mem_38168[(res_37703 *
                                                               g_30887 +
                                                               i_37708) * 4];
            float x_37768 = x_37766 + y_37767;
            float y_37769 = *(__global float *) &S1_mem_38168[(res_37703 *
                                                               g_30887 +
                                                               i_37709) * 4];
            float y_37770 = x_37768 + y_37769;
            float y_37771 = res_34621 * y_37770;
            float x_37772 = x_37763 + y_37771;
            float res_37773 = x_37772 / arg_34623;
            float res_37774 = res_37705 * res_37773;
            float x_37775 = *(__global float *) &D0_mem_38121[(res_37740 *
                                                               g_30887 +
                                                               res_37741) * 4];
            float x_37776 = *(__global float *) &S1_mem_38168[(i_37743 *
                                                               g_30887 +
                                                               res_37741) * 4];
            float y_37777 = *(__global float *) &S1_mem_38168[(i_37744 *
                                                               g_30887 +
                                                               res_37741) * 4];
            float x_37778 = x_37776 + y_37777;
            float y_37779 = *(__global float *) &S1_mem_38168[(res_37740 *
                                                               g_30887 +
                                                               i_37745) * 4];
            float x_37780 = x_37778 + y_37779;
            float y_37781 = *(__global float *) &S1_mem_38168[(res_37740 *
                                                               g_30887 +
                                                               i_37746) * 4];
            float y_37782 = x_37780 + y_37781;
            float y_37783 = res_34621 * y_37782;
            float x_37784 = x_37775 + y_37783;
            float res_37785 = x_37784 / arg_34623;
            float res_37786 = res_37742 * res_37785;
            float y_37787 = res_37774 + res_37786;
            float res_37788 = 0.5F * y_37787;
            
            res_37801 = res_37788;
        } else {
            float x_37789 = *(__global float *) &D0_mem_38121[(res_37756 *
                                                               g_30887 +
                                                               res_37757) * 4];
            float x_37790 = *(__global float *) &S1_mem_38168[(i_37759 *
                                                               g_30887 +
                                                               res_37757) * 4];
            float y_37791 = *(__global float *) &S1_mem_38168[(i_37760 *
                                                               g_30887 +
                                                               res_37757) * 4];
            float x_37792 = x_37790 + y_37791;
            float y_37793 = *(__global float *) &S1_mem_38168[(res_37756 *
                                                               g_30887 +
                                                               i_37761) * 4];
            float x_37794 = x_37792 + y_37793;
            float y_37795 = *(__global float *) &S1_mem_38168[(res_37756 *
                                                               g_30887 +
                                                               i_37762) * 4];
            float y_37796 = x_37794 + y_37795;
            float y_37797 = res_34621 * y_37796;
            float x_37798 = x_37789 + y_37797;
            float res_37799 = x_37798 / arg_34623;
            float res_37800 = res_37758 * res_37799;
            
            res_37801 = res_37800;
        }
        res_37802 = res_37801;
    }
    // write kernel result
    {
        *(__global float *) &mem_38170[i_37621 * 4] = res_37802;
    }
}
__kernel void map_kernel_37805(float res_32512, char eq_x_z_30920,
                               char eq_x_z_30916, float y_32516,
                               char eq_x_y_30924, __global
                               unsigned char *S1_mem_38172, int32_t res_30909,
                               __global unsigned char *U0_mem_38117,
                               int32_t y_30914, char eq_x_y_30922,
                               char eq_x_y_30918, int32_t arg_30895,
                               int32_t x_30903, __global
                               unsigned char *V0_mem_38119, int32_t g_30887,
                               __global unsigned char *mem_38174)
{
    const uint kernel_thread_index_37805 = get_global_id(0);
    
    if (kernel_thread_index_37805 >= x_30903)
        return;
    
    int32_t i_37806;
    
    // compute thread index
    {
        i_37806 = kernel_thread_index_37805;
    }
    // read kernel parameters
    { }
    
    int32_t res_37808 = sdiv32(i_37806, g_30887);
    int32_t res_37809 = smod32(i_37806, g_30887);
    char x_37810 = sle32(1, res_37808);
    char y_37811 = sle32(res_37808, arg_30895);
    char x_37812 = x_37810 && y_37811;
    char y_37813 = sle32(1, res_37809);
    char x_37814 = x_37812 && y_37813;
    char y_37815 = sle32(res_37809, arg_30895);
    char res_37816 = x_37814 && y_37815;
    float x_37817 = sitofp_i32_f32(res_37808);
    float x_37818 = sitofp_i32_f32(res_37809);
    float res_38083;
    
    if (res_37816) {
        float y_37819 = *(__global float *) &U0_mem_38117[(res_37808 * g_30887 +
                                                           res_37809) * 4];
        float y_37820 = res_32512 * y_37819;
        float res_37821 = x_37817 - y_37820;
        float y_37822 = *(__global float *) &V0_mem_38119[(res_37808 * g_30887 +
                                                           res_37809) * 4];
        float y_37823 = res_32512 * y_37822;
        float res_37824 = x_37818 - y_37823;
        char cond_37825 = res_37821 < 0.5F;
        float res_37826;
        
        if (cond_37825) {
            res_37826 = 0.5F;
        } else {
            res_37826 = res_37821;
        }
        
        char cond_37827 = y_32516 < res_37826;
        float res_37828;
        
        if (cond_37827) {
            res_37828 = y_32516;
        } else {
            res_37828 = res_37826;
        }
        
        int32_t res_37829 = fptosi_f32_i32(res_37828);
        int32_t res_37830 = res_37829 + 1;
        char cond_37831 = res_37824 < 0.5F;
        float res_37832;
        
        if (cond_37831) {
            res_37832 = 0.5F;
        } else {
            res_37832 = res_37824;
        }
        
        char cond_37833 = y_32516 < res_37832;
        float res_37834;
        
        if (cond_37833) {
            res_37834 = y_32516;
        } else {
            res_37834 = res_37832;
        }
        
        int32_t res_37835 = fptosi_f32_i32(res_37834);
        int32_t res_37836 = res_37835 + 1;
        float y_37837 = sitofp_i32_f32(res_37829);
        float res_37838 = res_37828 - y_37837;
        float res_37839 = 1.0F - res_37838;
        float y_37840 = sitofp_i32_f32(res_37835);
        float res_37841 = res_37834 - y_37840;
        float res_37842 = 1.0F - res_37841;
        float y_37843 = *(__global float *) &S1_mem_38172[(res_37829 * g_30887 +
                                                           res_37835) * 4];
        float x_37844 = res_37842 * y_37843;
        float y_37845 = *(__global float *) &S1_mem_38172[(res_37829 * g_30887 +
                                                           res_37836) * 4];
        float y_37846 = res_37841 * y_37845;
        float y_37847 = x_37844 + y_37846;
        float x_37848 = res_37839 * y_37847;
        float y_37849 = *(__global float *) &S1_mem_38172[(res_37830 * g_30887 +
                                                           res_37835) * 4];
        float x_37850 = res_37842 * y_37849;
        float y_37851 = *(__global float *) &S1_mem_38172[(res_37830 * g_30887 +
                                                           res_37836) * 4];
        float y_37852 = res_37841 * y_37851;
        float y_37853 = x_37850 + y_37852;
        float y_37854 = res_37838 * y_37853;
        float res_37855 = x_37848 + y_37854;
        
        res_38083 = res_37855;
    } else {
        int32_t arg_37856 = sdiv32(res_37808, res_30909);
        int32_t arg_37857 = sdiv32(res_37809, res_30909);
        char x_37858 = arg_37856 == 0;
        char y_37859 = arg_37856 == y_30914;
        char x_37860 = x_37858 || y_37859;
        char x_37861 = arg_37857 == 0;
        char y_37862 = arg_37857 == y_30914;
        char y_37863 = x_37861 || y_37862;
        char res_37864 = x_37860 && y_37863;
        char cond_37865 = x_37858 && x_37861;
        char cond_37866 = x_37858 && y_37862;
        char cond_37867 = y_37859 && x_37861;
        int32_t res_37868;
        int32_t res_37869;
        
        if (cond_37867) {
            res_37868 = 1;
            res_37869 = 0;
        } else {
            res_37868 = arg_30895;
            res_37869 = y_30914;
        }
        
        int32_t res_37870;
        int32_t res_37871;
        int32_t res_37872;
        int32_t res_37873;
        
        if (cond_37866) {
            res_37870 = 1;
            res_37871 = y_30914;
            res_37872 = 0;
            res_37873 = arg_30895;
        } else {
            res_37870 = arg_30895;
            res_37871 = res_37869;
            res_37872 = y_30914;
            res_37873 = res_37868;
        }
        
        int32_t res_37874;
        int32_t res_37875;
        int32_t res_37876;
        int32_t res_37877;
        
        if (cond_37865) {
            res_37874 = 1;
            res_37875 = 0;
            res_37876 = 0;
            res_37877 = 1;
        } else {
            res_37874 = res_37870;
            res_37875 = res_37871;
            res_37876 = res_37872;
            res_37877 = res_37873;
        }
        
        char not_p_37878 = !cond_37866;
        char p_and_eq_x_y_37879 = not_p_37878 && eq_x_z_30916;
        char not_p_37880 = !cond_37865;
        char p_and_eq_x_y_37881 = not_p_37880 && p_and_eq_x_y_37879;
        char p_and_eq_x_y_37882 = cond_37866 && eq_x_y_30918;
        char p_and_eq_x_y_37883 = not_p_37878 && eq_x_z_30920;
        char eq_x_z_37884 = p_and_eq_x_y_37882 || p_and_eq_x_y_37883;
        char p_and_eq_x_y_37885 = cond_37865 && eq_x_y_30918;
        char p_and_eq_x_y_37886 = not_p_37880 && eq_x_z_37884;
        char cond_37887 = p_and_eq_x_y_37885 || p_and_eq_x_y_37886;
        char not_p_37888 = !cond_37867;
        char p_and_eq_x_y_37889 = not_p_37888 && eq_x_y_30922;
        char eq_x_z_37890 = cond_37867 || p_and_eq_x_y_37889;
        char p_and_eq_x_y_37891 = cond_37866 && eq_x_y_30922;
        char p_and_eq_x_y_37892 = not_p_37878 && eq_x_z_37890;
        char eq_x_z_37893 = p_and_eq_x_y_37891 || p_and_eq_x_y_37892;
        char p_and_eq_x_y_37894 = not_p_37880 && eq_x_z_37893;
        char cond_37895 = cond_37865 || p_and_eq_x_y_37894;
        char p_and_eq_x_y_37896 = cond_37867 && eq_x_y_30924;
        char eq_x_z_37897 = p_and_eq_x_y_37896 || not_p_37888;
        char p_and_eq_x_y_37898 = not_p_37878 && eq_x_z_37897;
        char eq_x_z_37899 = cond_37866 || p_and_eq_x_y_37898;
        char p_and_eq_x_y_37900 = cond_37865 && eq_x_y_30924;
        char p_and_eq_x_y_37901 = not_p_37880 && eq_x_z_37899;
        char cond_37902 = p_and_eq_x_y_37900 || p_and_eq_x_y_37901;
        int32_t res_37903;
        int32_t res_37904;
        float res_37905;
        
        if (cond_37902) {
            res_37903 = res_37874;
            res_37904 = arg_30895;
            res_37905 = 1.0F;
        } else {
            res_37903 = 0;
            res_37904 = 0;
            res_37905 = 0.0F;
        }
        
        int32_t res_37906;
        int32_t res_37907;
        float res_37908;
        
        if (cond_37895) {
            res_37906 = res_37874;
            res_37907 = 1;
            res_37908 = 1.0F;
        } else {
            res_37906 = res_37903;
            res_37907 = res_37904;
            res_37908 = res_37905;
        }
        
        int32_t res_37909;
        int32_t res_37910;
        float res_37911;
        
        if (cond_37887) {
            res_37909 = arg_30895;
            res_37910 = res_37875;
            res_37911 = 1.0F;
        } else {
            res_37909 = res_37906;
            res_37910 = res_37907;
            res_37911 = res_37908;
        }
        
        int32_t res_37912;
        int32_t res_37913;
        float res_37914;
        
        if (p_and_eq_x_y_37881) {
            res_37912 = 1;
            res_37913 = res_37875;
            res_37914 = 1.0F;
        } else {
            res_37912 = res_37909;
            res_37913 = res_37910;
            res_37914 = res_37911;
        }
        
        float x_37915 = sitofp_i32_f32(res_37912);
        float x_37916 = sitofp_i32_f32(res_37913);
        char p_and_eq_x_y_37917 = not_p_37878 && eq_x_y_30922;
        char eq_x_z_37918 = cond_37866 || p_and_eq_x_y_37917;
        char p_and_eq_x_y_37919 = not_p_37880 && eq_x_z_37918;
        char cond_37920 = cond_37865 || p_and_eq_x_y_37919;
        char p_and_eq_x_y_37921 = cond_37866 && eq_x_y_30924;
        char eq_x_z_37922 = p_and_eq_x_y_37921 || not_p_37878;
        char p_and_eq_x_y_37923 = not_p_37880 && eq_x_z_37922;
        char cond_37924 = p_and_eq_x_y_37900 || p_and_eq_x_y_37923;
        char p_and_eq_x_y_37925 = not_p_37888 && eq_x_z_30916;
        char p_and_eq_x_y_37926 = cond_37866 && eq_x_z_30916;
        char p_and_eq_x_y_37927 = not_p_37878 && p_and_eq_x_y_37925;
        char eq_x_z_37928 = p_and_eq_x_y_37926 || p_and_eq_x_y_37927;
        char p_and_eq_x_y_37929 = not_p_37880 && eq_x_z_37928;
        char p_and_eq_x_y_37930 = cond_37867 && eq_x_y_30918;
        char p_and_eq_x_y_37931 = not_p_37888 && eq_x_z_30920;
        char eq_x_z_37932 = p_and_eq_x_y_37930 || p_and_eq_x_y_37931;
        char p_and_eq_x_y_37933 = cond_37866 && eq_x_z_30920;
        char p_and_eq_x_y_37934 = not_p_37878 && eq_x_z_37932;
        char eq_x_z_37935 = p_and_eq_x_y_37933 || p_and_eq_x_y_37934;
        char p_and_eq_x_y_37936 = not_p_37880 && eq_x_z_37935;
        char cond_37937 = p_and_eq_x_y_37885 || p_and_eq_x_y_37936;
        int32_t res_37938;
        int32_t res_37939;
        float res_37940;
        
        if (cond_37937) {
            res_37938 = res_37876;
            res_37939 = arg_30895;
            res_37940 = 1.0F;
        } else {
            res_37938 = 0;
            res_37939 = 0;
            res_37940 = 0.0F;
        }
        
        int32_t res_37941;
        int32_t res_37942;
        float res_37943;
        
        if (p_and_eq_x_y_37929) {
            res_37941 = res_37876;
            res_37942 = 1;
            res_37943 = 1.0F;
        } else {
            res_37941 = res_37938;
            res_37942 = res_37939;
            res_37943 = res_37940;
        }
        
        int32_t res_37944;
        int32_t res_37945;
        float res_37946;
        
        if (cond_37924) {
            res_37944 = arg_30895;
            res_37945 = res_37877;
            res_37946 = 1.0F;
        } else {
            res_37944 = res_37941;
            res_37945 = res_37942;
            res_37946 = res_37943;
        }
        
        int32_t res_37947;
        int32_t res_37948;
        float res_37949;
        
        if (cond_37920) {
            res_37947 = 1;
            res_37948 = res_37877;
            res_37949 = 1.0F;
        } else {
            res_37947 = res_37944;
            res_37948 = res_37945;
            res_37949 = res_37946;
        }
        
        float x_37950 = sitofp_i32_f32(res_37947);
        float x_37951 = sitofp_i32_f32(res_37948);
        int32_t res_37952;
        int32_t res_37953;
        float res_37954;
        
        if (y_37862) {
            res_37952 = arg_37856;
            res_37953 = arg_30895;
            res_37954 = 1.0F;
        } else {
            res_37952 = 0;
            res_37953 = 0;
            res_37954 = 0.0F;
        }
        
        int32_t res_37955;
        int32_t res_37956;
        float res_37957;
        
        if (x_37861) {
            res_37955 = arg_37856;
            res_37956 = 1;
            res_37957 = 1.0F;
        } else {
            res_37955 = res_37952;
            res_37956 = res_37953;
            res_37957 = res_37954;
        }
        
        int32_t res_37958;
        int32_t res_37959;
        float res_37960;
        
        if (y_37859) {
            res_37958 = arg_30895;
            res_37959 = arg_37857;
            res_37960 = 1.0F;
        } else {
            res_37958 = res_37955;
            res_37959 = res_37956;
            res_37960 = res_37957;
        }
        
        int32_t res_37961;
        int32_t res_37962;
        float res_37963;
        
        if (x_37858) {
            res_37961 = 1;
            res_37962 = arg_37857;
            res_37963 = 1.0F;
        } else {
            res_37961 = res_37958;
            res_37962 = res_37959;
            res_37963 = res_37960;
        }
        
        float x_37964 = sitofp_i32_f32(res_37961);
        float x_37965 = sitofp_i32_f32(res_37962);
        float res_38082;
        
        if (res_37864) {
            float y_37966 = *(__global float *) &U0_mem_38117[(res_37912 *
                                                               g_30887 +
                                                               res_37913) * 4];
            float y_37967 = res_32512 * y_37966;
            float res_37968 = x_37915 - y_37967;
            float y_37969 = *(__global float *) &V0_mem_38119[(res_37912 *
                                                               g_30887 +
                                                               res_37913) * 4];
            float y_37970 = res_32512 * y_37969;
            float res_37971 = x_37916 - y_37970;
            char cond_37972 = res_37968 < 0.5F;
            float res_37973;
            
            if (cond_37972) {
                res_37973 = 0.5F;
            } else {
                res_37973 = res_37968;
            }
            
            char cond_37974 = y_32516 < res_37973;
            float res_37975;
            
            if (cond_37974) {
                res_37975 = y_32516;
            } else {
                res_37975 = res_37973;
            }
            
            int32_t res_37976 = fptosi_f32_i32(res_37975);
            int32_t res_37977 = res_37976 + 1;
            char cond_37978 = res_37971 < 0.5F;
            float res_37979;
            
            if (cond_37978) {
                res_37979 = 0.5F;
            } else {
                res_37979 = res_37971;
            }
            
            char cond_37980 = y_32516 < res_37979;
            float res_37981;
            
            if (cond_37980) {
                res_37981 = y_32516;
            } else {
                res_37981 = res_37979;
            }
            
            int32_t res_37982 = fptosi_f32_i32(res_37981);
            int32_t res_37983 = res_37982 + 1;
            float y_37984 = sitofp_i32_f32(res_37976);
            float res_37985 = res_37975 - y_37984;
            float res_37986 = 1.0F - res_37985;
            float y_37987 = sitofp_i32_f32(res_37982);
            float res_37988 = res_37981 - y_37987;
            float res_37989 = 1.0F - res_37988;
            float y_37990 = *(__global float *) &S1_mem_38172[(res_37976 *
                                                               g_30887 +
                                                               res_37982) * 4];
            float x_37991 = res_37989 * y_37990;
            float y_37992 = *(__global float *) &S1_mem_38172[(res_37976 *
                                                               g_30887 +
                                                               res_37983) * 4];
            float y_37993 = res_37988 * y_37992;
            float y_37994 = x_37991 + y_37993;
            float x_37995 = res_37986 * y_37994;
            float y_37996 = *(__global float *) &S1_mem_38172[(res_37977 *
                                                               g_30887 +
                                                               res_37982) * 4];
            float x_37997 = res_37989 * y_37996;
            float y_37998 = *(__global float *) &S1_mem_38172[(res_37977 *
                                                               g_30887 +
                                                               res_37983) * 4];
            float y_37999 = res_37988 * y_37998;
            float y_38000 = x_37997 + y_37999;
            float y_38001 = res_37985 * y_38000;
            float res_38002 = x_37995 + y_38001;
            float res_38003 = res_37914 * res_38002;
            float y_38004 = *(__global float *) &U0_mem_38117[(res_37947 *
                                                               g_30887 +
                                                               res_37948) * 4];
            float y_38005 = res_32512 * y_38004;
            float res_38006 = x_37950 - y_38005;
            float y_38007 = *(__global float *) &V0_mem_38119[(res_37947 *
                                                               g_30887 +
                                                               res_37948) * 4];
            float y_38008 = res_32512 * y_38007;
            float res_38009 = x_37951 - y_38008;
            char cond_38010 = res_38006 < 0.5F;
            float res_38011;
            
            if (cond_38010) {
                res_38011 = 0.5F;
            } else {
                res_38011 = res_38006;
            }
            
            char cond_38012 = y_32516 < res_38011;
            float res_38013;
            
            if (cond_38012) {
                res_38013 = y_32516;
            } else {
                res_38013 = res_38011;
            }
            
            int32_t res_38014 = fptosi_f32_i32(res_38013);
            int32_t res_38015 = res_38014 + 1;
            char cond_38016 = res_38009 < 0.5F;
            float res_38017;
            
            if (cond_38016) {
                res_38017 = 0.5F;
            } else {
                res_38017 = res_38009;
            }
            
            char cond_38018 = y_32516 < res_38017;
            float res_38019;
            
            if (cond_38018) {
                res_38019 = y_32516;
            } else {
                res_38019 = res_38017;
            }
            
            int32_t res_38020 = fptosi_f32_i32(res_38019);
            int32_t res_38021 = res_38020 + 1;
            float y_38022 = sitofp_i32_f32(res_38014);
            float res_38023 = res_38013 - y_38022;
            float res_38024 = 1.0F - res_38023;
            float y_38025 = sitofp_i32_f32(res_38020);
            float res_38026 = res_38019 - y_38025;
            float res_38027 = 1.0F - res_38026;
            float y_38028 = *(__global float *) &S1_mem_38172[(res_38014 *
                                                               g_30887 +
                                                               res_38020) * 4];
            float x_38029 = res_38027 * y_38028;
            float y_38030 = *(__global float *) &S1_mem_38172[(res_38014 *
                                                               g_30887 +
                                                               res_38021) * 4];
            float y_38031 = res_38026 * y_38030;
            float y_38032 = x_38029 + y_38031;
            float x_38033 = res_38024 * y_38032;
            float y_38034 = *(__global float *) &S1_mem_38172[(res_38015 *
                                                               g_30887 +
                                                               res_38020) * 4];
            float x_38035 = res_38027 * y_38034;
            float y_38036 = *(__global float *) &S1_mem_38172[(res_38015 *
                                                               g_30887 +
                                                               res_38021) * 4];
            float y_38037 = res_38026 * y_38036;
            float y_38038 = x_38035 + y_38037;
            float y_38039 = res_38023 * y_38038;
            float res_38040 = x_38033 + y_38039;
            float res_38041 = res_37949 * res_38040;
            float y_38042 = res_38003 + res_38041;
            float res_38043 = 0.5F * y_38042;
            
            res_38082 = res_38043;
        } else {
            float y_38044 = *(__global float *) &U0_mem_38117[(res_37961 *
                                                               g_30887 +
                                                               res_37962) * 4];
            float y_38045 = res_32512 * y_38044;
            float res_38046 = x_37964 - y_38045;
            float y_38047 = *(__global float *) &V0_mem_38119[(res_37961 *
                                                               g_30887 +
                                                               res_37962) * 4];
            float y_38048 = res_32512 * y_38047;
            float res_38049 = x_37965 - y_38048;
            char cond_38050 = res_38046 < 0.5F;
            float res_38051;
            
            if (cond_38050) {
                res_38051 = 0.5F;
            } else {
                res_38051 = res_38046;
            }
            
            char cond_38052 = y_32516 < res_38051;
            float res_38053;
            
            if (cond_38052) {
                res_38053 = y_32516;
            } else {
                res_38053 = res_38051;
            }
            
            int32_t res_38054 = fptosi_f32_i32(res_38053);
            int32_t res_38055 = res_38054 + 1;
            char cond_38056 = res_38049 < 0.5F;
            float res_38057;
            
            if (cond_38056) {
                res_38057 = 0.5F;
            } else {
                res_38057 = res_38049;
            }
            
            char cond_38058 = y_32516 < res_38057;
            float res_38059;
            
            if (cond_38058) {
                res_38059 = y_32516;
            } else {
                res_38059 = res_38057;
            }
            
            int32_t res_38060 = fptosi_f32_i32(res_38059);
            int32_t res_38061 = res_38060 + 1;
            float y_38062 = sitofp_i32_f32(res_38054);
            float res_38063 = res_38053 - y_38062;
            float res_38064 = 1.0F - res_38063;
            float y_38065 = sitofp_i32_f32(res_38060);
            float res_38066 = res_38059 - y_38065;
            float res_38067 = 1.0F - res_38066;
            float y_38068 = *(__global float *) &S1_mem_38172[(res_38054 *
                                                               g_30887 +
                                                               res_38060) * 4];
            float x_38069 = res_38067 * y_38068;
            float y_38070 = *(__global float *) &S1_mem_38172[(res_38054 *
                                                               g_30887 +
                                                               res_38061) * 4];
            float y_38071 = res_38066 * y_38070;
            float y_38072 = x_38069 + y_38071;
            float x_38073 = res_38064 * y_38072;
            float y_38074 = *(__global float *) &S1_mem_38172[(res_38055 *
                                                               g_30887 +
                                                               res_38060) * 4];
            float x_38075 = res_38067 * y_38074;
            float y_38076 = *(__global float *) &S1_mem_38172[(res_38055 *
                                                               g_30887 +
                                                               res_38061) * 4];
            float y_38077 = res_38066 * y_38076;
            float y_38078 = x_38075 + y_38077;
            float y_38079 = res_38063 * y_38078;
            float res_38080 = x_38073 + y_38079;
            float res_38081 = res_37963 * res_38080;
            
            res_38082 = res_38081;
        }
        res_38083 = res_38082;
    }
    // write kernel result
    {
        *(__global float *) &mem_38174[i_37806 * 4] = res_38083;
    }
}
__kernel void map_kernel_38086(int32_t arg_30895, __global
                               unsigned char *mem_38176)
{
    const uint kernel_thread_index_38086 = get_global_id(0);
    
    if (kernel_thread_index_38086 >= arg_30895)
        return;
    
    int32_t i_38087;
    
    // compute thread index
    {
        i_38087 = kernel_thread_index_38086;
    }
    // read kernel parameters
    { }
    
    int32_t res_38089 = i_38087 + 1;
    
    // write kernel result
    {
        *(__global int32_t *) &mem_38176[i_38087 * 4] = res_38089;
    }
}
__kernel void map_kernel_38111(__global unsigned char *mem_38176,
                               int32_t arg_30895, int32_t g_30887, __global
                               unsigned char *mem_38178)
{
    const uint kernel_thread_index_38111 = get_global_id(0);
    
    if (kernel_thread_index_38111 >= arg_30895)
        return;
    
    int32_t i_38112;
    int32_t i_38113;
    
    // compute thread index
    {
        i_38112 = kernel_thread_index_38111;
    }
    // read kernel parameters
    {
        i_38113 = *(__global int32_t *) &mem_38176[i_38112 * 4];
    }
    
    int32_t x_38114 = i_38113 * g_30887;
    
    // write kernel result
    {
        *(__global int32_t *) &mem_38178[i_38112 * 4] = x_38114;
    }
}
__kernel void map_kernel_38095(__global unsigned char *mem_38180, __global
                               unsigned char *mem_38176,
                               int32_t nesting_size_38093, __global
                               unsigned char *mem_38174, __global
                               unsigned char *mem_38178, int32_t arg_30895,
                               __global unsigned char *mem_38184)
{
    const uint kernel_thread_index_38095 = get_global_id(0);
    
    if (kernel_thread_index_38095 >= arg_30895 * arg_30895)
        return;
    
    int32_t i_38096;
    int32_t i_38097;
    int32_t x_38098;
    int32_t j_38099;
    
    // compute thread index
    {
        i_38096 = squot32(kernel_thread_index_38095, arg_30895);
        i_38097 = kernel_thread_index_38095 - squot32(kernel_thread_index_38095,
                                                      arg_30895) * arg_30895;
    }
    // read kernel parameters
    {
        x_38098 = *(__global int32_t *) &mem_38178[i_38096 * 4];
        j_38099 = *(__global int32_t *) &mem_38176[i_38097 * 4];
    }
    
    int32_t x_38100 = x_38098 + j_38099;
    float y_38101 = *(__global float *) &mem_38174[x_38100 * 4];
    float arg_38102 = 255.0F * y_38101;
    char cond_38103 = arg_38102 < 0.0F;
    char cond_38104 = 255.0F < arg_38102;
    int8_t res_38105 = fptosi_f32_i8(arg_38102);
    int8_t res_38106;
    
    if (cond_38104) {
        res_38106 = -1;
    } else {
        res_38106 = res_38105;
    }
    
    int8_t res_38107;
    
    if (cond_38103) {
        res_38107 = 0;
    } else {
        res_38107 = res_38106;
    }
    *(__global int8_t *) &mem_38180[kernel_thread_index_38095] = res_38107;
    *(__global int8_t *) &mem_38180[nesting_size_38093 +
                                    kernel_thread_index_38095] = res_38107;
    *(__global int8_t *) &mem_38180[2 * nesting_size_38093 +
                                    kernel_thread_index_38095] = res_38107;
    // write kernel result
    {
        for (int i_38264 = 0; i_38264 < 3; i_38264++) {
            *(__global int8_t *) &mem_38184[3 * (arg_30895 * i_38096) +
                                            (arg_30895 * i_38264 + i_38097)] =
                *(__global int8_t *) &mem_38180[nesting_size_38093 * i_38264 +
                                                kernel_thread_index_38095];
        }
    }
}
__kernel void fut_kernel_map_transpose_i8(__global int8_t *odata,
                                          uint odata_offset, __global
                                          int8_t *idata, uint idata_offset,
                                          uint width, uint height, __local
                                          int8_t *block)
{
    uint x_index;
    uint y_index;
    uint our_array_offset;
    
    // Adjust the input and output arrays with the basic offset.
    odata += odata_offset / sizeof(int8_t);
    idata += idata_offset / sizeof(int8_t);
    // Adjust the input and output arrays for the third dimension.
    our_array_offset = get_global_id(2) * width * height;
    odata += our_array_offset;
    idata += our_array_offset;
    // read the matrix tile into shared memory
    x_index = get_global_id(0);
    y_index = get_global_id(1);
    if (x_index < width && y_index < height) {
        uint index_in = y_index * width + x_index;
        
        block[get_local_id(1) * (FUT_BLOCK_DIM + 1) + get_local_id(0)] =
            idata[index_in];
    }
    barrier(CLK_LOCAL_MEM_FENCE);
    // Write the transposed matrix tile to global memory.
    x_index = get_group_id(1) * FUT_BLOCK_DIM + get_local_id(0);
    y_index = get_group_id(0) * FUT_BLOCK_DIM + get_local_id(1);
    if (x_index < height && y_index < width) {
        uint index_out = y_index * height + x_index;
        
        odata[index_out] = block[get_local_id(0) * (FUT_BLOCK_DIM + 1) +
                                 get_local_id(1)];
    }
}
"""
# Hacky parser/reader for values written in Futhark syntax.  Used for
# reading stdin when compiling standalone programs with the Python
# code generator.

lookahead_buffer = []

def reset_lookahead():
    global lookahead_buffer
    lookahead_buffer = []

def get_char(f):
    global lookahead_buffer
    if len(lookahead_buffer) == 0:
        return f.read(1)
    else:
        c = lookahead_buffer[0]
        lookahead_buffer = lookahead_buffer[1:]
        return c

def unget_char(f, c):
    global lookahead_buffer
    lookahead_buffer = [c] + lookahead_buffer

def peek_char(f):
    c = get_char(f)
    if c:
        unget_char(f, c)
    return c

def skip_spaces(f):
    c = get_char(f)
    while c != None:
        if c.isspace():
            c = get_char(f)
        elif c == '-':
          # May be line comment.
          if peek_char(f) == '-':
            # Yes, line comment. Skip to end of line.
            while (c != '\n' and c != None):
              c = get_char(f)
          else:
            break
        else:
          break
    if c:
        unget_char(f, c)

def parse_specific_char(f, expected):
    got = get_char(f)
    if got != expected:
        unget_char(f, got)
        raise ValueError
    return True

def parse_specific_string(f, s):
    for c in s:
        parse_specific_char(f, c)
    return True

def optional(p, *args):
    try:
        return p(*args)
    except ValueError:
        return None

def sepBy(p, sep, *args):
    elems = []
    x = optional(p, *args)
    if x != None:
        elems += [x]
        while optional(sep, *args) != None:
            x = p(*args)
            elems += [x]
    return elems

def parse_int(f):
    s = ''
    c = get_char(f)
    while c != None:
        if c.isdigit():
            s += c
            c = get_char(f)
        else:
            unget_char(f, c)
            break
    optional(read_int_trailer, f)
    return s

def parse_int_signed(f):
    s = ''
    c = get_char(f)

    if c == '-' and peek_char(f).isdigit():
      s = c + parse_int(f)
    else:
      unget_char(f, c)
      s = parse_int(f)

    return s

def read_int_trailer(f):
  parse_specific_char(f, 'i')
  while peek_char(f).isdigit():
    get_char(f)

def read_comma(f):
    skip_spaces(f)
    parse_specific_char(f, ',')
    return ','

def read_int(f):
    skip_spaces(f)
    return int(parse_int_signed(f))

def read_char(f):
    skip_spaces(f)
    parse_specific_char(f, '\'')
    c = get_char(f)
    parse_specific_char(f, '\'')
    return c

def read_double(f):
    skip_spaces(f)
    c = get_char(f)
    if (c == '-'):
      sign = '-'
    else:
      unget_char(f,c)
      sign = ''
    bef = optional(parse_int, f)
    if bef == None:
        bef = '0'
        parse_specific_char(f, '.')
        aft = parse_int(f)
    elif optional(parse_specific_char, f, '.'):
        aft = parse_int(f)
    else:
        aft = '0'
    if (optional(parse_specific_char, f, 'E') or
        optional(parse_specific_char, f, 'e')):
        expt = parse_int_signed(f)
    else:
        expt = '0'
    optional(read_float_trailer, f)
    return float(sign + bef + '.' + aft + 'E' + expt)

def read_float(f):
    return read_double(f)

def read_float_trailer(f):
  parse_specific_char(f, 'f')
  while peek_char(f).isdigit():
    get_char(f)

def read_bool(f):
    skip_spaces(f)
    if peek_char(f) == 'T':
        parse_specific_string(f, 'True')
        return True
    elif peek_char(f) == 'F':
        parse_specific_string(f, 'False')
        return False
    else:
        raise ValueError

def read_array_elems(f, elem_reader):
    skip_spaces(f)
    parse_specific_char(f, '[')
    xs = sepBy(elem_reader, read_comma, f)
    skip_spaces(f)
    parse_specific_char(f, ']')
    return xs

def read_array_helper(f, elem_reader, rank):
    def nested_row_reader(_):
        return read_array_helper(f, elem_reader, rank-1)
    if rank == 1:
        row_reader = elem_reader
    else:
        row_reader = nested_row_reader
    return read_array_elems(f, row_reader)

def expected_array_dims(l, rank):
  if rank > 1:
      n = len(l)
      if n == 0:
          elem = []
      else:
          elem = l[0]
      return [n] + expected_array_dims(elem, rank-1)
  else:
      return [len(l)]

def verify_array_dims(l, dims):
    if dims[0] != len(l):
        raise ValueError
    if len(dims) > 1:
        for x in l:
            verify_array_dims(x, dims[1:])

def read_double_signed(f):

    skip_spaces(f)
    c = get_char(f)

    if c == '-' and peek_char(f).isdigit():
      v = -1 * read_double(f)
    else:
      unget_char(f, c)
      v = read_double(f)

    return v

def read_array(f, elem_reader, rank, bt):
    elems = read_array_helper(f, elem_reader, rank)
    dims = expected_array_dims(elems, rank)
    verify_array_dims(elems, dims)
    return np.array(elems, dtype=bt)
# Scalar functions.

import numpy as np

def signed(x):
  if type(x) == np.uint8:
    return np.int8(x)
  elif type(x) == np.uint16:
    return np.int16(x)
  elif type(x) == np.uint32:
    return np.int32(x)
  else:
    return np.int64(x)

def unsigned(x):
  if type(x) == np.int8:
    return np.uint8(x)
  elif type(x) == np.int16:
    return np.uint16(x)
  elif type(x) == np.int32:
    return np.uint32(x)
  else:
    return np.uint64(x)

def shlN(x,y):
  return x << y

def ashrN(x,y):
  return x >> y

def sdivN(x,y):
  return x / y

def smodN(x,y):
  return x % y

def udivN(x,y):
  return signed(unsigned(x) / unsigned(y))

def umodN(x,y):
  return signed(unsigned(x) % unsigned(y))

def squotN(x,y):
  return np.int32(float(x) / float(y))

def sremN(x,y):
  return np.fmod(x,y)

def powN(x,y):
  return x ** y

def fpowN(x,y):
  return x ** y

def sleN(x,y):
  return x <= y

def sltN(x,y):
  return x < y

def uleN(x,y):
  return unsigned(x) <= unsigned(y)

def ultN(x,y):
  return unsigned(x) < unsigned(y)

def lshr8(x,y):
  return np.int8(np.uint8(x) >> np.uint8(y))

def lshr16(x,y):
  return np.int16(np.uint16(x) >> np.uint16(y))

def lshr32(x,y):
  return np.int32(np.uint32(x) >> np.uint32(y))

def lshr64(x,y):
  return np.int64(np.uint64(x) >> np.uint64(y))

def sext_T_i8(x):
  return np.int8(x)

def sext_T_i16(x):
  return np.int16(x)

def sext_T_i32(x):
  return np.int32(x)

def sext_T_i64(x):
  return np.int32(x)

def zext_i8_i8(x):
  return np.int8(np.uint8(x))

def zext_i8_i16(x):
  return np.int16(np.uint8(x))

def zext_i8_i32(x):
  return np.int32(np.uint8(x))

def zext_i8_i64(x):
  return np.int64(np.uint8(x))

def zext_i16_i8(x):
  return np.int8(np.uint16(x))

def zext_i16_i16(x):
  return np.int16(np.uint16(x))

def zext_i16_i32(x):
  return np.int32(np.uint16(x))

def zext_i16_i64(x):
  return np.int64(np.uint16(x))

def zext_i32_i8(x):
  return np.int8(np.uint32(x))

def zext_i32_i16(x):
  return np.int16(np.uint32(x))

def zext_i32_i32(x):
  return np.int32(np.uint32(x))

def zext_i32_i64(x):
  return np.int64(np.uint32(x))

def zext_i64_i8(x):
  return np.int8(np.uint64(x))

def zext_i64_i16(x):
  return np.int16(np.uint64(x))

def zext_i64_i32(x):
  return np.int32(np.uint64(x))

def zext_i64_i64(x):
  return np.int64(np.uint64(x))

shl8 = shl16 = shl32 = shl64 = shlN
ashr8 = ashr16 = ashr32 = ashr64 = ashrN
sdiv8 = sdiv16 = sdiv32 = sdiv64 = sdivN
smod8 = smod16 = smod32 = smod64 = smodN
udiv8 = udiv16 = udiv32 = udiv64 = udivN
umod8 = umod16 = umod32 = umod64 = umodN
squot8 = squot16 = squot32 = squot64 = squotN
srem8 = srem16 = srem32 = srem64 = sremN
pow8 = pow16 = pow32 = pow64 = powN
fpow32 = fpow64 = fpowN
sle8 = sle16 = sle32 = sle64 = sleN
slt8 = slt16 = slt32 = slt64 = sltN
ule8 = ule16 = ule32 = ule64 = uleN
ult8 = ult16 = ult32 = ult64 = ultN
sext_i8_i8 = sext_i16_i8 = sext_i32_i8 = sext_i64_i8 = sext_T_i8
sext_i8_i16 = sext_i16_i16 = sext_i32_i16 = sext_i64_i16 = sext_T_i16
sext_i8_i32 = sext_i16_i32 = sext_i32_i32 = sext_i64_i32 = sext_T_i32
sext_i8_i64 = sext_i16_i64 = sext_i32_i64 = sext_i64_i64 = sext_T_i64

def ssignum(x):
  return np.sign(x)

def usignum(x):
  if x < 0:
    return ssignum(-x)
  else:
    return ssignum(x)

def sitofp_T_f32(x):
  return np.float32(x)
sitofp_i8_f32 = sitofp_i16_f32 = sitofp_i32_f32 = sitofp_i64_f32 = sitofp_T_f32

def sitofp_T_f64(x):
  return np.float64(x)
sitofp_i8_f64 = sitofp_i16_f64 = sitofp_i32_f64 = sitofp_i64_f64 = sitofp_T_f64

def uitofp_T_f32(x):
  return np.float32(unsigned(x))
uitofp_i8_f32 = uitofp_i16_f32 = uitofp_i32_f32 = uitofp_i64_f32 = uitofp_T_f32

def uitofp_T_f64(x):
  return np.float64(unsigned(x))
uitofp_i8_f64 = uitofp_i16_f64 = uitofp_i32_f64 = uitofp_i64_f64 = uitofp_T_f64

def fptosi_T_i8(x):
  return np.int8(np.trunc(x))
fptosi_f32_i8 = fptosi_f64_i8 = fptosi_T_i8

def fptosi_T_i16(x):
  return np.int16(np.trunc(x))
fptosi_f32_i16 = fptosi_f64_i16 = fptosi_T_i16

def fptosi_T_i32(x):
  return np.int32(np.trunc(x))
fptosi_f32_i32 = fptosi_f64_i32 = fptosi_T_i32

def fptosi_T_i64(x):
  return np.int64(np.trunc(x))
fptosi_f32_i64 = fptosi_f64_i64 = fptosi_T_i64

def fptoui_T_i8(x):
  return np.uint8(np.trunc(x))
fptoui_f32_i8 = fptoui_f64_i8 = fptoui_T_i8

def fptoui_T_i16(x):
  return np.uint16(np.trunc(x))
fptoui_f32_i16 = fptoui_f64_i16 = fptoui_T_i16

def fptoui_T_i32(x):
  return np.uint32(np.trunc(x))
fptoui_f32_i32 = fptoui_f64_i32 = fptoui_T_i32

def fptoui_T_i64(x):
  return np.uint64(np.trunc(x))
fptoui_f32_i64 = fptoui_f64_i64 = fptoui_T_i64

def fpconv_f32_f64(x):
  return np.float64(x)

def fpconv_f64_f32(x):
  return np.float32(x)

def futhark_log64(x):
  return np.float64(np.log(x))

def futhark_sqrt64(x):
  return np.sqrt(x)

def futhark_exp64(x):
  return np.exp(x)

def futhark_cos64(x):
  return np.cos(x)

def futhark_sin64(x):
  return np.sin(x)

def futhark_atan2_64(x, y):
  return np.arctan2(x, y)

def futhark_isnan64(x):
  return np.isnan(x)

def futhark_isinf64(x):
  return np.isinf(x)

def futhark_log32(x):
  return np.float32(np.log(x))

def futhark_sqrt32(x):
  return np.float32(np.sqrt(x))

def futhark_exp32(x):
  return np.exp(x)

def futhark_cos32(x):
  return np.cos(x)

def futhark_sin32(x):
  return np.sin(x)

def futhark_atan2_32(x, y):
  return np.arctan2(x, y)

def futhark_isnan32(x):
  return np.isnan(x)

def futhark_isinf32(x):
  return np.isinf(x)
class fluid_visualize_densities_one_frame_rgb:
  def __init__(self):
    self.ctx = cl.create_some_context(interactive=False)
    self.queue = cl.CommandQueue(self.ctx)
     # XXX: Assuming just a single device here.
    platform_name = self.ctx.get_info(cl.context_info.DEVICES)[0].platform.name
    device_type = self.ctx.get_info(cl.context_info.DEVICES)[0].type
    lockstep_width = 1
    if ((platform_name == "NVIDIA CUDA") and (device_type == cl.device_type.GPU)):
      lockstep_width = np.int32(32)
    if ((platform_name == "AMD Accelerated Parallel Processing") and (device_type == cl.device_type.GPU)):
      lockstep_width = np.int32(64)
    if (len(fut_opencl_src) >= 0):
      program = cl.Program(self.ctx, fut_opencl_src).build(["-DFUT_BLOCK_DIM={}".format(FUT_BLOCK_DIM), "-DLOCKSTEP_WIDTH={}".format(lockstep_width)])
    
    self.map_kernel_38211_var = program.map_kernel_38211
    self.map_kernel_38215_var = program.map_kernel_38215
    self.map_kernel_35236_var = program.map_kernel_35236
    self.map_kernel_35426_var = program.map_kernel_35426
    self.map_kernel_35616_var = program.map_kernel_35616
    self.map_kernel_35778_var = program.map_kernel_35778
    self.map_kernel_35967_var = program.map_kernel_35967
    self.map_kernel_36280_var = program.map_kernel_36280
    self.map_kernel_36898_var = program.map_kernel_36898
    self.map_kernel_37088_var = program.map_kernel_37088
    self.map_kernel_37277_var = program.map_kernel_37277
    self.map_kernel_37448_var = program.map_kernel_37448
    self.map_kernel_37620_var = program.map_kernel_37620
    self.map_kernel_37805_var = program.map_kernel_37805
    self.map_kernel_38086_var = program.map_kernel_38086
    self.map_kernel_38111_var = program.map_kernel_38111
    self.map_kernel_38095_var = program.map_kernel_38095
    self.fut_kernel_map_transpose_i8_var = program.fut_kernel_map_transpose_i8
  def futhark_main(self, U0_mem_size_38116, V0_mem_size_38118,
                   D0_mem_size_38120, U0_mem_38117, V0_mem_38119, D0_mem_38121,
                   g_30887, n_solver_steps_30891, time_step_30892,
                   diffusion_rate_30893, viscosity_30894):
    arg_30895 = (g_30887 - np.int32(2))
    x_30896 = (time_step_30892 * viscosity_30894)
    y_30898 = sitofp_i32_f32(arg_30895)
    x_30899 = (x_30896 * y_30898)
    res_30900 = (x_30899 * y_30898)
    y_30901 = (np.float32(4.0) * res_30900)
    arg_30902 = (np.float32(1.0) + y_30901)
    x_30903 = (g_30887 * g_30887)
    y_30904 = (np.int32(2) * g_30887)
    x_30905 = (x_30903 + y_30904)
    x_30906 = (x_30905 + np.int32(1))
    y_30907 = (g_30887 + np.int32(1))
    x_30908 = sdiv32(x_30906, y_30907)
    res_30909 = (x_30908 - g_30887)
    bytes_38122 = (np.int32(4) * g_30887)
    mem_38123 = cl.Buffer(self.ctx, cl.mem_flags.READ_WRITE,
                          long(long(bytes_38122) if (bytes_38122 > np.int32(0)) else np.int32(1)))
    group_size_38213 = np.int32(512)
    num_groups_38214 = squot32(((g_30887 + group_size_38213) - np.int32(1)),
                               group_size_38213)
    if ((np.int32(1) * (num_groups_38214 * group_size_38213)) != np.int32(0)):
      self.map_kernel_38211_var.set_args(np.int32(g_30887), mem_38123)
      cl.enqueue_nd_range_kernel(self.queue, self.map_kernel_38211_var,
                                 (long((num_groups_38214 * group_size_38213)),),
                                 (long(group_size_38213),))
      if synchronous:
        self.queue.finish()
    bytes_38124 = (bytes_38122 * g_30887)
    mem_38126 = cl.Buffer(self.ctx, cl.mem_flags.READ_WRITE,
                          long(long(bytes_38124) if (bytes_38124 > np.int32(0)) else np.int32(1)))
    group_size_38219 = np.int32(512)
    num_groups_38220 = squot32((((g_30887 * g_30887) + group_size_38219) - np.int32(1)),
                               group_size_38219)
    if ((np.int32(1) * (num_groups_38220 * group_size_38219)) != np.int32(0)):
      self.map_kernel_38215_var.set_args(mem_38123, np.int32(g_30887),
                                         mem_38126)
      cl.enqueue_nd_range_kernel(self.queue, self.map_kernel_38215_var,
                                 (long((num_groups_38220 * group_size_38219)),),
                                 (long(group_size_38219),))
      if synchronous:
        self.queue.finish()
    y_30914 = (g_30887 - np.int32(1))
    eq_x_z_30916 = (np.int32(0) == arg_30895)
    eq_x_y_30918 = (y_30914 == np.int32(1))
    eq_x_z_30920 = (y_30914 == arg_30895)
    eq_x_y_30922 = (np.int32(0) == y_30914)
    eq_x_y_30924 = (y_30914 == np.int32(0))
    bytes_38129 = (np.int32(4) * x_30903)
    double_buffer_mem_38190 = cl.Buffer(self.ctx, cl.mem_flags.READ_WRITE,
                                        long(long(bytes_38129) if (bytes_38129 > np.int32(0)) else np.int32(1)))
    mem_38130 = cl.Buffer(self.ctx, cl.mem_flags.READ_WRITE,
                          long(long(bytes_38129) if (bytes_38129 > np.int32(0)) else np.int32(1)))
    S1_mem_size_38127 = bytes_38124
    S1_mem_38128 = mem_38126
    k_30941 = np.int32(0)
    one_38268 = np.int32(1)
    for counter_38267 in range(n_solver_steps_30891):
      group_size_38224 = np.int32(512)
      num_groups_38225 = squot32(((x_30903 + group_size_38224) - np.int32(1)),
                                 group_size_38224)
      if ((np.int32(1) * (num_groups_38225 * group_size_38224)) != np.int32(0)):
        self.map_kernel_35236_var.set_args(np.byte(eq_x_z_30920),
                                           np.float32(res_30900),
                                           np.byte(eq_x_z_30916),
                                           np.byte(eq_x_y_30924), S1_mem_38128,
                                           np.int32(res_30909), U0_mem_38117,
                                           np.int32(y_30914),
                                           np.byte(eq_x_y_30922),
                                           np.float32(arg_30902),
                                           np.byte(eq_x_y_30918),
                                           np.int32(arg_30895),
                                           np.int32(x_30903), np.int32(g_30887),
                                           mem_38130)
        cl.enqueue_nd_range_kernel(self.queue, self.map_kernel_35236_var,
                                   (long((num_groups_38225 * group_size_38224)),),
                                   (long(group_size_38224),))
        if synchronous:
          self.queue.finish()
      if (((g_30887 * g_30887) * np.int32(4)) != np.int32(0)):
        cl.enqueue_copy(self.queue, double_buffer_mem_38190, mem_38130,
                        dest_offset=long(np.int32(0)),
                        src_offset=long(np.int32(0)),
                        byte_count=long(((g_30887 * g_30887) * np.int32(4))))
      if synchronous:
        self.queue.finish()
      S1_mem_size_tmp_38221 = bytes_38129
      S1_mem_tmp_38222 = double_buffer_mem_38190
      S1_mem_size_38127 = S1_mem_size_tmp_38221
      S1_mem_38128 = S1_mem_tmp_38222
      k_30941 += one_38268
    S1_mem_38132 = S1_mem_38128
    S1_mem_size_38131 = S1_mem_size_38127
    double_buffer_mem_38192 = cl.Buffer(self.ctx, cl.mem_flags.READ_WRITE,
                                        long(long(bytes_38129) if (bytes_38129 > np.int32(0)) else np.int32(1)))
    mem_38136 = cl.Buffer(self.ctx, cl.mem_flags.READ_WRITE,
                          long(long(bytes_38129) if (bytes_38129 > np.int32(0)) else np.int32(1)))
    S1_mem_size_38133 = bytes_38124
    S1_mem_38134 = mem_38126
    k_31189 = np.int32(0)
    one_38270 = np.int32(1)
    for counter_38269 in range(n_solver_steps_30891):
      group_size_38229 = np.int32(512)
      num_groups_38230 = squot32(((x_30903 + group_size_38229) - np.int32(1)),
                                 group_size_38229)
      if ((np.int32(1) * (num_groups_38230 * group_size_38229)) != np.int32(0)):
        self.map_kernel_35426_var.set_args(np.byte(eq_x_z_30920),
                                           np.float32(res_30900),
                                           np.byte(eq_x_z_30916),
                                           np.byte(eq_x_y_30924),
                                           np.int32(res_30909),
                                           np.int32(y_30914),
                                           np.byte(eq_x_y_30922),
                                           np.float32(arg_30902), S1_mem_38134,
                                           np.byte(eq_x_y_30918),
                                           np.int32(arg_30895),
                                           np.int32(x_30903), V0_mem_38119,
                                           np.int32(g_30887), mem_38136)
        cl.enqueue_nd_range_kernel(self.queue, self.map_kernel_35426_var,
                                   (long((num_groups_38230 * group_size_38229)),),
                                   (long(group_size_38229),))
        if synchronous:
          self.queue.finish()
      if (((g_30887 * g_30887) * np.int32(4)) != np.int32(0)):
        cl.enqueue_copy(self.queue, double_buffer_mem_38192, mem_38136,
                        dest_offset=long(np.int32(0)),
                        src_offset=long(np.int32(0)),
                        byte_count=long(((g_30887 * g_30887) * np.int32(4))))
      if synchronous:
        self.queue.finish()
      S1_mem_size_tmp_38226 = bytes_38129
      S1_mem_tmp_38227 = double_buffer_mem_38192
      S1_mem_size_38133 = S1_mem_size_tmp_38226
      S1_mem_38134 = S1_mem_tmp_38227
      k_31189 += one_38270
    S1_mem_38138 = S1_mem_38134
    S1_mem_size_38137 = S1_mem_size_38133
    y_31410 = sitofp_i32_f32(g_30887)
    mem_38140 = cl.Buffer(self.ctx, cl.mem_flags.READ_WRITE,
                          long(long(bytes_38129) if (bytes_38129 > np.int32(0)) else np.int32(1)))
    group_size_38231 = np.int32(512)
    num_groups_38232 = squot32(((x_30903 + group_size_38231) - np.int32(1)),
                               group_size_38231)
    if ((np.int32(1) * (num_groups_38232 * group_size_38231)) != np.int32(0)):
      self.map_kernel_35616_var.set_args(np.byte(eq_x_z_30920), S1_mem_38132,
                                         np.byte(eq_x_z_30916),
                                         np.byte(eq_x_y_30924),
                                         np.int32(res_30909),
                                         np.float32(y_31410), S1_mem_38138,
                                         np.int32(y_30914),
                                         np.byte(eq_x_y_30922),
                                         np.byte(eq_x_y_30918),
                                         np.int32(arg_30895), np.int32(x_30903),
                                         np.int32(g_30887), mem_38140)
      cl.enqueue_nd_range_kernel(self.queue, self.map_kernel_35616_var,
                                 (long((num_groups_38232 * group_size_38231)),),
                                 (long(group_size_38231),))
      if synchronous:
        self.queue.finish()
    double_buffer_mem_38194 = cl.Buffer(self.ctx, cl.mem_flags.READ_WRITE,
                                        long(long(bytes_38129) if (bytes_38129 > np.int32(0)) else np.int32(1)))
    mem_38144 = cl.Buffer(self.ctx, cl.mem_flags.READ_WRITE,
                          long(long(bytes_38129) if (bytes_38129 > np.int32(0)) else np.int32(1)))
    S1_mem_size_38141 = bytes_38124
    S1_mem_38142 = mem_38126
    k_31652 = np.int32(0)
    one_38272 = np.int32(1)
    for counter_38271 in range(n_solver_steps_30891):
      group_size_38236 = np.int32(512)
      num_groups_38237 = squot32(((x_30903 + group_size_38236) - np.int32(1)),
                                 group_size_38236)
      if ((np.int32(1) * (num_groups_38237 * group_size_38236)) != np.int32(0)):
        self.map_kernel_35778_var.set_args(np.byte(eq_x_z_30920), mem_38140,
                                           np.byte(eq_x_z_30916),
                                           np.byte(eq_x_y_30924),
                                           np.int32(res_30909),
                                           np.int32(y_30914),
                                           np.byte(eq_x_y_30922), S1_mem_38142,
                                           np.byte(eq_x_y_30918),
                                           np.int32(arg_30895),
                                           np.int32(x_30903), np.int32(g_30887),
                                           mem_38144)
        cl.enqueue_nd_range_kernel(self.queue, self.map_kernel_35778_var,
                                   (long((num_groups_38237 * group_size_38236)),),
                                   (long(group_size_38236),))
        if synchronous:
          self.queue.finish()
      if (((g_30887 * g_30887) * np.int32(4)) != np.int32(0)):
        cl.enqueue_copy(self.queue, double_buffer_mem_38194, mem_38144,
                        dest_offset=long(np.int32(0)),
                        src_offset=long(np.int32(0)),
                        byte_count=long(((g_30887 * g_30887) * np.int32(4))))
      if synchronous:
        self.queue.finish()
      S1_mem_size_tmp_38233 = bytes_38129
      S1_mem_tmp_38234 = double_buffer_mem_38194
      S1_mem_size_38141 = S1_mem_size_tmp_38233
      S1_mem_38142 = S1_mem_tmp_38234
      k_31652 += one_38272
    S1_mem_38146 = S1_mem_38142
    S1_mem_size_38145 = S1_mem_size_38141
    x_31869 = (np.float32(0.5) * y_30898)
    mem_38148 = cl.Buffer(self.ctx, cl.mem_flags.READ_WRITE,
                          long(long(bytes_38129) if (bytes_38129 > np.int32(0)) else np.int32(1)))
    mem_38150 = cl.Buffer(self.ctx, cl.mem_flags.READ_WRITE,
                          long(long(bytes_38129) if (bytes_38129 > np.int32(0)) else np.int32(1)))
    group_size_38238 = np.int32(512)
    num_groups_38239 = squot32(((x_30903 + group_size_38238) - np.int32(1)),
                               group_size_38238)
    if ((np.int32(1) * (num_groups_38239 * group_size_38238)) != np.int32(0)):
      self.map_kernel_35967_var.set_args(np.byte(eq_x_z_30920), S1_mem_38132,
                                         np.byte(eq_x_z_30916),
                                         np.byte(eq_x_y_30924),
                                         np.float32(x_31869),
                                         np.int32(res_30909), S1_mem_38138,
                                         S1_mem_38146, np.int32(y_30914),
                                         np.byte(eq_x_y_30922),
                                         np.byte(eq_x_y_30918),
                                         np.int32(arg_30895), np.int32(x_30903),
                                         np.int32(g_30887), mem_38148,
                                         mem_38150)
      cl.enqueue_nd_range_kernel(self.queue, self.map_kernel_35967_var,
                                 (long((num_groups_38239 * group_size_38238)),),
                                 (long(group_size_38238),))
      if synchronous:
        self.queue.finish()
    res_32512 = (time_step_30892 * y_30898)
    y_32516 = (y_30898 + np.float32(0.5))
    mem_38152 = cl.Buffer(self.ctx, cl.mem_flags.READ_WRITE,
                          long(long(bytes_38129) if (bytes_38129 > np.int32(0)) else np.int32(1)))
    mem_38154 = cl.Buffer(self.ctx, cl.mem_flags.READ_WRITE,
                          long(long(bytes_38129) if (bytes_38129 > np.int32(0)) else np.int32(1)))
    group_size_38240 = np.int32(512)
    num_groups_38241 = squot32(((x_30903 + group_size_38240) - np.int32(1)),
                               group_size_38240)
    if ((np.int32(1) * (num_groups_38241 * group_size_38240)) != np.int32(0)):
      self.map_kernel_36280_var.set_args(np.float32(res_32512),
                                         np.byte(eq_x_z_30920), mem_38148,
                                         np.byte(eq_x_z_30916),
                                         np.float32(y_32516),
                                         np.byte(eq_x_y_30924),
                                         np.int32(res_30909), np.int32(y_30914),
                                         np.byte(eq_x_y_30922), mem_38150,
                                         np.byte(eq_x_y_30918),
                                         np.int32(arg_30895), np.int32(x_30903),
                                         np.int32(g_30887), mem_38152,
                                         mem_38154)
      cl.enqueue_nd_range_kernel(self.queue, self.map_kernel_36280_var,
                                 (long((num_groups_38241 * group_size_38240)),),
                                 (long(group_size_38240),))
      if synchronous:
        self.queue.finish()
    mem_38156 = cl.Buffer(self.ctx, cl.mem_flags.READ_WRITE,
                          long(long(bytes_38129) if (bytes_38129 > np.int32(0)) else np.int32(1)))
    group_size_38242 = np.int32(512)
    num_groups_38243 = squot32(((x_30903 + group_size_38242) - np.int32(1)),
                               group_size_38242)
    if ((np.int32(1) * (num_groups_38243 * group_size_38242)) != np.int32(0)):
      self.map_kernel_36898_var.set_args(np.byte(eq_x_z_30920), mem_38152,
                                         np.byte(eq_x_z_30916),
                                         np.byte(eq_x_y_30924),
                                         np.int32(res_30909),
                                         np.float32(y_31410), np.int32(y_30914),
                                         np.byte(eq_x_y_30922), mem_38154,
                                         np.byte(eq_x_y_30918),
                                         np.int32(arg_30895), np.int32(x_30903),
                                         np.int32(g_30887), mem_38156)
      cl.enqueue_nd_range_kernel(self.queue, self.map_kernel_36898_var,
                                 (long((num_groups_38243 * group_size_38242)),),
                                 (long(group_size_38242),))
      if synchronous:
        self.queue.finish()
    double_buffer_mem_38196 = cl.Buffer(self.ctx, cl.mem_flags.READ_WRITE,
                                        long(long(bytes_38129) if (bytes_38129 > np.int32(0)) else np.int32(1)))
    mem_38160 = cl.Buffer(self.ctx, cl.mem_flags.READ_WRITE,
                          long(long(bytes_38129) if (bytes_38129 > np.int32(0)) else np.int32(1)))
    S1_mem_size_38157 = bytes_38124
    S1_mem_38158 = mem_38126
    k_33939 = np.int32(0)
    one_38274 = np.int32(1)
    for counter_38273 in range(n_solver_steps_30891):
      group_size_38247 = np.int32(512)
      num_groups_38248 = squot32(((x_30903 + group_size_38247) - np.int32(1)),
                                 group_size_38247)
      if ((np.int32(1) * (num_groups_38248 * group_size_38247)) != np.int32(0)):
        self.map_kernel_37088_var.set_args(np.byte(eq_x_z_30920),
                                           np.byte(eq_x_z_30916),
                                           np.byte(eq_x_y_30924), mem_38156,
                                           np.int32(res_30909),
                                           np.int32(y_30914),
                                           np.byte(eq_x_y_30922),
                                           np.byte(eq_x_y_30918), S1_mem_38158,
                                           np.int32(arg_30895),
                                           np.int32(x_30903), np.int32(g_30887),
                                           mem_38160)
        cl.enqueue_nd_range_kernel(self.queue, self.map_kernel_37088_var,
                                   (long((num_groups_38248 * group_size_38247)),),
                                   (long(group_size_38247),))
        if synchronous:
          self.queue.finish()
      if (((g_30887 * g_30887) * np.int32(4)) != np.int32(0)):
        cl.enqueue_copy(self.queue, double_buffer_mem_38196, mem_38160,
                        dest_offset=long(np.int32(0)),
                        src_offset=long(np.int32(0)),
                        byte_count=long(((g_30887 * g_30887) * np.int32(4))))
      if synchronous:
        self.queue.finish()
      S1_mem_size_tmp_38244 = bytes_38129
      S1_mem_tmp_38245 = double_buffer_mem_38196
      S1_mem_size_38157 = S1_mem_size_tmp_38244
      S1_mem_38158 = S1_mem_tmp_38245
      k_33939 += one_38274
    S1_mem_38162 = S1_mem_38158
    S1_mem_size_38161 = S1_mem_size_38157
    mem_38164 = cl.Buffer(self.ctx, cl.mem_flags.READ_WRITE,
                          long(long(bytes_38129) if (bytes_38129 > np.int32(0)) else np.int32(1)))
    group_size_38249 = np.int32(512)
    num_groups_38250 = squot32(((x_30903 + group_size_38249) - np.int32(1)),
                               group_size_38249)
    if ((np.int32(1) * (num_groups_38250 * group_size_38249)) != np.int32(0)):
      self.map_kernel_37277_var.set_args(np.byte(eq_x_z_30920),
                                         np.byte(eq_x_z_30916),
                                         np.byte(eq_x_y_30924),
                                         np.float32(x_31869),
                                         np.int32(res_30909), np.int32(y_30914),
                                         np.byte(eq_x_y_30922), mem_38154,
                                         S1_mem_38162, np.byte(eq_x_y_30918),
                                         np.int32(arg_30895), np.int32(x_30903),
                                         np.int32(g_30887), mem_38164)
      cl.enqueue_nd_range_kernel(self.queue, self.map_kernel_37277_var,
                                 (long((num_groups_38250 * group_size_38249)),),
                                 (long(group_size_38249),))
      if synchronous:
        self.queue.finish()
    mem_38166 = cl.Buffer(self.ctx, cl.mem_flags.READ_WRITE,
                          long(long(bytes_38129) if (bytes_38129 > np.int32(0)) else np.int32(1)))
    group_size_38251 = np.int32(512)
    num_groups_38252 = squot32(((x_30903 + group_size_38251) - np.int32(1)),
                               group_size_38251)
    if ((np.int32(1) * (num_groups_38252 * group_size_38251)) != np.int32(0)):
      self.map_kernel_37448_var.set_args(np.byte(eq_x_z_30920), mem_38152,
                                         np.byte(eq_x_z_30916),
                                         np.byte(eq_x_y_30924),
                                         np.float32(x_31869),
                                         np.int32(res_30909), np.int32(y_30914),
                                         np.byte(eq_x_y_30922), S1_mem_38162,
                                         np.byte(eq_x_y_30918),
                                         np.int32(arg_30895), np.int32(x_30903),
                                         np.int32(g_30887), mem_38166)
      cl.enqueue_nd_range_kernel(self.queue, self.map_kernel_37448_var,
                                 (long((num_groups_38252 * group_size_38251)),),
                                 (long(group_size_38251),))
      if synchronous:
        self.queue.finish()
    x_34619 = (time_step_30892 * diffusion_rate_30893)
    x_34620 = (x_34619 * y_30898)
    res_34621 = (x_34620 * y_30898)
    y_34622 = (np.float32(4.0) * res_34621)
    arg_34623 = (np.float32(1.0) + y_34622)
    double_buffer_mem_38198 = cl.Buffer(self.ctx, cl.mem_flags.READ_WRITE,
                                        long(long(bytes_38129) if (bytes_38129 > np.int32(0)) else np.int32(1)))
    mem_38170 = cl.Buffer(self.ctx, cl.mem_flags.READ_WRITE,
                          long(long(bytes_38129) if (bytes_38129 > np.int32(0)) else np.int32(1)))
    S1_mem_size_38167 = bytes_38124
    S1_mem_38168 = mem_38126
    k_34652 = np.int32(0)
    one_38276 = np.int32(1)
    for counter_38275 in range(n_solver_steps_30891):
      group_size_38256 = np.int32(512)
      num_groups_38257 = squot32(((x_30903 + group_size_38256) - np.int32(1)),
                                 group_size_38256)
      if ((np.int32(1) * (num_groups_38257 * group_size_38256)) != np.int32(0)):
        self.map_kernel_37620_var.set_args(np.byte(eq_x_z_30920), S1_mem_38168,
                                           np.byte(eq_x_z_30916),
                                           np.byte(eq_x_y_30924),
                                           np.float32(res_34621),
                                           np.int32(res_30909), D0_mem_38121,
                                           np.int32(y_30914),
                                           np.byte(eq_x_y_30922),
                                           np.byte(eq_x_y_30918),
                                           np.int32(arg_30895),
                                           np.int32(x_30903),
                                           np.float32(arg_34623),
                                           np.int32(g_30887), mem_38170)
        cl.enqueue_nd_range_kernel(self.queue, self.map_kernel_37620_var,
                                   (long((num_groups_38257 * group_size_38256)),),
                                   (long(group_size_38256),))
        if synchronous:
          self.queue.finish()
      if (((g_30887 * g_30887) * np.int32(4)) != np.int32(0)):
        cl.enqueue_copy(self.queue, double_buffer_mem_38198, mem_38170,
                        dest_offset=long(np.int32(0)),
                        src_offset=long(np.int32(0)),
                        byte_count=long(((g_30887 * g_30887) * np.int32(4))))
      if synchronous:
        self.queue.finish()
      S1_mem_size_tmp_38253 = bytes_38129
      S1_mem_tmp_38254 = double_buffer_mem_38198
      S1_mem_size_38167 = S1_mem_size_tmp_38253
      S1_mem_38168 = S1_mem_tmp_38254
      k_34652 += one_38276
    S1_mem_38172 = S1_mem_38168
    S1_mem_size_38171 = S1_mem_size_38167
    mem_38174 = cl.Buffer(self.ctx, cl.mem_flags.READ_WRITE,
                          long(long(bytes_38129) if (bytes_38129 > np.int32(0)) else np.int32(1)))
    group_size_38258 = np.int32(512)
    num_groups_38259 = squot32(((x_30903 + group_size_38258) - np.int32(1)),
                               group_size_38258)
    if ((np.int32(1) * (num_groups_38259 * group_size_38258)) != np.int32(0)):
      self.map_kernel_37805_var.set_args(np.float32(res_32512),
                                         np.byte(eq_x_z_30920),
                                         np.byte(eq_x_z_30916),
                                         np.float32(y_32516),
                                         np.byte(eq_x_y_30924), S1_mem_38172,
                                         np.int32(res_30909), U0_mem_38117,
                                         np.int32(y_30914),
                                         np.byte(eq_x_y_30922),
                                         np.byte(eq_x_y_30918),
                                         np.int32(arg_30895), np.int32(x_30903),
                                         V0_mem_38119, np.int32(g_30887),
                                         mem_38174)
      cl.enqueue_nd_range_kernel(self.queue, self.map_kernel_37805_var,
                                 (long((num_groups_38259 * group_size_38258)),),
                                 (long(group_size_38258),))
      if synchronous:
        self.queue.finish()
    bytes_38175 = (np.int32(4) * arg_30895)
    mem_38176 = cl.Buffer(self.ctx, cl.mem_flags.READ_WRITE,
                          long(long(bytes_38175) if (bytes_38175 > np.int32(0)) else np.int32(1)))
    group_size_38260 = np.int32(512)
    num_groups_38261 = squot32(((arg_30895 + group_size_38260) - np.int32(1)),
                               group_size_38260)
    if ((np.int32(1) * (num_groups_38261 * group_size_38260)) != np.int32(0)):
      self.map_kernel_38086_var.set_args(np.int32(arg_30895), mem_38176)
      cl.enqueue_nd_range_kernel(self.queue, self.map_kernel_38086_var,
                                 (long((num_groups_38261 * group_size_38260)),),
                                 (long(group_size_38260),))
      if synchronous:
        self.queue.finish()
    mem_38178 = cl.Buffer(self.ctx, cl.mem_flags.READ_WRITE,
                          long(long(bytes_38175) if (bytes_38175 > np.int32(0)) else np.int32(1)))
    group_size_38262 = np.int32(512)
    num_groups_38263 = squot32(((arg_30895 + group_size_38262) - np.int32(1)),
                               group_size_38262)
    if ((np.int32(1) * (num_groups_38263 * group_size_38262)) != np.int32(0)):
      self.map_kernel_38111_var.set_args(mem_38176, np.int32(arg_30895),
                                         np.int32(g_30887), mem_38178)
      cl.enqueue_nd_range_kernel(self.queue, self.map_kernel_38111_var,
                                 (long((num_groups_38263 * group_size_38262)),),
                                 (long(group_size_38262),))
      if synchronous:
        self.queue.finish()
    nesting_size_38093 = (arg_30895 * arg_30895)
    x_38183 = (arg_30895 * np.int32(3))
    bytes_38181 = (x_38183 * arg_30895)
    mem_38184 = cl.Buffer(self.ctx, cl.mem_flags.READ_WRITE,
                          long(long(bytes_38181) if (bytes_38181 > np.int32(0)) else np.int32(1)))
    total_size_38200 = (nesting_size_38093 * np.int32(3))
    mem_38180 = cl.Buffer(self.ctx, cl.mem_flags.READ_WRITE,
                          long(long(total_size_38200) if (total_size_38200 > np.int32(0)) else np.int32(1)))
    group_size_38265 = np.int32(512)
    num_groups_38266 = squot32((((arg_30895 * arg_30895) + group_size_38265) - np.int32(1)),
                               group_size_38265)
    if ((np.int32(1) * (num_groups_38266 * group_size_38265)) != np.int32(0)):
      self.map_kernel_38095_var.set_args(mem_38180, mem_38176,
                                         np.int32(nesting_size_38093),
                                         mem_38174, mem_38178,
                                         np.int32(arg_30895), mem_38184)
      cl.enqueue_nd_range_kernel(self.queue, self.map_kernel_38095_var,
                                 (long((num_groups_38266 * group_size_38265)),),
                                 (long(group_size_38265),))
      if synchronous:
        self.queue.finish()
    bytes_38185 = (nesting_size_38093 * np.int32(3))
    mem_38188 = cl.Buffer(self.ctx, cl.mem_flags.READ_WRITE,
                          long(long(bytes_38185) if (bytes_38185 > np.int32(0)) else np.int32(1)))
    if ((((np.int32(1) * (arg_30895 + srem32((np.int32(16) - srem32(arg_30895,
                                                                    np.int32(16))),
                                             np.int32(16)))) * (np.int32(3) + srem32((np.int32(16) - srem32(np.int32(3),
                                                                                                            np.int32(16))),
                                                                                     np.int32(16)))) * arg_30895) != np.int32(0)):
      self.fut_kernel_map_transpose_i8_var.set_args(mem_38188,
                                                    np.int32(np.int32(0)),
                                                    mem_38184,
                                                    np.int32(np.int32(0)),
                                                    np.int32(arg_30895),
                                                    np.int32(np.int32(3)),
                                                    cl.LocalMemory(long((((np.int32(16) + np.int32(1)) * np.int32(16)) * np.int32(1)))))
      cl.enqueue_nd_range_kernel(self.queue,
                                 self.fut_kernel_map_transpose_i8_var,
                                 (long((arg_30895 + srem32((np.int32(16) - srem32(arg_30895,
                                                                                  np.int32(16))),
                                                           np.int32(16)))),
                                  long((np.int32(3) + srem32((np.int32(16) - srem32(np.int32(3),
                                                                                    np.int32(16))),
                                                             np.int32(16)))),
                                  long(arg_30895)), (long(np.int32(16)),
                                                     long(np.int32(16)),
                                                     long(np.int32(1))))
      if synchronous:
        self.queue.finish()
    out_mem_38201 = mem_38188
    out_arrsize_38203 = arg_30895
    out_arrsize_38204 = arg_30895
    out_memsize_38202 = bytes_38185
    out_mem_38205 = mem_38164
    out_memsize_38206 = bytes_38129
    out_mem_38207 = mem_38166
    out_memsize_38208 = bytes_38129
    out_mem_38209 = mem_38174
    out_memsize_38210 = bytes_38129
    return (out_memsize_38202, out_mem_38201, out_arrsize_38203,
            out_arrsize_38204, out_memsize_38206, out_mem_38205,
            out_memsize_38208, out_mem_38207, out_memsize_38210, out_mem_38209)
  def main(self, U0_mem_38117_ext, V0_mem_38119_ext, D0_mem_38121_ext,
           n_solver_steps_30891_ext, time_step_30892_ext,
           diffusion_rate_30893_ext, viscosity_30894_ext):
    g_30887 = np.int32(U0_mem_38117_ext.shape[np.int32(0)])
    g_30887 = np.int32(U0_mem_38117_ext.shape[np.int32(1)])
    U0_mem_size_38116 = np.int32(U0_mem_38117_ext.nbytes)
    U0_mem_device_38277 = cl.Buffer(self.ctx, cl.mem_flags.READ_WRITE,
                                    long(long(U0_mem_size_38116) if (U0_mem_size_38116 > np.int32(0)) else np.int32(1)))
    U0_mem_38117 = U0_mem_38117_ext
    if (U0_mem_38117_ext.nbytes != np.int32(0)):
      cl.enqueue_copy(self.queue, U0_mem_device_38277,
                      U0_mem_38117[np.int32(0):(np.int32(0) + (U0_mem_38117_ext.nbytes // 4))],
                      device_offset=long(np.int32(0)), is_blocking=synchronous)
    U0_mem_38117 = U0_mem_device_38277
    g_30887 = np.int32(V0_mem_38119_ext.shape[np.int32(0)])
    g_30887 = np.int32(V0_mem_38119_ext.shape[np.int32(1)])
    V0_mem_size_38118 = np.int32(V0_mem_38119_ext.nbytes)
    V0_mem_device_38278 = cl.Buffer(self.ctx, cl.mem_flags.READ_WRITE,
                                    long(long(V0_mem_size_38118) if (V0_mem_size_38118 > np.int32(0)) else np.int32(1)))
    V0_mem_38119 = V0_mem_38119_ext
    if (V0_mem_38119_ext.nbytes != np.int32(0)):
      cl.enqueue_copy(self.queue, V0_mem_device_38278,
                      V0_mem_38119[np.int32(0):(np.int32(0) + (V0_mem_38119_ext.nbytes // 4))],
                      device_offset=long(np.int32(0)), is_blocking=synchronous)
    V0_mem_38119 = V0_mem_device_38278
    g_30887 = np.int32(D0_mem_38121_ext.shape[np.int32(0)])
    g_30887 = np.int32(D0_mem_38121_ext.shape[np.int32(1)])
    D0_mem_size_38120 = np.int32(D0_mem_38121_ext.nbytes)
    D0_mem_device_38279 = cl.Buffer(self.ctx, cl.mem_flags.READ_WRITE,
                                    long(long(D0_mem_size_38120) if (D0_mem_size_38120 > np.int32(0)) else np.int32(1)))
    D0_mem_38121 = D0_mem_38121_ext
    if (D0_mem_38121_ext.nbytes != np.int32(0)):
      cl.enqueue_copy(self.queue, D0_mem_device_38279,
                      D0_mem_38121[np.int32(0):(np.int32(0) + (D0_mem_38121_ext.nbytes // 4))],
                      device_offset=long(np.int32(0)), is_blocking=synchronous)
    D0_mem_38121 = D0_mem_device_38279
    n_solver_steps_30891 = np.int32(n_solver_steps_30891_ext)
    time_step_30892 = np.float32(time_step_30892_ext)
    diffusion_rate_30893 = np.float32(diffusion_rate_30893_ext)
    viscosity_30894 = np.float32(viscosity_30894_ext)
    (out_memsize_38202, out_mem_38201, out_arrsize_38203, out_arrsize_38204,
     out_memsize_38206, out_mem_38205, out_memsize_38208, out_mem_38207,
     out_memsize_38210, out_mem_38209) = self.futhark_main(U0_mem_size_38116,
                                                           V0_mem_size_38118,
                                                           D0_mem_size_38120,
                                                           U0_mem_38117,
                                                           V0_mem_38119,
                                                           D0_mem_38121,
                                                           g_30887,
                                                           n_solver_steps_30891,
                                                           time_step_30892,
                                                           diffusion_rate_30893,
                                                           viscosity_30894)
    out_mem_device_38280 = np.empty((out_arrsize_38203, out_arrsize_38204,
                                     np.int32(3)), dtype=ct.c_int8)
    if (out_memsize_38202 != np.int32(0)):
      cl.enqueue_copy(self.queue,
                      out_mem_device_38280[np.int32(0):(np.int32(0) + (out_memsize_38202 // 1))],
                      out_mem_38201, device_offset=long(np.int32(0)),
                      is_blocking=synchronous)
    out_mem_38201 = out_mem_device_38280
    out_mem_device_38281 = np.empty((g_30887, g_30887), dtype=ct.c_float)
    if (out_memsize_38206 != np.int32(0)):
      cl.enqueue_copy(self.queue,
                      out_mem_device_38281[np.int32(0):(np.int32(0) + (out_memsize_38206 // 4))],
                      out_mem_38205, device_offset=long(np.int32(0)),
                      is_blocking=synchronous)
    out_mem_38205 = out_mem_device_38281
    out_mem_device_38282 = np.empty((g_30887, g_30887), dtype=ct.c_float)
    if (out_memsize_38208 != np.int32(0)):
      cl.enqueue_copy(self.queue,
                      out_mem_device_38282[np.int32(0):(np.int32(0) + (out_memsize_38208 // 4))],
                      out_mem_38207, device_offset=long(np.int32(0)),
                      is_blocking=synchronous)
    out_mem_38207 = out_mem_device_38282
    out_mem_device_38283 = np.empty((g_30887, g_30887), dtype=ct.c_float)
    if (out_memsize_38210 != np.int32(0)):
      cl.enqueue_copy(self.queue,
                      out_mem_device_38283[np.int32(0):(np.int32(0) + (out_memsize_38210 // 4))],
                      out_mem_38209, device_offset=long(np.int32(0)),
                      is_blocking=synchronous)
    out_mem_38209 = out_mem_device_38283
    return (out_mem_38201, out_mem_38205, out_mem_38207, out_mem_38209)