import sys
import numpy as np
import ctypes as ct
import pyopencl as cl
import time
import argparse
FUT_BLOCK_DIM = "16"
cl_group_size = np.int32(512)
synchronous = False
fut_opencl_src = """typedef char int8_t;
typedef short int16_t;
typedef int int32_t;
typedef long int64_t;
typedef uchar uint8_t;
typedef ushort uint16_t;
typedef uint uint32_t;
typedef ulong uint64_t;
static inline int8_t add8(int8_t x, int8_t y)
{
    return x + y;
}
static inline int16_t add16(int16_t x, int16_t y)
{
    return x + y;
}
static inline int32_t add32(int32_t x, int32_t y)
{
    return x + y;
}
static inline int64_t add64(int64_t x, int64_t y)
{
    return x + y;
}
static inline int8_t sub8(int8_t x, int8_t y)
{
    return x - y;
}
static inline int16_t sub16(int16_t x, int16_t y)
{
    return x - y;
}
static inline int32_t sub32(int32_t x, int32_t y)
{
    return x - y;
}
static inline int64_t sub64(int64_t x, int64_t y)
{
    return x - y;
}
static inline int8_t mul8(int8_t x, int8_t y)
{
    return x * y;
}
static inline int16_t mul16(int16_t x, int16_t y)
{
    return x * y;
}
static inline int32_t mul32(int32_t x, int32_t y)
{
    return x * y;
}
static inline int64_t mul64(int64_t x, int64_t y)
{
    return x * y;
}
static inline uint8_t udiv8(uint8_t x, uint8_t y)
{
    return x / y;
}
static inline uint16_t udiv16(uint16_t x, uint16_t y)
{
    return x / y;
}
static inline uint32_t udiv32(uint32_t x, uint32_t y)
{
    return x / y;
}
static inline uint64_t udiv64(uint64_t x, uint64_t y)
{
    return x / y;
}
static inline uint8_t umod8(uint8_t x, uint8_t y)
{
    return x % y;
}
static inline uint16_t umod16(uint16_t x, uint16_t y)
{
    return x % y;
}
static inline uint32_t umod32(uint32_t x, uint32_t y)
{
    return x % y;
}
static inline uint64_t umod64(uint64_t x, uint64_t y)
{
    return x % y;
}
static inline int8_t sdiv8(int8_t x, int8_t y)
{
    int8_t q = x / y;
    int8_t r = x % y;
    
    return q - ((r != 0 && r < 0 != y < 0) ? 1 : 0);
}
static inline int16_t sdiv16(int16_t x, int16_t y)
{
    int16_t q = x / y;
    int16_t r = x % y;
    
    return q - ((r != 0 && r < 0 != y < 0) ? 1 : 0);
}
static inline int32_t sdiv32(int32_t x, int32_t y)
{
    int32_t q = x / y;
    int32_t r = x % y;
    
    return q - ((r != 0 && r < 0 != y < 0) ? 1 : 0);
}
static inline int64_t sdiv64(int64_t x, int64_t y)
{
    int64_t q = x / y;
    int64_t r = x % y;
    
    return q - ((r != 0 && r < 0 != y < 0) ? 1 : 0);
}
static inline int8_t smod8(int8_t x, int8_t y)
{
    int8_t r = x % y;
    
    return r + (r == 0 || (x > 0 && y > 0) || (x < 0 && y < 0) ? 0 : y);
}
static inline int16_t smod16(int16_t x, int16_t y)
{
    int16_t r = x % y;
    
    return r + (r == 0 || (x > 0 && y > 0) || (x < 0 && y < 0) ? 0 : y);
}
static inline int32_t smod32(int32_t x, int32_t y)
{
    int32_t r = x % y;
    
    return r + (r == 0 || (x > 0 && y > 0) || (x < 0 && y < 0) ? 0 : y);
}
static inline int64_t smod64(int64_t x, int64_t y)
{
    int64_t r = x % y;
    
    return r + (r == 0 || (x > 0 && y > 0) || (x < 0 && y < 0) ? 0 : y);
}
static inline int8_t squot8(int8_t x, int8_t y)
{
    return x / y;
}
static inline int16_t squot16(int16_t x, int16_t y)
{
    return x / y;
}
static inline int32_t squot32(int32_t x, int32_t y)
{
    return x / y;
}
static inline int64_t squot64(int64_t x, int64_t y)
{
    return x / y;
}
static inline int8_t srem8(int8_t x, int8_t y)
{
    return x % y;
}
static inline int16_t srem16(int16_t x, int16_t y)
{
    return x % y;
}
static inline int32_t srem32(int32_t x, int32_t y)
{
    return x % y;
}
static inline int64_t srem64(int64_t x, int64_t y)
{
    return x % y;
}
static inline uint8_t shl8(uint8_t x, uint8_t y)
{
    return x << y;
}
static inline uint16_t shl16(uint16_t x, uint16_t y)
{
    return x << y;
}
static inline uint32_t shl32(uint32_t x, uint32_t y)
{
    return x << y;
}
static inline uint64_t shl64(uint64_t x, uint64_t y)
{
    return x << y;
}
static inline uint8_t lshr8(uint8_t x, uint8_t y)
{
    return x >> y;
}
static inline uint16_t lshr16(uint16_t x, uint16_t y)
{
    return x >> y;
}
static inline uint32_t lshr32(uint32_t x, uint32_t y)
{
    return x >> y;
}
static inline uint64_t lshr64(uint64_t x, uint64_t y)
{
    return x >> y;
}
static inline int8_t ashr8(int8_t x, int8_t y)
{
    return x >> y;
}
static inline int16_t ashr16(int16_t x, int16_t y)
{
    return x >> y;
}
static inline int32_t ashr32(int32_t x, int32_t y)
{
    return x >> y;
}
static inline int64_t ashr64(int64_t x, int64_t y)
{
    return x >> y;
}
static inline uint8_t and8(uint8_t x, uint8_t y)
{
    return x & y;
}
static inline uint16_t and16(uint16_t x, uint16_t y)
{
    return x & y;
}
static inline uint32_t and32(uint32_t x, uint32_t y)
{
    return x & y;
}
static inline uint64_t and64(uint64_t x, uint64_t y)
{
    return x & y;
}
static inline uint8_t or8(uint8_t x, uint8_t y)
{
    return x | y;
}
static inline uint16_t or16(uint16_t x, uint16_t y)
{
    return x | y;
}
static inline uint32_t or32(uint32_t x, uint32_t y)
{
    return x | y;
}
static inline uint64_t or64(uint64_t x, uint64_t y)
{
    return x | y;
}
static inline uint8_t xor8(uint8_t x, uint8_t y)
{
    return x ^ y;
}
static inline uint16_t xor16(uint16_t x, uint16_t y)
{
    return x ^ y;
}
static inline uint32_t xor32(uint32_t x, uint32_t y)
{
    return x ^ y;
}
static inline uint64_t xor64(uint64_t x, uint64_t y)
{
    return x ^ y;
}
static inline char ult8(uint8_t x, uint8_t y)
{
    return x < y;
}
static inline char ult16(uint16_t x, uint16_t y)
{
    return x < y;
}
static inline char ult32(uint32_t x, uint32_t y)
{
    return x < y;
}
static inline char ult64(uint64_t x, uint64_t y)
{
    return x < y;
}
static inline char ule8(uint8_t x, uint8_t y)
{
    return x <= y;
}
static inline char ule16(uint16_t x, uint16_t y)
{
    return x <= y;
}
static inline char ule32(uint32_t x, uint32_t y)
{
    return x <= y;
}
static inline char ule64(uint64_t x, uint64_t y)
{
    return x <= y;
}
static inline char slt8(int8_t x, int8_t y)
{
    return x < y;
}
static inline char slt16(int16_t x, int16_t y)
{
    return x < y;
}
static inline char slt32(int32_t x, int32_t y)
{
    return x < y;
}
static inline char slt64(int64_t x, int64_t y)
{
    return x < y;
}
static inline char sle8(int8_t x, int8_t y)
{
    return x <= y;
}
static inline char sle16(int16_t x, int16_t y)
{
    return x <= y;
}
static inline char sle32(int32_t x, int32_t y)
{
    return x <= y;
}
static inline char sle64(int64_t x, int64_t y)
{
    return x <= y;
}
static inline int8_t pow8(int8_t x, int8_t y)
{
    int8_t res = 1, rem = y;
    
    while (rem != 0) {
        if (rem & 1)
            res *= x;
        rem >>= 1;
        x *= x;
    }
    return res;
}
static inline int16_t pow16(int16_t x, int16_t y)
{
    int16_t res = 1, rem = y;
    
    while (rem != 0) {
        if (rem & 1)
            res *= x;
        rem >>= 1;
        x *= x;
    }
    return res;
}
static inline int32_t pow32(int32_t x, int32_t y)
{
    int32_t res = 1, rem = y;
    
    while (rem != 0) {
        if (rem & 1)
            res *= x;
        rem >>= 1;
        x *= x;
    }
    return res;
}
static inline int64_t pow64(int64_t x, int64_t y)
{
    int64_t res = 1, rem = y;
    
    while (rem != 0) {
        if (rem & 1)
            res *= x;
        rem >>= 1;
        x *= x;
    }
    return res;
}
static inline int8_t sext_i8_i8(int8_t x)
{
    return x;
}
static inline int16_t sext_i8_i16(int8_t x)
{
    return x;
}
static inline int32_t sext_i8_i32(int8_t x)
{
    return x;
}
static inline int64_t sext_i8_i64(int8_t x)
{
    return x;
}
static inline int8_t sext_i16_i8(int16_t x)
{
    return x;
}
static inline int16_t sext_i16_i16(int16_t x)
{
    return x;
}
static inline int32_t sext_i16_i32(int16_t x)
{
    return x;
}
static inline int64_t sext_i16_i64(int16_t x)
{
    return x;
}
static inline int8_t sext_i32_i8(int32_t x)
{
    return x;
}
static inline int16_t sext_i32_i16(int32_t x)
{
    return x;
}
static inline int32_t sext_i32_i32(int32_t x)
{
    return x;
}
static inline int64_t sext_i32_i64(int32_t x)
{
    return x;
}
static inline int8_t sext_i64_i8(int64_t x)
{
    return x;
}
static inline int16_t sext_i64_i16(int64_t x)
{
    return x;
}
static inline int32_t sext_i64_i32(int64_t x)
{
    return x;
}
static inline int64_t sext_i64_i64(int64_t x)
{
    return x;
}
static inline uint8_t zext_i8_i8(uint8_t x)
{
    return x;
}
static inline uint16_t zext_i8_i16(uint8_t x)
{
    return x;
}
static inline uint32_t zext_i8_i32(uint8_t x)
{
    return x;
}
static inline uint64_t zext_i8_i64(uint8_t x)
{
    return x;
}
static inline uint8_t zext_i16_i8(uint16_t x)
{
    return x;
}
static inline uint16_t zext_i16_i16(uint16_t x)
{
    return x;
}
static inline uint32_t zext_i16_i32(uint16_t x)
{
    return x;
}
static inline uint64_t zext_i16_i64(uint16_t x)
{
    return x;
}
static inline uint8_t zext_i32_i8(uint32_t x)
{
    return x;
}
static inline uint16_t zext_i32_i16(uint32_t x)
{
    return x;
}
static inline uint32_t zext_i32_i32(uint32_t x)
{
    return x;
}
static inline uint64_t zext_i32_i64(uint32_t x)
{
    return x;
}
static inline uint8_t zext_i64_i8(uint64_t x)
{
    return x;
}
static inline uint16_t zext_i64_i16(uint64_t x)
{
    return x;
}
static inline uint32_t zext_i64_i32(uint64_t x)
{
    return x;
}
static inline uint64_t zext_i64_i64(uint64_t x)
{
    return x;
}
static inline float fdiv32(float x, float y)
{
    return x / y;
}
static inline float fadd32(float x, float y)
{
    return x + y;
}
static inline float fsub32(float x, float y)
{
    return x - y;
}
static inline float fmul32(float x, float y)
{
    return x * y;
}
static inline float fpow32(float x, float y)
{
    return pow(x, y);
}
static inline char cmplt32(float x, float y)
{
    return x < y;
}
static inline char cmple32(float x, float y)
{
    return x <= y;
}
static inline float sitofp_i8_f32(int8_t x)
{
    return x;
}
static inline float sitofp_i16_f32(int16_t x)
{
    return x;
}
static inline float sitofp_i32_f32(int32_t x)
{
    return x;
}
static inline float sitofp_i64_f32(int64_t x)
{
    return x;
}
static inline float uitofp_i8_f32(uint8_t x)
{
    return x;
}
static inline float uitofp_i16_f32(uint16_t x)
{
    return x;
}
static inline float uitofp_i32_f32(uint32_t x)
{
    return x;
}
static inline float uitofp_i64_f32(uint64_t x)
{
    return x;
}
static inline int8_t fptosi_f32_i8(float x)
{
    return x;
}
static inline int16_t fptosi_f32_i16(float x)
{
    return x;
}
static inline int32_t fptosi_f32_i32(float x)
{
    return x;
}
static inline int64_t fptosi_f32_i64(float x)
{
    return x;
}
static inline uint8_t fptoui_f32_i8(float x)
{
    return x;
}
static inline uint16_t fptoui_f32_i16(float x)
{
    return x;
}
static inline uint32_t fptoui_f32_i32(float x)
{
    return x;
}
static inline uint64_t fptoui_f32_i64(float x)
{
    return x;
}
__kernel void map_kernel_1651(int32_t row_1120, __global
                              unsigned char *mem_1960, int32_t col_1121,
                              int32_t nesting_size_1649, __global
                              unsigned char *temp_mem_1958, __global
                              unsigned char *mem_1964)
{
    const uint kernel_thread_index_1651 = get_global_id(0);
    
    if (kernel_thread_index_1651 >= row_1120 * col_1121)
        return;
    
    int32_t i_1652;
    int32_t i_1653;
    float c_1654;
    
    // compute thread index
    {
        i_1652 = squot32(kernel_thread_index_1651, col_1121);
        i_1653 = kernel_thread_index_1651 - squot32(kernel_thread_index_1651,
                                                    col_1121) * col_1121;
    }
    // read kernel parameters
    {
        c_1654 = *(__global float *) &temp_mem_1958[(i_1652 * col_1121 +
                                                     i_1653) * 4];
    }
    
    char cond_1655 = c_1654 < 270.0F;
    char cond_1656 = 360.0F < c_1654;
    float res_1657;
    
    if (cond_1656) {
        res_1657 = 360.0F;
    } else {
        res_1657 = c_1654;
    }
    
    float res_1658;
    
    if (cond_1655) {
        res_1658 = 270.0F;
    } else {
        res_1658 = res_1657;
    }
    
    float x_1659 = res_1658 - 270.0F;
    float x_1660 = x_1659 / 90.0F;
    float res_1661 = x_1660 * 256.0F;
    int8_t arr_elem_1662 = fptosi_f32_i8(res_1661);
    
    *(__global int8_t *) &mem_1960[kernel_thread_index_1651] = arr_elem_1662;
    *(__global int8_t *) &mem_1960[nesting_size_1649 +
                                   kernel_thread_index_1651] = 0;
    *(__global int8_t *) &mem_1960[2 * nesting_size_1649 +
                                   kernel_thread_index_1651] = arr_elem_1662;
    // write kernel result
    {
        for (int i_2015 = 0; i_2015 < 3; i_2015++) {
            *(__global int8_t *) &mem_1964[3 * (col_1121 * i_1652) + (col_1121 *
                                                                      i_2015 +
                                                                      i_1653)] =
                *(__global int8_t *) &mem_1960[nesting_size_1649 * i_2015 +
                                               kernel_thread_index_1651];
        }
    }
}
__kernel void fut_kernel_map_transpose_i8(__global int8_t *odata,
                                          uint odata_offset, __global
                                          int8_t *idata, uint idata_offset,
                                          uint width, uint height, __local
                                          int8_t *block)
{
    uint x_index;
    uint y_index;
    uint our_array_offset;
    
    // Adjust the input and output arrays with the basic offset.
    odata += odata_offset / sizeof(int8_t);
    idata += idata_offset / sizeof(int8_t);
    // Adjust the input and output arrays for the third dimension.
    our_array_offset = get_global_id(2) * width * height;
    odata += our_array_offset;
    idata += our_array_offset;
    // read the matrix tile into shared memory
    x_index = get_global_id(0);
    y_index = get_global_id(1);
    if (x_index < width && y_index < height) {
        uint index_in = y_index * width + x_index;
        
        block[get_local_id(1) * (FUT_BLOCK_DIM + 1) + get_local_id(0)] =
            idata[index_in];
    }
    barrier(CLK_LOCAL_MEM_FENCE);
    // Write the transposed matrix tile to global memory.
    x_index = get_group_id(1) * FUT_BLOCK_DIM + get_local_id(0);
    y_index = get_group_id(0) * FUT_BLOCK_DIM + get_local_id(1);
    if (x_index < height && y_index < width) {
        uint index_out = y_index * height + x_index;
        
        odata[index_out] = block[get_local_id(0) * (FUT_BLOCK_DIM + 1) +
                                 get_local_id(1)];
    }
}
__kernel void map_kernel_1803(int32_t row_1137, int32_t y_1205, __global
                              unsigned char *mem_1975, __global
                              unsigned char *mem_1977, __global
                              unsigned char *mem_1979, __global
                              unsigned char *mem_1981)
{
    const uint kernel_thread_index_1803 = get_global_id(0);
    
    if (kernel_thread_index_1803 >= row_1137)
        return;
    
    int32_t i_1804;
    
    // compute thread index
    {
        i_1804 = kernel_thread_index_1803;
    }
    // read kernel parameters
    { }
    
    char x_1806 = i_1804 == 0;
    int32_t i_1807 = i_1804 + 1;
    char x_1808 = i_1804 == y_1205;
    int32_t i_1809 = i_1804 - 1;
    
    // write kernel result
    {
        *(__global char *) &mem_1975[i_1804] = x_1808;
        *(__global char *) &mem_1977[i_1804] = x_1806;
        *(__global int32_t *) &mem_1979[i_1804 * 4] = i_1807;
        *(__global int32_t *) &mem_1981[i_1804 * 4] = i_1809;
    }
}
__kernel void map_kernel_1679(int32_t y_1204, float res_1176, __global
                              unsigned char *mem_1981, float res_1165,
                              int32_t row_1137, __global
                              unsigned char *mem_1977, __global
                              unsigned char *power_mem_1973, int32_t col_1138,
                              float res_1171, __global unsigned char *mem_1975,
                              __global unsigned char *temp_mem_1983,
                              int32_t size_1187, float x_1203, __global
                              unsigned char *mem_1979, __global
                              unsigned char *mem_1986)
{
    const uint kernel_thread_index_1679 = get_global_id(0);
    
    if (kernel_thread_index_1679 >= row_1137 * col_1138)
        return;
    
    int32_t i_1680;
    int32_t i_1681;
    char x_1683;
    char x_1684;
    int32_t i_1685;
    int32_t i_1686;
    
    // compute thread index
    {
        i_1680 = squot32(kernel_thread_index_1679, col_1138);
        i_1681 = kernel_thread_index_1679 - squot32(kernel_thread_index_1679,
                                                    col_1138) * col_1138;
    }
    // read kernel parameters
    {
        x_1683 = *(__global char *) &mem_1975[i_1680];
        x_1684 = *(__global char *) &mem_1977[i_1680];
        i_1685 = *(__global int32_t *) &mem_1979[i_1680 * 4];
        i_1686 = *(__global int32_t *) &mem_1981[i_1680 * 4];
    }
    
    float x_1688 = *(__global float *) &power_mem_1973[(i_1680 * col_1138 +
                                                        i_1681) * 4];
    char y_1689 = i_1681 == 0;
    char cond_1690 = x_1684 && y_1689;
    int32_t i_1691 = i_1681 + 1;
    char y_1692 = i_1681 == y_1204;
    char cond_1693 = x_1684 && y_1692;
    int32_t i_1694 = i_1681 - 1;
    char cond_1695 = x_1683 && y_1692;
    char cond_1696 = x_1683 && y_1689;
    float y_1793;
    
    if (cond_1690) {
        float x_1697 = *(__global float *) &temp_mem_1983[(i_1680 * size_1187 +
                                                           i_1691) * 4];
        float y_1698 = *(__global float *) &temp_mem_1983[(i_1680 * size_1187 +
                                                           i_1681) * 4];
        float x_1699 = x_1697 - y_1698;
        float x_1700 = x_1699 / res_1165;
        float x_1701 = *(__global float *) &temp_mem_1983[(i_1685 * size_1187 +
                                                           i_1681) * 4];
        float x_1702 = x_1701 - y_1698;
        float y_1703 = x_1702 / res_1171;
        float res_1704 = x_1700 + y_1703;
        
        y_1793 = res_1704;
    } else {
        float res_1792;
        
        if (cond_1693) {
            float x_1705 = *(__global float *) &temp_mem_1983[(i_1680 *
                                                               size_1187 +
                                                               i_1694) * 4];
            float y_1706 = *(__global float *) &temp_mem_1983[(i_1680 *
                                                               size_1187 +
                                                               i_1681) * 4];
            float x_1707 = x_1705 - y_1706;
            float x_1708 = x_1707 / res_1165;
            float x_1709 = *(__global float *) &temp_mem_1983[(i_1685 *
                                                               size_1187 +
                                                               i_1681) * 4];
            float x_1710 = x_1709 - y_1706;
            float y_1711 = x_1710 / res_1171;
            float res_1712 = x_1708 + y_1711;
            
            res_1792 = res_1712;
        } else {
            float res_1791;
            
            if (cond_1695) {
                float x_1713 = *(__global float *) &temp_mem_1983[(i_1680 *
                                                                   size_1187 +
                                                                   i_1694) * 4];
                float y_1714 = *(__global float *) &temp_mem_1983[(i_1680 *
                                                                   size_1187 +
                                                                   i_1681) * 4];
                float x_1715 = x_1713 - y_1714;
                float x_1716 = x_1715 / res_1165;
                float x_1717 = *(__global float *) &temp_mem_1983[(i_1686 *
                                                                   size_1187 +
                                                                   i_1681) * 4];
                float x_1718 = x_1717 - y_1714;
                float y_1719 = x_1718 / res_1171;
                float res_1720 = x_1716 + y_1719;
                
                res_1791 = res_1720;
            } else {
                float res_1790;
                
                if (cond_1696) {
                    float x_1721 = *(__global float *) &temp_mem_1983[(i_1680 *
                                                                       size_1187 +
                                                                       i_1691) *
                                                                      4];
                    float y_1722 = *(__global float *) &temp_mem_1983[(i_1680 *
                                                                       size_1187 +
                                                                       i_1681) *
                                                                      4];
                    float x_1723 = x_1721 - y_1722;
                    float x_1724 = x_1723 / res_1165;
                    float x_1725 = *(__global float *) &temp_mem_1983[(i_1686 *
                                                                       size_1187 +
                                                                       i_1681) *
                                                                      4];
                    float x_1726 = x_1725 - y_1722;
                    float y_1727 = x_1726 / res_1171;
                    float res_1728 = x_1724 + y_1727;
                    
                    res_1790 = res_1728;
                } else {
                    float res_1789;
                    
                    if (x_1684) {
                        float x_1729 = *(__global
                                         float *) &temp_mem_1983[(i_1680 *
                                                                  size_1187 +
                                                                  i_1691) * 4];
                        float y_1730 = *(__global
                                         float *) &temp_mem_1983[(i_1680 *
                                                                  size_1187 +
                                                                  i_1694) * 4];
                        float x_1731 = x_1729 + y_1730;
                        float y_1732 = *(__global
                                         float *) &temp_mem_1983[(i_1680 *
                                                                  size_1187 +
                                                                  i_1681) * 4];
                        float y_1733 = 2.0F * y_1732;
                        float x_1734 = x_1731 - y_1733;
                        float x_1735 = x_1734 / res_1165;
                        float x_1736 = *(__global
                                         float *) &temp_mem_1983[(i_1685 *
                                                                  size_1187 +
                                                                  i_1681) * 4];
                        float x_1737 = x_1736 - y_1732;
                        float y_1738 = x_1737 / res_1171;
                        float res_1739 = x_1735 + y_1738;
                        
                        res_1789 = res_1739;
                    } else {
                        float res_1788;
                        
                        if (y_1692) {
                            float x_1740 = *(__global
                                             float *) &temp_mem_1983[(i_1680 *
                                                                      size_1187 +
                                                                      i_1694) *
                                                                     4];
                            float y_1741 = *(__global
                                             float *) &temp_mem_1983[(i_1680 *
                                                                      size_1187 +
                                                                      i_1681) *
                                                                     4];
                            float x_1742 = x_1740 - y_1741;
                            float x_1743 = x_1742 / res_1165;
                            float x_1744 = *(__global
                                             float *) &temp_mem_1983[(i_1685 *
                                                                      size_1187 +
                                                                      i_1681) *
                                                                     4];
                            float y_1745 = *(__global
                                             float *) &temp_mem_1983[(i_1686 *
                                                                      size_1187 +
                                                                      i_1681) *
                                                                     4];
                            float x_1746 = x_1744 + y_1745;
                            float y_1747 = 2.0F * y_1741;
                            float x_1748 = x_1746 - y_1747;
                            float y_1749 = x_1748 / res_1171;
                            float res_1750 = x_1743 + y_1749;
                            
                            res_1788 = res_1750;
                        } else {
                            float res_1787;
                            
                            if (x_1683) {
                                float x_1751 = *(__global
                                                 float *) &temp_mem_1983[(i_1680 *
                                                                          size_1187 +
                                                                          i_1691) *
                                                                         4];
                                float y_1752 = *(__global
                                                 float *) &temp_mem_1983[(i_1680 *
                                                                          size_1187 +
                                                                          i_1694) *
                                                                         4];
                                float x_1753 = x_1751 + y_1752;
                                float y_1754 = *(__global
                                                 float *) &temp_mem_1983[(i_1680 *
                                                                          size_1187 +
                                                                          i_1681) *
                                                                         4];
                                float y_1755 = 2.0F * y_1754;
                                float x_1756 = x_1753 - y_1755;
                                float x_1757 = x_1756 / res_1165;
                                float x_1758 = *(__global
                                                 float *) &temp_mem_1983[(i_1686 *
                                                                          size_1187 +
                                                                          i_1681) *
                                                                         4];
                                float x_1759 = x_1758 - y_1754;
                                float y_1760 = x_1759 / res_1171;
                                float res_1761 = x_1757 + y_1760;
                                
                                res_1787 = res_1761;
                            } else {
                                float res_1786;
                                
                                if (y_1689) {
                                    float x_1762 = *(__global
                                                     float *) &temp_mem_1983[(i_1680 *
                                                                              size_1187 +
                                                                              i_1691) *
                                                                             4];
                                    float y_1763 = *(__global
                                                     float *) &temp_mem_1983[(i_1680 *
                                                                              size_1187 +
                                                                              i_1681) *
                                                                             4];
                                    float x_1764 = x_1762 - y_1763;
                                    float x_1765 = x_1764 / res_1165;
                                    float x_1766 = *(__global
                                                     float *) &temp_mem_1983[(i_1685 *
                                                                              size_1187 +
                                                                              i_1681) *
                                                                             4];
                                    float y_1767 = *(__global
                                                     float *) &temp_mem_1983[(i_1686 *
                                                                              size_1187 +
                                                                              i_1681) *
                                                                             4];
                                    float x_1768 = x_1766 + y_1767;
                                    float y_1769 = 2.0F * y_1763;
                                    float x_1770 = x_1768 - y_1769;
                                    float y_1771 = x_1770 / res_1171;
                                    float res_1772 = x_1765 + y_1771;
                                    
                                    res_1786 = res_1772;
                                } else {
                                    float x_1773 = *(__global
                                                     float *) &temp_mem_1983[(i_1680 *
                                                                              size_1187 +
                                                                              i_1691) *
                                                                             4];
                                    float y_1774 = *(__global
                                                     float *) &temp_mem_1983[(i_1680 *
                                                                              size_1187 +
                                                                              i_1694) *
                                                                             4];
                                    float x_1775 = x_1773 + y_1774;
                                    float y_1776 = *(__global
                                                     float *) &temp_mem_1983[(i_1680 *
                                                                              size_1187 +
                                                                              i_1681) *
                                                                             4];
                                    float y_1777 = 2.0F * y_1776;
                                    float x_1778 = x_1775 - y_1777;
                                    float x_1779 = x_1778 / res_1165;
                                    float x_1780 = *(__global
                                                     float *) &temp_mem_1983[(i_1685 *
                                                                              size_1187 +
                                                                              i_1681) *
                                                                             4];
                                    float y_1781 = *(__global
                                                     float *) &temp_mem_1983[(i_1686 *
                                                                              size_1187 +
                                                                              i_1681) *
                                                                             4];
                                    float x_1782 = x_1780 + y_1781;
                                    float x_1783 = x_1782 - y_1777;
                                    float y_1784 = x_1783 / res_1171;
                                    float res_1785 = x_1779 + y_1784;
                                    
                                    res_1786 = res_1785;
                                }
                                res_1787 = res_1786;
                            }
                            res_1788 = res_1787;
                        }
                        res_1789 = res_1788;
                    }
                    res_1790 = res_1789;
                }
                res_1791 = res_1790;
            }
            res_1792 = res_1791;
        }
        y_1793 = res_1792;
    }
    
    float x_1794 = x_1688 + y_1793;
    float y_1795 = *(__global float *) &temp_mem_1983[(i_1680 * size_1187 +
                                                       i_1681) * 4];
    float x_1796 = 80.0F - y_1795;
    float y_1797 = x_1796 / res_1176;
    float y_1798 = x_1794 + y_1797;
    float res_1799 = x_1203 * y_1798;
    float res_1800 = y_1795 + res_1799;
    
    // write kernel result
    {
        *(__global float *) &mem_1986[(i_1680 * col_1138 + i_1681) * 4] =
            res_1800;
    }
}
__kernel void map_kernel_1949(int32_t y_1452, int32_t row_1389, __global
                              unsigned char *mem_1994, __global
                              unsigned char *mem_1996, __global
                              unsigned char *mem_1998, __global
                              unsigned char *mem_2000)
{
    const uint kernel_thread_index_1949 = get_global_id(0);
    
    if (kernel_thread_index_1949 >= row_1389)
        return;
    
    int32_t i_1950;
    
    // compute thread index
    {
        i_1950 = kernel_thread_index_1949;
    }
    // read kernel parameters
    { }
    
    char x_1952 = i_1950 == 0;
    int32_t i_1953 = i_1950 + 1;
    char x_1954 = i_1950 == y_1452;
    int32_t i_1955 = i_1950 - 1;
    
    // write kernel result
    {
        *(__global char *) &mem_1994[i_1950] = x_1954;
        *(__global char *) &mem_1996[i_1950] = x_1952;
        *(__global int32_t *) &mem_1998[i_1950 * 4] = i_1955;
        *(__global int32_t *) &mem_2000[i_1950 * 4] = i_1953;
    }
}
__kernel void map_kernel_1825(__global unsigned char *power_mem_1992, __global
                              unsigned char *mem_2000, float res_1412, __global
                              unsigned char *mem_1996, int32_t row_1389,
                              float res_1418, __global unsigned char *mem_1994,
                              int32_t col_1390, __global
                              unsigned char *temp_mem_2002, int32_t size_1434,
                              float x_1450, __global unsigned char *mem_1998,
                              int32_t y_1451, float res_1423, __global
                              unsigned char *mem_2005)
{
    const uint kernel_thread_index_1825 = get_global_id(0);
    
    if (kernel_thread_index_1825 >= row_1389 * col_1390)
        return;
    
    int32_t i_1826;
    int32_t i_1827;
    char x_1829;
    char x_1830;
    int32_t i_1831;
    int32_t i_1832;
    
    // compute thread index
    {
        i_1826 = squot32(kernel_thread_index_1825, col_1390);
        i_1827 = kernel_thread_index_1825 - squot32(kernel_thread_index_1825,
                                                    col_1390) * col_1390;
    }
    // read kernel parameters
    {
        x_1829 = *(__global char *) &mem_1994[i_1826];
        x_1830 = *(__global char *) &mem_1996[i_1826];
        i_1831 = *(__global int32_t *) &mem_1998[i_1826 * 4];
        i_1832 = *(__global int32_t *) &mem_2000[i_1826 * 4];
    }
    
    float x_1834 = *(__global float *) &power_mem_1992[(i_1826 * col_1390 +
                                                        i_1827) * 4];
    char y_1835 = i_1827 == 0;
    char cond_1836 = x_1830 && y_1835;
    int32_t i_1837 = i_1827 + 1;
    char y_1838 = i_1827 == y_1451;
    char cond_1839 = x_1830 && y_1838;
    int32_t i_1840 = i_1827 - 1;
    char cond_1841 = x_1829 && y_1838;
    char cond_1842 = x_1829 && y_1835;
    float y_1939;
    
    if (cond_1836) {
        float x_1843 = *(__global float *) &temp_mem_2002[(i_1826 * size_1434 +
                                                           i_1837) * 4];
        float y_1844 = *(__global float *) &temp_mem_2002[(i_1826 * size_1434 +
                                                           i_1827) * 4];
        float x_1845 = x_1843 - y_1844;
        float x_1846 = x_1845 / res_1412;
        float x_1847 = *(__global float *) &temp_mem_2002[(i_1832 * size_1434 +
                                                           i_1827) * 4];
        float x_1848 = x_1847 - y_1844;
        float y_1849 = x_1848 / res_1418;
        float res_1850 = x_1846 + y_1849;
        
        y_1939 = res_1850;
    } else {
        float res_1938;
        
        if (cond_1839) {
            float x_1851 = *(__global float *) &temp_mem_2002[(i_1826 *
                                                               size_1434 +
                                                               i_1840) * 4];
            float y_1852 = *(__global float *) &temp_mem_2002[(i_1826 *
                                                               size_1434 +
                                                               i_1827) * 4];
            float x_1853 = x_1851 - y_1852;
            float x_1854 = x_1853 / res_1412;
            float x_1855 = *(__global float *) &temp_mem_2002[(i_1832 *
                                                               size_1434 +
                                                               i_1827) * 4];
            float x_1856 = x_1855 - y_1852;
            float y_1857 = x_1856 / res_1418;
            float res_1858 = x_1854 + y_1857;
            
            res_1938 = res_1858;
        } else {
            float res_1937;
            
            if (cond_1841) {
                float x_1859 = *(__global float *) &temp_mem_2002[(i_1826 *
                                                                   size_1434 +
                                                                   i_1840) * 4];
                float y_1860 = *(__global float *) &temp_mem_2002[(i_1826 *
                                                                   size_1434 +
                                                                   i_1827) * 4];
                float x_1861 = x_1859 - y_1860;
                float x_1862 = x_1861 / res_1412;
                float x_1863 = *(__global float *) &temp_mem_2002[(i_1831 *
                                                                   size_1434 +
                                                                   i_1827) * 4];
                float x_1864 = x_1863 - y_1860;
                float y_1865 = x_1864 / res_1418;
                float res_1866 = x_1862 + y_1865;
                
                res_1937 = res_1866;
            } else {
                float res_1936;
                
                if (cond_1842) {
                    float x_1867 = *(__global float *) &temp_mem_2002[(i_1826 *
                                                                       size_1434 +
                                                                       i_1837) *
                                                                      4];
                    float y_1868 = *(__global float *) &temp_mem_2002[(i_1826 *
                                                                       size_1434 +
                                                                       i_1827) *
                                                                      4];
                    float x_1869 = x_1867 - y_1868;
                    float x_1870 = x_1869 / res_1412;
                    float x_1871 = *(__global float *) &temp_mem_2002[(i_1831 *
                                                                       size_1434 +
                                                                       i_1827) *
                                                                      4];
                    float x_1872 = x_1871 - y_1868;
                    float y_1873 = x_1872 / res_1418;
                    float res_1874 = x_1870 + y_1873;
                    
                    res_1936 = res_1874;
                } else {
                    float res_1935;
                    
                    if (x_1830) {
                        float x_1875 = *(__global
                                         float *) &temp_mem_2002[(i_1826 *
                                                                  size_1434 +
                                                                  i_1837) * 4];
                        float y_1876 = *(__global
                                         float *) &temp_mem_2002[(i_1826 *
                                                                  size_1434 +
                                                                  i_1840) * 4];
                        float x_1877 = x_1875 + y_1876;
                        float y_1878 = *(__global
                                         float *) &temp_mem_2002[(i_1826 *
                                                                  size_1434 +
                                                                  i_1827) * 4];
                        float y_1879 = 2.0F * y_1878;
                        float x_1880 = x_1877 - y_1879;
                        float x_1881 = x_1880 / res_1412;
                        float x_1882 = *(__global
                                         float *) &temp_mem_2002[(i_1832 *
                                                                  size_1434 +
                                                                  i_1827) * 4];
                        float x_1883 = x_1882 - y_1878;
                        float y_1884 = x_1883 / res_1418;
                        float res_1885 = x_1881 + y_1884;
                        
                        res_1935 = res_1885;
                    } else {
                        float res_1934;
                        
                        if (y_1838) {
                            float x_1886 = *(__global
                                             float *) &temp_mem_2002[(i_1826 *
                                                                      size_1434 +
                                                                      i_1840) *
                                                                     4];
                            float y_1887 = *(__global
                                             float *) &temp_mem_2002[(i_1826 *
                                                                      size_1434 +
                                                                      i_1827) *
                                                                     4];
                            float x_1888 = x_1886 - y_1887;
                            float x_1889 = x_1888 / res_1412;
                            float x_1890 = *(__global
                                             float *) &temp_mem_2002[(i_1832 *
                                                                      size_1434 +
                                                                      i_1827) *
                                                                     4];
                            float y_1891 = *(__global
                                             float *) &temp_mem_2002[(i_1831 *
                                                                      size_1434 +
                                                                      i_1827) *
                                                                     4];
                            float x_1892 = x_1890 + y_1891;
                            float y_1893 = 2.0F * y_1887;
                            float x_1894 = x_1892 - y_1893;
                            float y_1895 = x_1894 / res_1418;
                            float res_1896 = x_1889 + y_1895;
                            
                            res_1934 = res_1896;
                        } else {
                            float res_1933;
                            
                            if (x_1829) {
                                float x_1897 = *(__global
                                                 float *) &temp_mem_2002[(i_1826 *
                                                                          size_1434 +
                                                                          i_1837) *
                                                                         4];
                                float y_1898 = *(__global
                                                 float *) &temp_mem_2002[(i_1826 *
                                                                          size_1434 +
                                                                          i_1840) *
                                                                         4];
                                float x_1899 = x_1897 + y_1898;
                                float y_1900 = *(__global
                                                 float *) &temp_mem_2002[(i_1826 *
                                                                          size_1434 +
                                                                          i_1827) *
                                                                         4];
                                float y_1901 = 2.0F * y_1900;
                                float x_1902 = x_1899 - y_1901;
                                float x_1903 = x_1902 / res_1412;
                                float x_1904 = *(__global
                                                 float *) &temp_mem_2002[(i_1831 *
                                                                          size_1434 +
                                                                          i_1827) *
                                                                         4];
                                float x_1905 = x_1904 - y_1900;
                                float y_1906 = x_1905 / res_1418;
                                float res_1907 = x_1903 + y_1906;
                                
                                res_1933 = res_1907;
                            } else {
                                float res_1932;
                                
                                if (y_1835) {
                                    float x_1908 = *(__global
                                                     float *) &temp_mem_2002[(i_1826 *
                                                                              size_1434 +
                                                                              i_1837) *
                                                                             4];
                                    float y_1909 = *(__global
                                                     float *) &temp_mem_2002[(i_1826 *
                                                                              size_1434 +
                                                                              i_1827) *
                                                                             4];
                                    float x_1910 = x_1908 - y_1909;
                                    float x_1911 = x_1910 / res_1412;
                                    float x_1912 = *(__global
                                                     float *) &temp_mem_2002[(i_1832 *
                                                                              size_1434 +
                                                                              i_1827) *
                                                                             4];
                                    float y_1913 = *(__global
                                                     float *) &temp_mem_2002[(i_1831 *
                                                                              size_1434 +
                                                                              i_1827) *
                                                                             4];
                                    float x_1914 = x_1912 + y_1913;
                                    float y_1915 = 2.0F * y_1909;
                                    float x_1916 = x_1914 - y_1915;
                                    float y_1917 = x_1916 / res_1418;
                                    float res_1918 = x_1911 + y_1917;
                                    
                                    res_1932 = res_1918;
                                } else {
                                    float x_1919 = *(__global
                                                     float *) &temp_mem_2002[(i_1826 *
                                                                              size_1434 +
                                                                              i_1837) *
                                                                             4];
                                    float y_1920 = *(__global
                                                     float *) &temp_mem_2002[(i_1826 *
                                                                              size_1434 +
                                                                              i_1840) *
                                                                             4];
                                    float x_1921 = x_1919 + y_1920;
                                    float y_1922 = *(__global
                                                     float *) &temp_mem_2002[(i_1826 *
                                                                              size_1434 +
                                                                              i_1827) *
                                                                             4];
                                    float y_1923 = 2.0F * y_1922;
                                    float x_1924 = x_1921 - y_1923;
                                    float x_1925 = x_1924 / res_1412;
                                    float x_1926 = *(__global
                                                     float *) &temp_mem_2002[(i_1832 *
                                                                              size_1434 +
                                                                              i_1827) *
                                                                             4];
                                    float y_1927 = *(__global
                                                     float *) &temp_mem_2002[(i_1831 *
                                                                              size_1434 +
                                                                              i_1827) *
                                                                             4];
                                    float x_1928 = x_1926 + y_1927;
                                    float x_1929 = x_1928 - y_1923;
                                    float y_1930 = x_1929 / res_1418;
                                    float res_1931 = x_1925 + y_1930;
                                    
                                    res_1932 = res_1931;
                                }
                                res_1933 = res_1932;
                            }
                            res_1934 = res_1933;
                        }
                        res_1935 = res_1934;
                    }
                    res_1936 = res_1935;
                }
                res_1937 = res_1936;
            }
            res_1938 = res_1937;
        }
        y_1939 = res_1938;
    }
    
    float x_1940 = x_1834 + y_1939;
    float y_1941 = *(__global float *) &temp_mem_2002[(i_1826 * size_1434 +
                                                       i_1827) * 4];
    float x_1942 = 80.0F - y_1941;
    float y_1943 = x_1942 / res_1423;
    float y_1944 = x_1940 + y_1943;
    float res_1945 = x_1450 * y_1944;
    float res_1946 = y_1941 + res_1945;
    
    // write kernel result
    {
        *(__global float *) &mem_2005[(i_1826 * col_1390 + i_1827) * 4] =
            res_1946;
    }
}
"""
# Hacky parser/reader for values written in Futhark syntax.  Used for
# reading stdin when compiling standalone programs with the Python
# code generator.

lookahead_buffer = []

def reset_lookahead():
    global lookahead_buffer
    lookahead_buffer = []

def get_char(f):
    global lookahead_buffer
    if len(lookahead_buffer) == 0:
        return f.read(1)
    else:
        c = lookahead_buffer[0]
        lookahead_buffer = lookahead_buffer[1:]
        return c

def unget_char(f, c):
    global lookahead_buffer
    lookahead_buffer = [c] + lookahead_buffer

def peek_char(f):
    c = get_char(f)
    if c:
        unget_char(f, c)
    return c

def skip_spaces(f):
    c = get_char(f)
    while c != None:
        if c.isspace():
            c = get_char(f)
        elif c == '-':
          # May be line comment.
          if peek_char(f) == '-':
            # Yes, line comment. Skip to end of line.
            while (c != '\n' and c != None):
              c = get_char(f)
          else:
            break
        else:
          break
    if c:
        unget_char(f, c)

def parse_specific_char(f, expected):
    got = get_char(f)
    if got != expected:
        unget_char(f, got)
        raise ValueError
    return True

def parse_specific_string(f, s):
    for c in s:
        parse_specific_char(f, c)
    return True

def optional(p, *args):
    try:
        return p(*args)
    except ValueError:
        return None

def sepBy(p, sep, *args):
    elems = []
    x = optional(p, *args)
    if x != None:
        elems += [x]
        while optional(sep, *args) != None:
            x = p(*args)
            elems += [x]
    return elems

def parse_int(f):
    s = ''
    c = get_char(f)
    while c != None:
        if c.isdigit():
            s += c
            c = get_char(f)
        else:
            unget_char(f, c)
            break
    optional(read_int_trailer, f)
    return s

def parse_int_signed(f):
    s = ''
    c = get_char(f)

    if c == '-' and peek_char(f).isdigit():
      s = c + parse_int(f)
    else:
      unget_char(f, c)
      s = parse_int(f)

    return s

def read_int_trailer(f):
  parse_specific_char(f, 'i')
  while peek_char(f).isdigit():
    get_char(f)

def read_comma(f):
    skip_spaces(f)
    parse_specific_char(f, ',')
    return ','

def read_int(f):
    skip_spaces(f)
    return int(parse_int_signed(f))

def read_char(f):
    skip_spaces(f)
    parse_specific_char(f, '\'')
    c = get_char(f)
    parse_specific_char(f, '\'')
    return c

def read_double(f):
    skip_spaces(f)
    c = get_char(f)
    if (c == '-'):
      sign = '-'
    else:
      unget_char(f,c)
      sign = ''
    bef = optional(parse_int, f)
    if bef == None:
        bef = '0'
        parse_specific_char(f, '.')
        aft = parse_int(f)
    elif optional(parse_specific_char, f, '.'):
        aft = parse_int(f)
    else:
        aft = '0'
    if (optional(parse_specific_char, f, 'E') or
        optional(parse_specific_char, f, 'e')):
        expt = parse_int_signed(f)
    else:
        expt = '0'
    optional(read_float_trailer, f)
    return float(sign + bef + '.' + aft + 'E' + expt)

def read_float(f):
    return read_double(f)

def read_float_trailer(f):
  parse_specific_char(f, 'f')
  while peek_char(f).isdigit():
    get_char(f)

def read_bool(f):
    skip_spaces(f)
    if peek_char(f) == 'T':
        parse_specific_string(f, 'True')
        return True
    elif peek_char(f) == 'F':
        parse_specific_string(f, 'False')
        return False
    else:
        raise ValueError

def read_array_elems(f, elem_reader):
    skip_spaces(f)
    parse_specific_char(f, '[')
    xs = sepBy(elem_reader, read_comma, f)
    skip_spaces(f)
    parse_specific_char(f, ']')
    return xs

def read_array_helper(f, elem_reader, rank):
    def nested_row_reader(_):
        return read_array_helper(f, elem_reader, rank-1)
    if rank == 1:
        row_reader = elem_reader
    else:
        row_reader = nested_row_reader
    return read_array_elems(f, row_reader)

def expected_array_dims(l, rank):
  if rank > 1:
      n = len(l)
      if n == 0:
          elem = []
      else:
          elem = l[0]
      return [n] + expected_array_dims(elem, rank-1)
  else:
      return [len(l)]

def verify_array_dims(l, dims):
    if dims[0] != len(l):
        raise ValueError
    if len(dims) > 1:
        for x in l:
            verify_array_dims(x, dims[1:])

def read_double_signed(f):

    skip_spaces(f)
    c = get_char(f)

    if c == '-' and peek_char(f).isdigit():
      v = -1 * read_double(f)
    else:
      unget_char(f, c)
      v = read_double(f)

    return v

def read_array(f, elem_reader, rank, bt):
    elems = read_array_helper(f, elem_reader, rank)
    dims = expected_array_dims(elems, rank)
    verify_array_dims(elems, dims)
    return np.array(elems, dtype=bt)
# Scalar functions.

import numpy as np

def signed(x):
  if type(x) == np.uint8:
    return np.int8(x)
  elif type(x) == np.uint16:
    return np.int16(x)
  elif type(x) == np.uint32:
    return np.int32(x)
  else:
    return np.int64(x)

def unsigned(x):
  if type(x) == np.int8:
    return np.uint8(x)
  elif type(x) == np.int16:
    return np.uint16(x)
  elif type(x) == np.int32:
    return np.uint32(x)
  else:
    return np.uint64(x)

def shlN(x,y):
  return x << y

def ashrN(x,y):
  return x >> y

def sdivN(x,y):
  return x / y

def smodN(x,y):
  return x % y

def udivN(x,y):
  return signed(unsigned(x) / unsigned(y))

def umodN(x,y):
  return signed(unsigned(x) % unsigned(y))

def squotN(x,y):
  return np.int32(float(x) / float(y))

def sremN(x,y):
  return np.fmod(x,y)

def powN(x,y):
  return x ** y

def fpowN(x,y):
  return x ** y

def sleN(x,y):
  return x <= y

def sltN(x,y):
  return x < y

def uleN(x,y):
  return unsigned(x) <= unsigned(y)

def ultN(x,y):
  return unsigned(x) < unsigned(y)

def lshr8(x,y):
  return np.int8(np.uint8(x) >> np.uint8(y))

def lshr16(x,y):
  return np.int16(np.uint16(x) >> np.uint16(y))

def lshr32(x,y):
  return np.int32(np.uint32(x) >> np.uint32(y))

def lshr64(x,y):
  return np.int64(np.uint64(x) >> np.uint64(y))

def sext_T_i8(x):
  return np.int8(x)

def sext_T_i16(x):
  return np.int16(x)

def sext_T_i32(x):
  return np.int32(x)

def sext_T_i64(x):
  return np.int32(x)

def zext_i8_i8(x):
  return np.int8(np.uint8(x))

def zext_i8_i16(x):
  return np.int16(np.uint8(x))

def zext_i8_i32(x):
  return np.int32(np.uint8(x))

def zext_i8_i64(x):
  return np.int64(np.uint8(x))

def zext_i16_i8(x):
  return np.int8(np.uint16(x))

def zext_i16_i16(x):
  return np.int16(np.uint16(x))

def zext_i16_i32(x):
  return np.int32(np.uint16(x))

def zext_i16_i64(x):
  return np.int64(np.uint16(x))

def zext_i32_i8(x):
  return np.int8(np.uint32(x))

def zext_i32_i16(x):
  return np.int16(np.uint32(x))

def zext_i32_i32(x):
  return np.int32(np.uint32(x))

def zext_i32_i64(x):
  return np.int64(np.uint32(x))

def zext_i64_i8(x):
  return np.int8(np.uint64(x))

def zext_i64_i16(x):
  return np.int16(np.uint64(x))

def zext_i64_i32(x):
  return np.int32(np.uint64(x))

def zext_i64_i64(x):
  return np.int64(np.uint64(x))

shl8 = shl16 = shl32 = shl64 = shlN
ashr8 = ashr16 = ashr32 = ashr64 = ashrN
sdiv8 = sdiv16 = sdiv32 = sdiv64 = sdivN
smod8 = smod16 = smod32 = smod64 = smodN
udiv8 = udiv16 = udiv32 = udiv64 = udivN
umod8 = umod16 = umod32 = umod64 = umodN
squot8 = squot16 = squot32 = squot64 = squotN
srem8 = srem16 = srem32 = srem64 = sremN
pow8 = pow16 = pow32 = pow64 = powN
fpow32 = fpow64 = fpowN
sle8 = sle16 = sle32 = sle64 = sleN
slt8 = slt16 = slt32 = slt64 = sltN
ule8 = ule16 = ule32 = ule64 = uleN
ult8 = ult16 = ult32 = ult64 = ultN
sext_i8_i8 = sext_i16_i8 = sext_i32_i8 = sext_i64_i8 = sext_T_i8
sext_i8_i16 = sext_i16_i16 = sext_i32_i16 = sext_i64_i16 = sext_T_i16
sext_i8_i32 = sext_i16_i32 = sext_i32_i32 = sext_i64_i32 = sext_T_i32
sext_i8_i64 = sext_i16_i64 = sext_i32_i64 = sext_i64_i64 = sext_T_i64

def ssignum(x):
  return np.sign(x)

def usignum(x):
  if x < 0:
    return ssignum(-x)
  else:
    return ssignum(x)

def sitofp_T_f32(x):
  return np.float32(x)
sitofp_i8_f32 = sitofp_i16_f32 = sitofp_i32_f32 = sitofp_i64_f32 = sitofp_T_f32

def sitofp_T_f64(x):
  return np.float64(x)
sitofp_i8_f64 = sitofp_i16_f64 = sitofp_i32_f64 = sitofp_i64_f64 = sitofp_T_f64

def uitofp_T_f32(x):
  return np.float32(unsigned(x))
uitofp_i8_f32 = uitofp_i16_f32 = uitofp_i32_f32 = uitofp_i64_f32 = uitofp_T_f32

def uitofp_T_f64(x):
  return np.float64(unsigned(x))
uitofp_i8_f64 = uitofp_i16_f64 = uitofp_i32_f64 = uitofp_i64_f64 = uitofp_T_f64

def fptosi_T_i8(x):
  return np.int8(np.trunc(x))
fptosi_f32_i8 = fptosi_f64_i8 = fptosi_T_i8

def fptosi_T_i16(x):
  return np.int16(np.trunc(x))
fptosi_f32_i16 = fptosi_f64_i16 = fptosi_T_i16

def fptosi_T_i32(x):
  return np.int32(np.trunc(x))
fptosi_f32_i32 = fptosi_f64_i32 = fptosi_T_i32

def fptosi_T_i64(x):
  return np.int64(np.trunc(x))
fptosi_f32_i64 = fptosi_f64_i64 = fptosi_T_i64

def fptoui_T_i8(x):
  return np.uint8(np.trunc(x))
fptoui_f32_i8 = fptoui_f64_i8 = fptoui_T_i8

def fptoui_T_i16(x):
  return np.uint16(np.trunc(x))
fptoui_f32_i16 = fptoui_f64_i16 = fptoui_T_i16

def fptoui_T_i32(x):
  return np.uint32(np.trunc(x))
fptoui_f32_i32 = fptoui_f64_i32 = fptoui_T_i32

def fptoui_T_i64(x):
  return np.uint64(np.trunc(x))
fptoui_f32_i64 = fptoui_f64_i64 = fptoui_T_i64

def fpconv_f32_f64(x):
  return np.float64(x)

def fpconv_f64_f32(x):
  return np.float32(x)

def futhark_log64(x):
  return np.float64(np.log(x))

def futhark_sqrt64(x):
  return np.sqrt(x)

def futhark_exp64(x):
  return np.exp(x)

def futhark_cos64(x):
  return np.cos(x)

def futhark_sin64(x):
  return np.sin(x)

def futhark_atan2_64(x, y):
  return np.arctan2(x, y)

def futhark_isnan64(x):
  return np.isnan(x)

def futhark_isinf64(x):
  return np.isinf(x)

def futhark_log32(x):
  return np.float32(np.log(x))

def futhark_sqrt32(x):
  return np.float32(np.sqrt(x))

def futhark_exp32(x):
  return np.exp(x)

def futhark_cos32(x):
  return np.cos(x)

def futhark_sin32(x):
  return np.sin(x)

def futhark_atan2_32(x, y):
  return np.arctan2(x, y)

def futhark_isnan32(x):
  return np.isnan(x)

def futhark_isinf32(x):
  return np.isinf(x)
class hotspot:
  def __init__(self):
    self.ctx = cl.create_some_context(interactive=False)
    self.queue = cl.CommandQueue(self.ctx)
     # XXX: Assuming just a single device here.
    platform_name = self.ctx.get_info(cl.context_info.DEVICES)[0].platform.name
    device_type = self.ctx.get_info(cl.context_info.DEVICES)[0].type
    lockstep_width = 1
    if ((platform_name == "NVIDIA CUDA") and (device_type == cl.device_type.GPU)):
      lockstep_width = np.int32(32)
    if ((platform_name == "AMD Accelerated Parallel Processing") and (device_type == cl.device_type.GPU)):
      lockstep_width = np.int32(64)
    if (len(fut_opencl_src) >= 0):
      program = cl.Program(self.ctx, fut_opencl_src).build(["-DFUT_BLOCK_DIM={}".format(FUT_BLOCK_DIM), "-DLOCKSTEP_WIDTH={}".format(lockstep_width)])
    
    self.map_kernel_1651_var = program.map_kernel_1651
    self.fut_kernel_map_transpose_i8_var = program.fut_kernel_map_transpose_i8
    self.map_kernel_1803_var = program.map_kernel_1803
    self.map_kernel_1679_var = program.map_kernel_1679
    self.map_kernel_1949_var = program.map_kernel_1949
    self.map_kernel_1825_var = program.map_kernel_1825
  def futhark_render_frame(self, temp_mem_size_1957, temp_mem_1958, row_1120,
                           col_1121):
    nesting_size_1649 = (col_1121 * row_1120)
    x_1963 = (row_1120 * np.int32(3))
    bytes_1961 = (x_1963 * col_1121)
    mem_1964 = cl.Buffer(self.ctx, cl.mem_flags.READ_WRITE,
                         long(long(bytes_1961) if (bytes_1961 > np.int32(0)) else np.int32(1)))
    total_size_2012 = (nesting_size_1649 * np.int32(3))
    mem_1960 = cl.Buffer(self.ctx, cl.mem_flags.READ_WRITE,
                         long(long(total_size_2012) if (total_size_2012 > np.int32(0)) else np.int32(1)))
    group_size_2016 = np.int32(512)
    num_groups_2017 = squot32((((row_1120 * col_1121) + group_size_2016) - np.int32(1)),
                              group_size_2016)
    if ((np.int32(1) * (num_groups_2017 * group_size_2016)) != np.int32(0)):
      self.map_kernel_1651_var.set_args(np.int32(row_1120), mem_1960,
                                        np.int32(col_1121),
                                        np.int32(nesting_size_1649),
                                        temp_mem_1958, mem_1964)
      cl.enqueue_nd_range_kernel(self.queue, self.map_kernel_1651_var,
                                 (long((num_groups_2017 * group_size_2016)),),
                                 (long(group_size_2016),))
      if synchronous:
        self.queue.finish()
    x_1967 = (row_1120 * col_1121)
    bytes_1965 = (x_1967 * np.int32(3))
    mem_1968 = cl.Buffer(self.ctx, cl.mem_flags.READ_WRITE,
                         long(long(bytes_1965) if (bytes_1965 > np.int32(0)) else np.int32(1)))
    if ((((np.int32(1) * (col_1121 + srem32((np.int32(16) - srem32(col_1121,
                                                                   np.int32(16))),
                                            np.int32(16)))) * (np.int32(3) + srem32((np.int32(16) - srem32(np.int32(3),
                                                                                                           np.int32(16))),
                                                                                    np.int32(16)))) * row_1120) != np.int32(0)):
      self.fut_kernel_map_transpose_i8_var.set_args(mem_1968,
                                                    np.int32(np.int32(0)),
                                                    mem_1964,
                                                    np.int32(np.int32(0)),
                                                    np.int32(col_1121),
                                                    np.int32(np.int32(3)),
                                                    cl.LocalMemory(long((((np.int32(16) + np.int32(1)) * np.int32(16)) * np.int32(1)))))
      cl.enqueue_nd_range_kernel(self.queue,
                                 self.fut_kernel_map_transpose_i8_var,
                                 (long((col_1121 + srem32((np.int32(16) - srem32(col_1121,
                                                                                 np.int32(16))),
                                                          np.int32(16)))),
                                  long((np.int32(3) + srem32((np.int32(16) - srem32(np.int32(3),
                                                                                    np.int32(16))),
                                                             np.int32(16)))),
                                  long(row_1120)), (long(np.int32(16)),
                                                    long(np.int32(16)),
                                                    long(np.int32(1))))
      if synchronous:
        self.queue.finish()
    out_mem_2013 = mem_1968
    out_memsize_2014 = bytes_1965
    return (out_memsize_2014, out_mem_2013)
  def futhark_main(self, temp_mem_size_1970, power_mem_size_1972, temp_mem_1971,
                   power_mem_1973, row_1137, col_1138, num_iterations_1139):
    y_1148 = sitofp_i32_f32(row_1137)
    res_1149 = (np.float32(1.6e-2) / y_1148)
    y_1151 = sitofp_i32_f32(col_1138)
    res_1152 = (np.float32(1.6e-2) / y_1151)
    x_1158 = (np.float32(437.50003) * res_1152)
    res_1159 = (x_1158 * res_1149)
    y_1164 = (np.float32(0.1) * res_1149)
    res_1165 = (res_1152 / y_1164)
    y_1170 = (np.float32(0.1) * res_1152)
    res_1171 = (res_1149 / y_1170)
    x_1174 = (np.float32(100.0) * res_1149)
    y_1175 = (x_1174 * res_1152)
    res_1176 = (np.float32(5.0e-4) / y_1175)
    cond_1200 = (row_1137 == np.int32(0))
    if cond_1200:
      size_1201 = np.int32(0)
    else:
      size_1201 = col_1138
    x_1203 = (np.float32(1.4583334e-7) / res_1159)
    y_1204 = (col_1138 - np.int32(1))
    y_1205 = (row_1137 - np.int32(1))
    eq_x_y_1211 = (col_1138 == np.int32(0))
    p_and_eq_x_y_1212 = (cond_1200 and eq_x_y_1211)
    not_p_1213 = not(cond_1200)
    assert_arg_1214 = (p_and_eq_x_y_1212 or not_p_1213)
    assert assert_arg_1214, 'hotspot.fut:44:8-44:8'
    mem_1975 = cl.Buffer(self.ctx, cl.mem_flags.READ_WRITE,
                         long(long(row_1137) if (row_1137 > np.int32(0)) else np.int32(1)))
    mem_1977 = cl.Buffer(self.ctx, cl.mem_flags.READ_WRITE,
                         long(long(row_1137) if (row_1137 > np.int32(0)) else np.int32(1)))
    bytes_1978 = (np.int32(4) * row_1137)
    mem_1979 = cl.Buffer(self.ctx, cl.mem_flags.READ_WRITE,
                         long(long(bytes_1978) if (bytes_1978 > np.int32(0)) else np.int32(1)))
    mem_1981 = cl.Buffer(self.ctx, cl.mem_flags.READ_WRITE,
                         long(long(bytes_1978) if (bytes_1978 > np.int32(0)) else np.int32(1)))
    group_size_2022 = np.int32(512)
    num_groups_2023 = squot32(((row_1137 + group_size_2022) - np.int32(1)),
                              group_size_2022)
    if ((np.int32(1) * (num_groups_2023 * group_size_2022)) != np.int32(0)):
      self.map_kernel_1803_var.set_args(np.int32(row_1137), np.int32(y_1205),
                                        mem_1975, mem_1977, mem_1979, mem_1981)
      cl.enqueue_nd_range_kernel(self.queue, self.map_kernel_1803_var,
                                 (long((num_groups_2023 * group_size_2022)),),
                                 (long(group_size_2022),))
      if synchronous:
        self.queue.finish()
    nesting_size_1677 = (col_1138 * row_1137)
    bytes_1984 = (bytes_1978 * col_1138)
    double_buffer_mem_2008 = cl.Buffer(self.ctx, cl.mem_flags.READ_WRITE,
                                       long(long(bytes_1984) if (bytes_1984 > np.int32(0)) else np.int32(1)))
    mem_1986 = cl.Buffer(self.ctx, cl.mem_flags.READ_WRITE,
                         long(long(bytes_1984) if (bytes_1984 > np.int32(0)) else np.int32(1)))
    temp_mem_size_1982 = temp_mem_size_1970
    temp_mem_1983 = temp_mem_1971
    size_1187 = col_1138
    i_1189 = np.int32(0)
    one_2041 = np.int32(1)
    for counter_2040 in range(num_iterations_1139):
      group_size_2028 = np.int32(512)
      num_groups_2029 = squot32((((row_1137 * col_1138) + group_size_2028) - np.int32(1)),
                                group_size_2028)
      if ((np.int32(1) * (num_groups_2029 * group_size_2028)) != np.int32(0)):
        self.map_kernel_1679_var.set_args(np.int32(y_1204),
                                          np.float32(res_1176), mem_1981,
                                          np.float32(res_1165),
                                          np.int32(row_1137), mem_1977,
                                          power_mem_1973, np.int32(col_1138),
                                          np.float32(res_1171), mem_1975,
                                          temp_mem_1983, np.int32(size_1187),
                                          np.float32(x_1203), mem_1979,
                                          mem_1986)
        cl.enqueue_nd_range_kernel(self.queue, self.map_kernel_1679_var,
                                   (long((num_groups_2029 * group_size_2028)),),
                                   (long(group_size_2028),))
        if synchronous:
          self.queue.finish()
      if (((row_1137 * size_1201) * np.int32(4)) != np.int32(0)):
        cl.enqueue_copy(self.queue, double_buffer_mem_2008, mem_1986,
                        dest_offset=long(np.int32(0)),
                        src_offset=long(np.int32(0)),
                        byte_count=long(((row_1137 * size_1201) * np.int32(4))))
      if synchronous:
        self.queue.finish()
      temp_mem_size_tmp_2024 = bytes_1984
      temp_mem_tmp_2025 = double_buffer_mem_2008
      size_tmp_2026 = size_1201
      temp_mem_size_1982 = temp_mem_size_tmp_2024
      temp_mem_1983 = temp_mem_tmp_2025
      size_1187 = size_tmp_2026
      i_1189 += one_2041
    temp_mem_1988 = temp_mem_1983
    size_1381 = size_1187
    temp_mem_size_1987 = temp_mem_size_1982
    assert_arg_1385 = (col_1138 == size_1381)
    assert assert_arg_1385, 'hotspot.fut:87:23-87:23'
    out_mem_2018 = temp_mem_1988
    out_arrsize_2020 = row_1137
    out_arrsize_2021 = col_1138
    out_memsize_2019 = temp_mem_size_1987
    return (out_memsize_2019, out_mem_2018, out_arrsize_2020, out_arrsize_2021)
  def futhark_compute_tran_temp(self, temp_mem_size_1989, power_mem_size_1991,
                                temp_mem_1990, power_mem_1992, row_1389,
                                col_1390, num_iterations_1391):
    y_1395 = sitofp_i32_f32(row_1389)
    res_1396 = (np.float32(1.6e-2) / y_1395)
    y_1398 = sitofp_i32_f32(col_1390)
    res_1399 = (np.float32(1.6e-2) / y_1398)
    x_1405 = (np.float32(437.50003) * res_1399)
    res_1406 = (x_1405 * res_1396)
    y_1411 = (np.float32(0.1) * res_1396)
    res_1412 = (res_1399 / y_1411)
    y_1417 = (np.float32(0.1) * res_1399)
    res_1418 = (res_1396 / y_1417)
    x_1421 = (np.float32(100.0) * res_1396)
    y_1422 = (x_1421 * res_1399)
    res_1423 = (np.float32(5.0e-4) / y_1422)
    cond_1447 = (row_1389 == np.int32(0))
    if cond_1447:
      size_1448 = np.int32(0)
    else:
      size_1448 = col_1390
    x_1450 = (np.float32(1.4583334e-7) / res_1406)
    y_1451 = (col_1390 - np.int32(1))
    y_1452 = (row_1389 - np.int32(1))
    eq_x_y_1458 = (col_1390 == np.int32(0))
    p_and_eq_x_y_1459 = (cond_1447 and eq_x_y_1458)
    not_p_1460 = not(cond_1447)
    assert_arg_1461 = (p_and_eq_x_y_1459 or not_p_1460)
    assert assert_arg_1461, 'hotspot.fut:44:8-44:8'
    mem_1994 = cl.Buffer(self.ctx, cl.mem_flags.READ_WRITE,
                         long(long(row_1389) if (row_1389 > np.int32(0)) else np.int32(1)))
    mem_1996 = cl.Buffer(self.ctx, cl.mem_flags.READ_WRITE,
                         long(long(row_1389) if (row_1389 > np.int32(0)) else np.int32(1)))
    bytes_1997 = (np.int32(4) * row_1389)
    mem_1998 = cl.Buffer(self.ctx, cl.mem_flags.READ_WRITE,
                         long(long(bytes_1997) if (bytes_1997 > np.int32(0)) else np.int32(1)))
    mem_2000 = cl.Buffer(self.ctx, cl.mem_flags.READ_WRITE,
                         long(long(bytes_1997) if (bytes_1997 > np.int32(0)) else np.int32(1)))
    group_size_2032 = np.int32(512)
    num_groups_2033 = squot32(((row_1389 + group_size_2032) - np.int32(1)),
                              group_size_2032)
    if ((np.int32(1) * (num_groups_2033 * group_size_2032)) != np.int32(0)):
      self.map_kernel_1949_var.set_args(np.int32(y_1452), np.int32(row_1389),
                                        mem_1994, mem_1996, mem_1998, mem_2000)
      cl.enqueue_nd_range_kernel(self.queue, self.map_kernel_1949_var,
                                 (long((num_groups_2033 * group_size_2032)),),
                                 (long(group_size_2032),))
      if synchronous:
        self.queue.finish()
    nesting_size_1823 = (col_1390 * row_1389)
    bytes_2003 = (bytes_1997 * col_1390)
    double_buffer_mem_2010 = cl.Buffer(self.ctx, cl.mem_flags.READ_WRITE,
                                       long(long(bytes_2003) if (bytes_2003 > np.int32(0)) else np.int32(1)))
    mem_2005 = cl.Buffer(self.ctx, cl.mem_flags.READ_WRITE,
                         long(long(bytes_2003) if (bytes_2003 > np.int32(0)) else np.int32(1)))
    temp_mem_size_2001 = temp_mem_size_1989
    temp_mem_2002 = temp_mem_1990
    size_1434 = col_1390
    i_1436 = np.int32(0)
    one_2043 = np.int32(1)
    for counter_2042 in range(num_iterations_1391):
      group_size_2038 = np.int32(512)
      num_groups_2039 = squot32((((row_1389 * col_1390) + group_size_2038) - np.int32(1)),
                                group_size_2038)
      if ((np.int32(1) * (num_groups_2039 * group_size_2038)) != np.int32(0)):
        self.map_kernel_1825_var.set_args(power_mem_1992, mem_2000,
                                          np.float32(res_1412), mem_1996,
                                          np.int32(row_1389),
                                          np.float32(res_1418), mem_1994,
                                          np.int32(col_1390), temp_mem_2002,
                                          np.int32(size_1434),
                                          np.float32(x_1450), mem_1998,
                                          np.int32(y_1451),
                                          np.float32(res_1423), mem_2005)
        cl.enqueue_nd_range_kernel(self.queue, self.map_kernel_1825_var,
                                   (long((num_groups_2039 * group_size_2038)),),
                                   (long(group_size_2038),))
        if synchronous:
          self.queue.finish()
      if (((row_1389 * size_1448) * np.int32(4)) != np.int32(0)):
        cl.enqueue_copy(self.queue, double_buffer_mem_2010, mem_2005,
                        dest_offset=long(np.int32(0)),
                        src_offset=long(np.int32(0)),
                        byte_count=long(((row_1389 * size_1448) * np.int32(4))))
      if synchronous:
        self.queue.finish()
      temp_mem_size_tmp_2034 = bytes_2003
      temp_mem_tmp_2035 = double_buffer_mem_2010
      size_tmp_2036 = size_1448
      temp_mem_size_2001 = temp_mem_size_tmp_2034
      temp_mem_2002 = temp_mem_tmp_2035
      size_1434 = size_tmp_2036
      i_1436 += one_2043
    temp_mem_2007 = temp_mem_2002
    size_1628 = size_1434
    temp_mem_size_2006 = temp_mem_size_2001
    assert_arg_1632 = (col_1390 == size_1628)
    assert assert_arg_1632, 'hotspot.fut:87:23-87:23'
    out_mem_2030 = temp_mem_2007
    out_memsize_2031 = temp_mem_size_2006
    return (out_memsize_2031, out_mem_2030)
  def render_frame(self, temp_mem_1958_ext):
    row_1120 = np.int32(temp_mem_1958_ext.shape[np.int32(0)])
    col_1121 = np.int32(temp_mem_1958_ext.shape[np.int32(1)])
    temp_mem_size_1957 = np.int32(temp_mem_1958_ext.nbytes)
    temp_mem_device_2044 = cl.Buffer(self.ctx, cl.mem_flags.READ_WRITE,
                                     long(long(temp_mem_size_1957) if (temp_mem_size_1957 > np.int32(0)) else np.int32(1)))
    temp_mem_1958 = temp_mem_1958_ext
    if (temp_mem_1958_ext.nbytes != np.int32(0)):
      cl.enqueue_copy(self.queue, temp_mem_device_2044,
                      temp_mem_1958[np.int32(0):(np.int32(0) + (temp_mem_1958_ext.nbytes // 4))],
                      device_offset=long(np.int32(0)), is_blocking=synchronous)
    temp_mem_1958 = temp_mem_device_2044
    (out_memsize_2014,
     out_mem_2013) = self.futhark_render_frame(temp_mem_size_1957,
                                               temp_mem_1958, row_1120,
                                               col_1121)
    out_mem_device_2045 = np.empty((row_1120, col_1121, np.int32(3)),
                                   dtype=ct.c_int8)
    if (out_memsize_2014 != np.int32(0)):
      cl.enqueue_copy(self.queue,
                      out_mem_device_2045[np.int32(0):(np.int32(0) + (out_memsize_2014 // 1))],
                      out_mem_2013, device_offset=long(np.int32(0)),
                      is_blocking=synchronous)
    out_mem_2013 = out_mem_device_2045
    return out_mem_2013
  def main(self, num_iterations_1139_ext, temp_mem_1971_ext,
           power_mem_1973_ext):
    num_iterations_1139 = np.int32(num_iterations_1139_ext)
    row_1137 = np.int32(temp_mem_1971_ext.shape[np.int32(0)])
    col_1138 = np.int32(temp_mem_1971_ext.shape[np.int32(1)])
    temp_mem_size_1970 = np.int32(temp_mem_1971_ext.nbytes)
    temp_mem_device_2046 = cl.Buffer(self.ctx, cl.mem_flags.READ_WRITE,
                                     long(long(temp_mem_size_1970) if (temp_mem_size_1970 > np.int32(0)) else np.int32(1)))
    temp_mem_1971 = temp_mem_1971_ext
    if (temp_mem_1971_ext.nbytes != np.int32(0)):
      cl.enqueue_copy(self.queue, temp_mem_device_2046,
                      temp_mem_1971[np.int32(0):(np.int32(0) + (temp_mem_1971_ext.nbytes // 4))],
                      device_offset=long(np.int32(0)), is_blocking=synchronous)
    temp_mem_1971 = temp_mem_device_2046
    row_1137 = np.int32(power_mem_1973_ext.shape[np.int32(0)])
    col_1138 = np.int32(power_mem_1973_ext.shape[np.int32(1)])
    power_mem_size_1972 = np.int32(power_mem_1973_ext.nbytes)
    power_mem_device_2047 = cl.Buffer(self.ctx, cl.mem_flags.READ_WRITE,
                                      long(long(power_mem_size_1972) if (power_mem_size_1972 > np.int32(0)) else np.int32(1)))
    power_mem_1973 = power_mem_1973_ext
    if (power_mem_1973_ext.nbytes != np.int32(0)):
      cl.enqueue_copy(self.queue, power_mem_device_2047,
                      power_mem_1973[np.int32(0):(np.int32(0) + (power_mem_1973_ext.nbytes // 4))],
                      device_offset=long(np.int32(0)), is_blocking=synchronous)
    power_mem_1973 = power_mem_device_2047
    (out_memsize_2019, out_mem_2018, out_arrsize_2020,
     out_arrsize_2021) = self.futhark_main(temp_mem_size_1970,
                                           power_mem_size_1972, temp_mem_1971,
                                           power_mem_1973, row_1137, col_1138,
                                           num_iterations_1139)
    out_mem_device_2048 = np.empty((out_arrsize_2020, out_arrsize_2021),
                                   dtype=ct.c_float)
    if (out_memsize_2019 != np.int32(0)):
      cl.enqueue_copy(self.queue,
                      out_mem_device_2048[np.int32(0):(np.int32(0) + (out_memsize_2019 // 4))],
                      out_mem_2018, device_offset=long(np.int32(0)),
                      is_blocking=synchronous)
    out_mem_2018 = out_mem_device_2048
    return out_mem_2018
  def compute_tran_temp(self, num_iterations_1391_ext, temp_mem_1990_ext,
                        power_mem_1992_ext):
    num_iterations_1391 = np.int32(num_iterations_1391_ext)
    row_1389 = np.int32(temp_mem_1990_ext.shape[np.int32(0)])
    col_1390 = np.int32(temp_mem_1990_ext.shape[np.int32(1)])
    temp_mem_size_1989 = np.int32(temp_mem_1990_ext.nbytes)
    temp_mem_device_2049 = cl.Buffer(self.ctx, cl.mem_flags.READ_WRITE,
                                     long(long(temp_mem_size_1989) if (temp_mem_size_1989 > np.int32(0)) else np.int32(1)))
    temp_mem_1990 = temp_mem_1990_ext
    if (temp_mem_1990_ext.nbytes != np.int32(0)):
      cl.enqueue_copy(self.queue, temp_mem_device_2049,
                      temp_mem_1990[np.int32(0):(np.int32(0) + (temp_mem_1990_ext.nbytes // 4))],
                      device_offset=long(np.int32(0)), is_blocking=synchronous)
    temp_mem_1990 = temp_mem_device_2049
    row_1389 = np.int32(power_mem_1992_ext.shape[np.int32(0)])
    col_1390 = np.int32(power_mem_1992_ext.shape[np.int32(1)])
    power_mem_size_1991 = np.int32(power_mem_1992_ext.nbytes)
    power_mem_device_2050 = cl.Buffer(self.ctx, cl.mem_flags.READ_WRITE,
                                      long(long(power_mem_size_1991) if (power_mem_size_1991 > np.int32(0)) else np.int32(1)))
    power_mem_1992 = power_mem_1992_ext
    if (power_mem_1992_ext.nbytes != np.int32(0)):
      cl.enqueue_copy(self.queue, power_mem_device_2050,
                      power_mem_1992[np.int32(0):(np.int32(0) + (power_mem_1992_ext.nbytes // 4))],
                      device_offset=long(np.int32(0)), is_blocking=synchronous)
    power_mem_1992 = power_mem_device_2050
    (out_memsize_2031,
     out_mem_2030) = self.futhark_compute_tran_temp(temp_mem_size_1989,
                                                    power_mem_size_1991,
                                                    temp_mem_1990,
                                                    power_mem_1992, row_1389,
                                                    col_1390,
                                                    num_iterations_1391)
    out_mem_device_2051 = np.empty((row_1389, col_1390), dtype=ct.c_float)
    if (out_memsize_2031 != np.int32(0)):
      cl.enqueue_copy(self.queue,
                      out_mem_device_2051[np.int32(0):(np.int32(0) + (out_memsize_2031 // 4))],
                      out_mem_2030, device_offset=long(np.int32(0)),
                      is_blocking=synchronous)
    out_mem_2030 = out_mem_device_2051
    return out_mem_2030