import sys
import numpy as np
import ctypes as ct
import pyopencl as cl
import pyopencl.array
import time
import argparse
FUT_BLOCK_DIM = "16"
cl_group_size = np.int32(512)
synchronous = False
fut_opencl_src = """typedef char int8_t;
typedef short int16_t;
typedef int int32_t;
typedef long int64_t;
typedef uchar uint8_t;
typedef ushort uint16_t;
typedef uint uint32_t;
typedef ulong uint64_t;
static inline int8_t add8(int8_t x, int8_t y)
{
    return x + y;
}
static inline int16_t add16(int16_t x, int16_t y)
{
    return x + y;
}
static inline int32_t add32(int32_t x, int32_t y)
{
    return x + y;
}
static inline int64_t add64(int64_t x, int64_t y)
{
    return x + y;
}
static inline int8_t sub8(int8_t x, int8_t y)
{
    return x - y;
}
static inline int16_t sub16(int16_t x, int16_t y)
{
    return x - y;
}
static inline int32_t sub32(int32_t x, int32_t y)
{
    return x - y;
}
static inline int64_t sub64(int64_t x, int64_t y)
{
    return x - y;
}
static inline int8_t mul8(int8_t x, int8_t y)
{
    return x * y;
}
static inline int16_t mul16(int16_t x, int16_t y)
{
    return x * y;
}
static inline int32_t mul32(int32_t x, int32_t y)
{
    return x * y;
}
static inline int64_t mul64(int64_t x, int64_t y)
{
    return x * y;
}
static inline uint8_t udiv8(uint8_t x, uint8_t y)
{
    return x / y;
}
static inline uint16_t udiv16(uint16_t x, uint16_t y)
{
    return x / y;
}
static inline uint32_t udiv32(uint32_t x, uint32_t y)
{
    return x / y;
}
static inline uint64_t udiv64(uint64_t x, uint64_t y)
{
    return x / y;
}
static inline uint8_t umod8(uint8_t x, uint8_t y)
{
    return x % y;
}
static inline uint16_t umod16(uint16_t x, uint16_t y)
{
    return x % y;
}
static inline uint32_t umod32(uint32_t x, uint32_t y)
{
    return x % y;
}
static inline uint64_t umod64(uint64_t x, uint64_t y)
{
    return x % y;
}
static inline int8_t sdiv8(int8_t x, int8_t y)
{
    int8_t q = x / y;
    int8_t r = x % y;
    
    return q - ((r != 0 && r < 0 != y < 0) ? 1 : 0);
}
static inline int16_t sdiv16(int16_t x, int16_t y)
{
    int16_t q = x / y;
    int16_t r = x % y;
    
    return q - ((r != 0 && r < 0 != y < 0) ? 1 : 0);
}
static inline int32_t sdiv32(int32_t x, int32_t y)
{
    int32_t q = x / y;
    int32_t r = x % y;
    
    return q - ((r != 0 && r < 0 != y < 0) ? 1 : 0);
}
static inline int64_t sdiv64(int64_t x, int64_t y)
{
    int64_t q = x / y;
    int64_t r = x % y;
    
    return q - ((r != 0 && r < 0 != y < 0) ? 1 : 0);
}
static inline int8_t smod8(int8_t x, int8_t y)
{
    int8_t r = x % y;
    
    return r + (r == 0 || (x > 0 && y > 0) || (x < 0 && y < 0) ? 0 : y);
}
static inline int16_t smod16(int16_t x, int16_t y)
{
    int16_t r = x % y;
    
    return r + (r == 0 || (x > 0 && y > 0) || (x < 0 && y < 0) ? 0 : y);
}
static inline int32_t smod32(int32_t x, int32_t y)
{
    int32_t r = x % y;
    
    return r + (r == 0 || (x > 0 && y > 0) || (x < 0 && y < 0) ? 0 : y);
}
static inline int64_t smod64(int64_t x, int64_t y)
{
    int64_t r = x % y;
    
    return r + (r == 0 || (x > 0 && y > 0) || (x < 0 && y < 0) ? 0 : y);
}
static inline int8_t squot8(int8_t x, int8_t y)
{
    return x / y;
}
static inline int16_t squot16(int16_t x, int16_t y)
{
    return x / y;
}
static inline int32_t squot32(int32_t x, int32_t y)
{
    return x / y;
}
static inline int64_t squot64(int64_t x, int64_t y)
{
    return x / y;
}
static inline int8_t srem8(int8_t x, int8_t y)
{
    return x % y;
}
static inline int16_t srem16(int16_t x, int16_t y)
{
    return x % y;
}
static inline int32_t srem32(int32_t x, int32_t y)
{
    return x % y;
}
static inline int64_t srem64(int64_t x, int64_t y)
{
    return x % y;
}
static inline uint8_t shl8(uint8_t x, uint8_t y)
{
    return x << y;
}
static inline uint16_t shl16(uint16_t x, uint16_t y)
{
    return x << y;
}
static inline uint32_t shl32(uint32_t x, uint32_t y)
{
    return x << y;
}
static inline uint64_t shl64(uint64_t x, uint64_t y)
{
    return x << y;
}
static inline uint8_t lshr8(uint8_t x, uint8_t y)
{
    return x >> y;
}
static inline uint16_t lshr16(uint16_t x, uint16_t y)
{
    return x >> y;
}
static inline uint32_t lshr32(uint32_t x, uint32_t y)
{
    return x >> y;
}
static inline uint64_t lshr64(uint64_t x, uint64_t y)
{
    return x >> y;
}
static inline int8_t ashr8(int8_t x, int8_t y)
{
    return x >> y;
}
static inline int16_t ashr16(int16_t x, int16_t y)
{
    return x >> y;
}
static inline int32_t ashr32(int32_t x, int32_t y)
{
    return x >> y;
}
static inline int64_t ashr64(int64_t x, int64_t y)
{
    return x >> y;
}
static inline uint8_t and8(uint8_t x, uint8_t y)
{
    return x & y;
}
static inline uint16_t and16(uint16_t x, uint16_t y)
{
    return x & y;
}
static inline uint32_t and32(uint32_t x, uint32_t y)
{
    return x & y;
}
static inline uint64_t and64(uint64_t x, uint64_t y)
{
    return x & y;
}
static inline uint8_t or8(uint8_t x, uint8_t y)
{
    return x | y;
}
static inline uint16_t or16(uint16_t x, uint16_t y)
{
    return x | y;
}
static inline uint32_t or32(uint32_t x, uint32_t y)
{
    return x | y;
}
static inline uint64_t or64(uint64_t x, uint64_t y)
{
    return x | y;
}
static inline uint8_t xor8(uint8_t x, uint8_t y)
{
    return x ^ y;
}
static inline uint16_t xor16(uint16_t x, uint16_t y)
{
    return x ^ y;
}
static inline uint32_t xor32(uint32_t x, uint32_t y)
{
    return x ^ y;
}
static inline uint64_t xor64(uint64_t x, uint64_t y)
{
    return x ^ y;
}
static inline char ult8(uint8_t x, uint8_t y)
{
    return x < y;
}
static inline char ult16(uint16_t x, uint16_t y)
{
    return x < y;
}
static inline char ult32(uint32_t x, uint32_t y)
{
    return x < y;
}
static inline char ult64(uint64_t x, uint64_t y)
{
    return x < y;
}
static inline char ule8(uint8_t x, uint8_t y)
{
    return x <= y;
}
static inline char ule16(uint16_t x, uint16_t y)
{
    return x <= y;
}
static inline char ule32(uint32_t x, uint32_t y)
{
    return x <= y;
}
static inline char ule64(uint64_t x, uint64_t y)
{
    return x <= y;
}
static inline char slt8(int8_t x, int8_t y)
{
    return x < y;
}
static inline char slt16(int16_t x, int16_t y)
{
    return x < y;
}
static inline char slt32(int32_t x, int32_t y)
{
    return x < y;
}
static inline char slt64(int64_t x, int64_t y)
{
    return x < y;
}
static inline char sle8(int8_t x, int8_t y)
{
    return x <= y;
}
static inline char sle16(int16_t x, int16_t y)
{
    return x <= y;
}
static inline char sle32(int32_t x, int32_t y)
{
    return x <= y;
}
static inline char sle64(int64_t x, int64_t y)
{
    return x <= y;
}
static inline int8_t pow8(int8_t x, int8_t y)
{
    int8_t res = 1, rem = y;
    
    while (rem != 0) {
        if (rem & 1)
            res *= x;
        rem >>= 1;
        x *= x;
    }
    return res;
}
static inline int16_t pow16(int16_t x, int16_t y)
{
    int16_t res = 1, rem = y;
    
    while (rem != 0) {
        if (rem & 1)
            res *= x;
        rem >>= 1;
        x *= x;
    }
    return res;
}
static inline int32_t pow32(int32_t x, int32_t y)
{
    int32_t res = 1, rem = y;
    
    while (rem != 0) {
        if (rem & 1)
            res *= x;
        rem >>= 1;
        x *= x;
    }
    return res;
}
static inline int64_t pow64(int64_t x, int64_t y)
{
    int64_t res = 1, rem = y;
    
    while (rem != 0) {
        if (rem & 1)
            res *= x;
        rem >>= 1;
        x *= x;
    }
    return res;
}
static inline int8_t sext_i8_i8(int8_t x)
{
    return x;
}
static inline int16_t sext_i8_i16(int8_t x)
{
    return x;
}
static inline int32_t sext_i8_i32(int8_t x)
{
    return x;
}
static inline int64_t sext_i8_i64(int8_t x)
{
    return x;
}
static inline int8_t sext_i16_i8(int16_t x)
{
    return x;
}
static inline int16_t sext_i16_i16(int16_t x)
{
    return x;
}
static inline int32_t sext_i16_i32(int16_t x)
{
    return x;
}
static inline int64_t sext_i16_i64(int16_t x)
{
    return x;
}
static inline int8_t sext_i32_i8(int32_t x)
{
    return x;
}
static inline int16_t sext_i32_i16(int32_t x)
{
    return x;
}
static inline int32_t sext_i32_i32(int32_t x)
{
    return x;
}
static inline int64_t sext_i32_i64(int32_t x)
{
    return x;
}
static inline int8_t sext_i64_i8(int64_t x)
{
    return x;
}
static inline int16_t sext_i64_i16(int64_t x)
{
    return x;
}
static inline int32_t sext_i64_i32(int64_t x)
{
    return x;
}
static inline int64_t sext_i64_i64(int64_t x)
{
    return x;
}
static inline uint8_t zext_i8_i8(uint8_t x)
{
    return x;
}
static inline uint16_t zext_i8_i16(uint8_t x)
{
    return x;
}
static inline uint32_t zext_i8_i32(uint8_t x)
{
    return x;
}
static inline uint64_t zext_i8_i64(uint8_t x)
{
    return x;
}
static inline uint8_t zext_i16_i8(uint16_t x)
{
    return x;
}
static inline uint16_t zext_i16_i16(uint16_t x)
{
    return x;
}
static inline uint32_t zext_i16_i32(uint16_t x)
{
    return x;
}
static inline uint64_t zext_i16_i64(uint16_t x)
{
    return x;
}
static inline uint8_t zext_i32_i8(uint32_t x)
{
    return x;
}
static inline uint16_t zext_i32_i16(uint32_t x)
{
    return x;
}
static inline uint32_t zext_i32_i32(uint32_t x)
{
    return x;
}
static inline uint64_t zext_i32_i64(uint32_t x)
{
    return x;
}
static inline uint8_t zext_i64_i8(uint64_t x)
{
    return x;
}
static inline uint16_t zext_i64_i16(uint64_t x)
{
    return x;
}
static inline uint32_t zext_i64_i32(uint64_t x)
{
    return x;
}
static inline uint64_t zext_i64_i64(uint64_t x)
{
    return x;
}
static inline float fdiv32(float x, float y)
{
    return x / y;
}
static inline float fadd32(float x, float y)
{
    return x + y;
}
static inline float fsub32(float x, float y)
{
    return x - y;
}
static inline float fmul32(float x, float y)
{
    return x * y;
}
static inline float fpow32(float x, float y)
{
    return pow(x, y);
}
static inline char cmplt32(float x, float y)
{
    return x < y;
}
static inline char cmple32(float x, float y)
{
    return x <= y;
}
static inline float sitofp_i8_f32(int8_t x)
{
    return x;
}
static inline float sitofp_i16_f32(int16_t x)
{
    return x;
}
static inline float sitofp_i32_f32(int32_t x)
{
    return x;
}
static inline float sitofp_i64_f32(int64_t x)
{
    return x;
}
static inline float uitofp_i8_f32(uint8_t x)
{
    return x;
}
static inline float uitofp_i16_f32(uint16_t x)
{
    return x;
}
static inline float uitofp_i32_f32(uint32_t x)
{
    return x;
}
static inline float uitofp_i64_f32(uint64_t x)
{
    return x;
}
static inline int8_t fptosi_f32_i8(float x)
{
    return x;
}
static inline int16_t fptosi_f32_i16(float x)
{
    return x;
}
static inline int32_t fptosi_f32_i32(float x)
{
    return x;
}
static inline int64_t fptosi_f32_i64(float x)
{
    return x;
}
static inline uint8_t fptoui_f32_i8(float x)
{
    return x;
}
static inline uint16_t fptoui_f32_i16(float x)
{
    return x;
}
static inline uint32_t fptoui_f32_i32(float x)
{
    return x;
}
static inline uint64_t fptoui_f32_i64(float x)
{
    return x;
}
__kernel void map_kernel_1649(__global unsigned char *temp_mem_1956,
                              int32_t row_1118, __global
                              unsigned char *mem_1958,
                              int32_t nesting_size_1647, int32_t col_1119,
                              __global unsigned char *mem_1962)
{
    const uint kernel_thread_index_1649 = get_global_id(0);
    
    if (kernel_thread_index_1649 >= row_1118 * col_1119)
        return;
    
    int32_t i_1650;
    int32_t i_1651;
    float c_1652;
    
    // compute thread index
    {
        i_1650 = squot32(kernel_thread_index_1649, col_1119);
        i_1651 = kernel_thread_index_1649 - squot32(kernel_thread_index_1649,
                                                    col_1119) * col_1119;
    }
    // read kernel parameters
    {
        c_1652 = *(__global float *) &temp_mem_1956[(i_1650 * col_1119 +
                                                     i_1651) * 4];
    }
    
    char cond_1653 = c_1652 < 270.0F;
    char cond_1654 = 360.0F < c_1652;
    float res_1655;
    
    if (cond_1654) {
        res_1655 = 360.0F;
    } else {
        res_1655 = c_1652;
    }
    
    float res_1656;
    
    if (cond_1653) {
        res_1656 = 270.0F;
    } else {
        res_1656 = res_1655;
    }
    
    float x_1657 = res_1656 - 270.0F;
    float x_1658 = x_1657 / 90.0F;
    float res_1659 = x_1658 * 256.0F;
    int8_t arr_elem_1660 = fptosi_f32_i8(res_1659);
    
    *(__global int8_t *) &mem_1958[kernel_thread_index_1649] = arr_elem_1660;
    *(__global int8_t *) &mem_1958[nesting_size_1647 +
                                   kernel_thread_index_1649] = 0;
    *(__global int8_t *) &mem_1958[2 * nesting_size_1647 +
                                   kernel_thread_index_1649] = arr_elem_1660;
    // write kernel result
    {
        for (int i_2013 = 0; i_2013 < 3; i_2013++) {
            *(__global int8_t *) &mem_1962[3 * (col_1119 * i_1650) + (col_1119 *
                                                                      i_2013 +
                                                                      i_1651)] =
                *(__global int8_t *) &mem_1958[nesting_size_1647 * i_2013 +
                                               kernel_thread_index_1649];
        }
    }
}
__kernel void fut_kernel_map_transpose_i8(__global int8_t *odata,
                                          uint odata_offset, __global
                                          int8_t *idata, uint idata_offset,
                                          uint width, uint height,
                                          uint total_size, __local
                                          int8_t *block)
{
    uint x_index;
    uint y_index;
    uint our_array_offset;
    
    // Adjust the input and output arrays with the basic offset.
    odata += odata_offset / sizeof(int8_t);
    idata += idata_offset / sizeof(int8_t);
    // Adjust the input and output arrays for the third dimension.
    our_array_offset = get_global_id(2) * width * height;
    odata += our_array_offset;
    idata += our_array_offset;
    // read the matrix tile into shared memory
    x_index = get_global_id(0);
    y_index = get_global_id(1);
    
    uint index_in = y_index * width + x_index;
    
    if ((x_index < width && y_index < height) && index_in < total_size)
        block[get_local_id(1) * (FUT_BLOCK_DIM + 1) + get_local_id(0)] =
            idata[index_in];
    barrier(CLK_LOCAL_MEM_FENCE);
    // Write the transposed matrix tile to global memory.
    x_index = get_group_id(1) * FUT_BLOCK_DIM + get_local_id(0);
    y_index = get_group_id(0) * FUT_BLOCK_DIM + get_local_id(1);
    
    uint index_out = y_index * height + x_index;
    
    if ((x_index < height && y_index < width) && index_out < total_size)
        odata[index_out] = block[get_local_id(0) * (FUT_BLOCK_DIM + 1) +
                                 get_local_id(1)];
}
__kernel void map_kernel_1801(int32_t row_1135, int32_t y_1203, __global
                              unsigned char *mem_1973, __global
                              unsigned char *mem_1975, __global
                              unsigned char *mem_1977, __global
                              unsigned char *mem_1979)
{
    const uint kernel_thread_index_1801 = get_global_id(0);
    
    if (kernel_thread_index_1801 >= row_1135)
        return;
    
    int32_t i_1802;
    
    // compute thread index
    {
        i_1802 = kernel_thread_index_1801;
    }
    // read kernel parameters
    { }
    
    char x_1804 = i_1802 == 0;
    int32_t i_1805 = i_1802 + 1;
    char x_1806 = i_1802 == y_1203;
    int32_t i_1807 = i_1802 - 1;
    
    // write kernel result
    {
        *(__global int32_t *) &mem_1973[i_1802 * 4] = i_1805;
        *(__global int32_t *) &mem_1975[i_1802 * 4] = i_1807;
        *(__global char *) &mem_1977[i_1802] = x_1804;
        *(__global char *) &mem_1979[i_1802] = x_1806;
    }
}
__kernel void map_kernel_1677(int32_t col_1136, __global
                              unsigned char *temp_mem_1981, int32_t size_1185,
                              float x_1201, __global unsigned char *mem_1977,
                              float res_1169, __global unsigned char *mem_1973,
                              int32_t y_1202, float res_1174, float res_1163,
                              int32_t row_1135, __global
                              unsigned char *mem_1975, __global
                              unsigned char *power_mem_1971, __global
                              unsigned char *mem_1979, __global
                              unsigned char *mem_1984)
{
    const uint kernel_thread_index_1677 = get_global_id(0);
    
    if (kernel_thread_index_1677 >= row_1135 * col_1136)
        return;
    
    int32_t i_1678;
    int32_t i_1679;
    int32_t i_1681;
    int32_t i_1682;
    char x_1683;
    char x_1684;
    
    // compute thread index
    {
        i_1678 = squot32(kernel_thread_index_1677, col_1136);
        i_1679 = kernel_thread_index_1677 - squot32(kernel_thread_index_1677,
                                                    col_1136) * col_1136;
    }
    // read kernel parameters
    {
        i_1681 = *(__global int32_t *) &mem_1973[i_1678 * 4];
        i_1682 = *(__global int32_t *) &mem_1975[i_1678 * 4];
        x_1683 = *(__global char *) &mem_1977[i_1678];
        x_1684 = *(__global char *) &mem_1979[i_1678];
    }
    
    float x_1686 = *(__global float *) &power_mem_1971[(i_1678 * col_1136 +
                                                        i_1679) * 4];
    char y_1687 = i_1679 == 0;
    char cond_1688 = x_1683 && y_1687;
    int32_t i_1689 = i_1679 + 1;
    char y_1690 = i_1679 == y_1202;
    char cond_1691 = x_1683 && y_1690;
    int32_t i_1692 = i_1679 - 1;
    char cond_1693 = x_1684 && y_1690;
    char cond_1694 = x_1684 && y_1687;
    float y_1791;
    
    if (cond_1688) {
        float x_1695 = *(__global float *) &temp_mem_1981[(i_1678 * size_1185 +
                                                           i_1689) * 4];
        float y_1696 = *(__global float *) &temp_mem_1981[(i_1678 * size_1185 +
                                                           i_1679) * 4];
        float x_1697 = x_1695 - y_1696;
        float x_1698 = x_1697 / res_1163;
        float x_1699 = *(__global float *) &temp_mem_1981[(i_1681 * size_1185 +
                                                           i_1679) * 4];
        float x_1700 = x_1699 - y_1696;
        float y_1701 = x_1700 / res_1169;
        float res_1702 = x_1698 + y_1701;
        
        y_1791 = res_1702;
    } else {
        float res_1790;
        
        if (cond_1691) {
            float x_1703 = *(__global float *) &temp_mem_1981[(i_1678 *
                                                               size_1185 +
                                                               i_1692) * 4];
            float y_1704 = *(__global float *) &temp_mem_1981[(i_1678 *
                                                               size_1185 +
                                                               i_1679) * 4];
            float x_1705 = x_1703 - y_1704;
            float x_1706 = x_1705 / res_1163;
            float x_1707 = *(__global float *) &temp_mem_1981[(i_1681 *
                                                               size_1185 +
                                                               i_1679) * 4];
            float x_1708 = x_1707 - y_1704;
            float y_1709 = x_1708 / res_1169;
            float res_1710 = x_1706 + y_1709;
            
            res_1790 = res_1710;
        } else {
            float res_1789;
            
            if (cond_1693) {
                float x_1711 = *(__global float *) &temp_mem_1981[(i_1678 *
                                                                   size_1185 +
                                                                   i_1692) * 4];
                float y_1712 = *(__global float *) &temp_mem_1981[(i_1678 *
                                                                   size_1185 +
                                                                   i_1679) * 4];
                float x_1713 = x_1711 - y_1712;
                float x_1714 = x_1713 / res_1163;
                float x_1715 = *(__global float *) &temp_mem_1981[(i_1682 *
                                                                   size_1185 +
                                                                   i_1679) * 4];
                float x_1716 = x_1715 - y_1712;
                float y_1717 = x_1716 / res_1169;
                float res_1718 = x_1714 + y_1717;
                
                res_1789 = res_1718;
            } else {
                float res_1788;
                
                if (cond_1694) {
                    float x_1719 = *(__global float *) &temp_mem_1981[(i_1678 *
                                                                       size_1185 +
                                                                       i_1689) *
                                                                      4];
                    float y_1720 = *(__global float *) &temp_mem_1981[(i_1678 *
                                                                       size_1185 +
                                                                       i_1679) *
                                                                      4];
                    float x_1721 = x_1719 - y_1720;
                    float x_1722 = x_1721 / res_1163;
                    float x_1723 = *(__global float *) &temp_mem_1981[(i_1682 *
                                                                       size_1185 +
                                                                       i_1679) *
                                                                      4];
                    float x_1724 = x_1723 - y_1720;
                    float y_1725 = x_1724 / res_1169;
                    float res_1726 = x_1722 + y_1725;
                    
                    res_1788 = res_1726;
                } else {
                    float res_1787;
                    
                    if (x_1683) {
                        float x_1727 = *(__global
                                         float *) &temp_mem_1981[(i_1678 *
                                                                  size_1185 +
                                                                  i_1689) * 4];
                        float y_1728 = *(__global
                                         float *) &temp_mem_1981[(i_1678 *
                                                                  size_1185 +
                                                                  i_1692) * 4];
                        float x_1729 = x_1727 + y_1728;
                        float y_1730 = *(__global
                                         float *) &temp_mem_1981[(i_1678 *
                                                                  size_1185 +
                                                                  i_1679) * 4];
                        float y_1731 = 2.0F * y_1730;
                        float x_1732 = x_1729 - y_1731;
                        float x_1733 = x_1732 / res_1163;
                        float x_1734 = *(__global
                                         float *) &temp_mem_1981[(i_1681 *
                                                                  size_1185 +
                                                                  i_1679) * 4];
                        float x_1735 = x_1734 - y_1730;
                        float y_1736 = x_1735 / res_1169;
                        float res_1737 = x_1733 + y_1736;
                        
                        res_1787 = res_1737;
                    } else {
                        float res_1786;
                        
                        if (y_1690) {
                            float x_1738 = *(__global
                                             float *) &temp_mem_1981[(i_1678 *
                                                                      size_1185 +
                                                                      i_1692) *
                                                                     4];
                            float y_1739 = *(__global
                                             float *) &temp_mem_1981[(i_1678 *
                                                                      size_1185 +
                                                                      i_1679) *
                                                                     4];
                            float x_1740 = x_1738 - y_1739;
                            float x_1741 = x_1740 / res_1163;
                            float x_1742 = *(__global
                                             float *) &temp_mem_1981[(i_1681 *
                                                                      size_1185 +
                                                                      i_1679) *
                                                                     4];
                            float y_1743 = *(__global
                                             float *) &temp_mem_1981[(i_1682 *
                                                                      size_1185 +
                                                                      i_1679) *
                                                                     4];
                            float x_1744 = x_1742 + y_1743;
                            float y_1745 = 2.0F * y_1739;
                            float x_1746 = x_1744 - y_1745;
                            float y_1747 = x_1746 / res_1169;
                            float res_1748 = x_1741 + y_1747;
                            
                            res_1786 = res_1748;
                        } else {
                            float res_1785;
                            
                            if (x_1684) {
                                float x_1749 = *(__global
                                                 float *) &temp_mem_1981[(i_1678 *
                                                                          size_1185 +
                                                                          i_1689) *
                                                                         4];
                                float y_1750 = *(__global
                                                 float *) &temp_mem_1981[(i_1678 *
                                                                          size_1185 +
                                                                          i_1692) *
                                                                         4];
                                float x_1751 = x_1749 + y_1750;
                                float y_1752 = *(__global
                                                 float *) &temp_mem_1981[(i_1678 *
                                                                          size_1185 +
                                                                          i_1679) *
                                                                         4];
                                float y_1753 = 2.0F * y_1752;
                                float x_1754 = x_1751 - y_1753;
                                float x_1755 = x_1754 / res_1163;
                                float x_1756 = *(__global
                                                 float *) &temp_mem_1981[(i_1682 *
                                                                          size_1185 +
                                                                          i_1679) *
                                                                         4];
                                float x_1757 = x_1756 - y_1752;
                                float y_1758 = x_1757 / res_1169;
                                float res_1759 = x_1755 + y_1758;
                                
                                res_1785 = res_1759;
                            } else {
                                float res_1784;
                                
                                if (y_1687) {
                                    float x_1760 = *(__global
                                                     float *) &temp_mem_1981[(i_1678 *
                                                                              size_1185 +
                                                                              i_1689) *
                                                                             4];
                                    float y_1761 = *(__global
                                                     float *) &temp_mem_1981[(i_1678 *
                                                                              size_1185 +
                                                                              i_1679) *
                                                                             4];
                                    float x_1762 = x_1760 - y_1761;
                                    float x_1763 = x_1762 / res_1163;
                                    float x_1764 = *(__global
                                                     float *) &temp_mem_1981[(i_1681 *
                                                                              size_1185 +
                                                                              i_1679) *
                                                                             4];
                                    float y_1765 = *(__global
                                                     float *) &temp_mem_1981[(i_1682 *
                                                                              size_1185 +
                                                                              i_1679) *
                                                                             4];
                                    float x_1766 = x_1764 + y_1765;
                                    float y_1767 = 2.0F * y_1761;
                                    float x_1768 = x_1766 - y_1767;
                                    float y_1769 = x_1768 / res_1169;
                                    float res_1770 = x_1763 + y_1769;
                                    
                                    res_1784 = res_1770;
                                } else {
                                    float x_1771 = *(__global
                                                     float *) &temp_mem_1981[(i_1678 *
                                                                              size_1185 +
                                                                              i_1689) *
                                                                             4];
                                    float y_1772 = *(__global
                                                     float *) &temp_mem_1981[(i_1678 *
                                                                              size_1185 +
                                                                              i_1692) *
                                                                             4];
                                    float x_1773 = x_1771 + y_1772;
                                    float y_1774 = *(__global
                                                     float *) &temp_mem_1981[(i_1678 *
                                                                              size_1185 +
                                                                              i_1679) *
                                                                             4];
                                    float y_1775 = 2.0F * y_1774;
                                    float x_1776 = x_1773 - y_1775;
                                    float x_1777 = x_1776 / res_1163;
                                    float x_1778 = *(__global
                                                     float *) &temp_mem_1981[(i_1681 *
                                                                              size_1185 +
                                                                              i_1679) *
                                                                             4];
                                    float y_1779 = *(__global
                                                     float *) &temp_mem_1981[(i_1682 *
                                                                              size_1185 +
                                                                              i_1679) *
                                                                             4];
                                    float x_1780 = x_1778 + y_1779;
                                    float x_1781 = x_1780 - y_1775;
                                    float y_1782 = x_1781 / res_1169;
                                    float res_1783 = x_1777 + y_1782;
                                    
                                    res_1784 = res_1783;
                                }
                                res_1785 = res_1784;
                            }
                            res_1786 = res_1785;
                        }
                        res_1787 = res_1786;
                    }
                    res_1788 = res_1787;
                }
                res_1789 = res_1788;
            }
            res_1790 = res_1789;
        }
        y_1791 = res_1790;
    }
    
    float x_1792 = x_1686 + y_1791;
    float y_1793 = *(__global float *) &temp_mem_1981[(i_1678 * size_1185 +
                                                       i_1679) * 4];
    float x_1794 = 80.0F - y_1793;
    float y_1795 = x_1794 / res_1174;
    float y_1796 = x_1792 + y_1795;
    float res_1797 = x_1201 * y_1796;
    float res_1798 = y_1793 + res_1797;
    
    // write kernel result
    {
        *(__global float *) &mem_1984[(i_1678 * col_1136 + i_1679) * 4] =
            res_1798;
    }
}
__kernel void map_kernel_1947(int32_t y_1450, int32_t row_1387, __global
                              unsigned char *mem_1992, __global
                              unsigned char *mem_1994, __global
                              unsigned char *mem_1996, __global
                              unsigned char *mem_1998)
{
    const uint kernel_thread_index_1947 = get_global_id(0);
    
    if (kernel_thread_index_1947 >= row_1387)
        return;
    
    int32_t i_1948;
    
    // compute thread index
    {
        i_1948 = kernel_thread_index_1947;
    }
    // read kernel parameters
    { }
    
    char x_1950 = i_1948 == 0;
    int32_t i_1951 = i_1948 + 1;
    char x_1952 = i_1948 == y_1450;
    int32_t i_1953 = i_1948 - 1;
    
    // write kernel result
    {
        *(__global char *) &mem_1992[i_1948] = x_1952;
        *(__global char *) &mem_1994[i_1948] = x_1950;
        *(__global int32_t *) &mem_1996[i_1948 * 4] = i_1951;
        *(__global int32_t *) &mem_1998[i_1948 * 4] = i_1953;
    }
}
__kernel void map_kernel_1823(float res_1416, __global unsigned char *mem_1992,
                              int32_t col_1388, __global
                              unsigned char *temp_mem_2000, int32_t size_1432,
                              float x_1448, __global unsigned char *mem_1996,
                              int32_t y_1449, float res_1421, float res_1410,
                              __global unsigned char *mem_1994, __global
                              unsigned char *power_mem_1990, __global
                              unsigned char *mem_1998, int32_t row_1387,
                              __global unsigned char *mem_2003)
{
    const uint kernel_thread_index_1823 = get_global_id(0);
    
    if (kernel_thread_index_1823 >= row_1387 * col_1388)
        return;
    
    int32_t i_1824;
    int32_t i_1825;
    char x_1827;
    char x_1828;
    int32_t i_1829;
    int32_t i_1830;
    
    // compute thread index
    {
        i_1824 = squot32(kernel_thread_index_1823, col_1388);
        i_1825 = kernel_thread_index_1823 - squot32(kernel_thread_index_1823,
                                                    col_1388) * col_1388;
    }
    // read kernel parameters
    {
        x_1827 = *(__global char *) &mem_1992[i_1824];
        x_1828 = *(__global char *) &mem_1994[i_1824];
        i_1829 = *(__global int32_t *) &mem_1996[i_1824 * 4];
        i_1830 = *(__global int32_t *) &mem_1998[i_1824 * 4];
    }
    
    float x_1832 = *(__global float *) &power_mem_1990[(i_1824 * col_1388 +
                                                        i_1825) * 4];
    char y_1833 = i_1825 == 0;
    char cond_1834 = x_1828 && y_1833;
    int32_t i_1835 = i_1825 + 1;
    char y_1836 = i_1825 == y_1449;
    char cond_1837 = x_1828 && y_1836;
    int32_t i_1838 = i_1825 - 1;
    char cond_1839 = x_1827 && y_1836;
    char cond_1840 = x_1827 && y_1833;
    float y_1937;
    
    if (cond_1834) {
        float x_1841 = *(__global float *) &temp_mem_2000[(i_1824 * size_1432 +
                                                           i_1835) * 4];
        float y_1842 = *(__global float *) &temp_mem_2000[(i_1824 * size_1432 +
                                                           i_1825) * 4];
        float x_1843 = x_1841 - y_1842;
        float x_1844 = x_1843 / res_1410;
        float x_1845 = *(__global float *) &temp_mem_2000[(i_1829 * size_1432 +
                                                           i_1825) * 4];
        float x_1846 = x_1845 - y_1842;
        float y_1847 = x_1846 / res_1416;
        float res_1848 = x_1844 + y_1847;
        
        y_1937 = res_1848;
    } else {
        float res_1936;
        
        if (cond_1837) {
            float x_1849 = *(__global float *) &temp_mem_2000[(i_1824 *
                                                               size_1432 +
                                                               i_1838) * 4];
            float y_1850 = *(__global float *) &temp_mem_2000[(i_1824 *
                                                               size_1432 +
                                                               i_1825) * 4];
            float x_1851 = x_1849 - y_1850;
            float x_1852 = x_1851 / res_1410;
            float x_1853 = *(__global float *) &temp_mem_2000[(i_1829 *
                                                               size_1432 +
                                                               i_1825) * 4];
            float x_1854 = x_1853 - y_1850;
            float y_1855 = x_1854 / res_1416;
            float res_1856 = x_1852 + y_1855;
            
            res_1936 = res_1856;
        } else {
            float res_1935;
            
            if (cond_1839) {
                float x_1857 = *(__global float *) &temp_mem_2000[(i_1824 *
                                                                   size_1432 +
                                                                   i_1838) * 4];
                float y_1858 = *(__global float *) &temp_mem_2000[(i_1824 *
                                                                   size_1432 +
                                                                   i_1825) * 4];
                float x_1859 = x_1857 - y_1858;
                float x_1860 = x_1859 / res_1410;
                float x_1861 = *(__global float *) &temp_mem_2000[(i_1830 *
                                                                   size_1432 +
                                                                   i_1825) * 4];
                float x_1862 = x_1861 - y_1858;
                float y_1863 = x_1862 / res_1416;
                float res_1864 = x_1860 + y_1863;
                
                res_1935 = res_1864;
            } else {
                float res_1934;
                
                if (cond_1840) {
                    float x_1865 = *(__global float *) &temp_mem_2000[(i_1824 *
                                                                       size_1432 +
                                                                       i_1835) *
                                                                      4];
                    float y_1866 = *(__global float *) &temp_mem_2000[(i_1824 *
                                                                       size_1432 +
                                                                       i_1825) *
                                                                      4];
                    float x_1867 = x_1865 - y_1866;
                    float x_1868 = x_1867 / res_1410;
                    float x_1869 = *(__global float *) &temp_mem_2000[(i_1830 *
                                                                       size_1432 +
                                                                       i_1825) *
                                                                      4];
                    float x_1870 = x_1869 - y_1866;
                    float y_1871 = x_1870 / res_1416;
                    float res_1872 = x_1868 + y_1871;
                    
                    res_1934 = res_1872;
                } else {
                    float res_1933;
                    
                    if (x_1828) {
                        float x_1873 = *(__global
                                         float *) &temp_mem_2000[(i_1824 *
                                                                  size_1432 +
                                                                  i_1835) * 4];
                        float y_1874 = *(__global
                                         float *) &temp_mem_2000[(i_1824 *
                                                                  size_1432 +
                                                                  i_1838) * 4];
                        float x_1875 = x_1873 + y_1874;
                        float y_1876 = *(__global
                                         float *) &temp_mem_2000[(i_1824 *
                                                                  size_1432 +
                                                                  i_1825) * 4];
                        float y_1877 = 2.0F * y_1876;
                        float x_1878 = x_1875 - y_1877;
                        float x_1879 = x_1878 / res_1410;
                        float x_1880 = *(__global
                                         float *) &temp_mem_2000[(i_1829 *
                                                                  size_1432 +
                                                                  i_1825) * 4];
                        float x_1881 = x_1880 - y_1876;
                        float y_1882 = x_1881 / res_1416;
                        float res_1883 = x_1879 + y_1882;
                        
                        res_1933 = res_1883;
                    } else {
                        float res_1932;
                        
                        if (y_1836) {
                            float x_1884 = *(__global
                                             float *) &temp_mem_2000[(i_1824 *
                                                                      size_1432 +
                                                                      i_1838) *
                                                                     4];
                            float y_1885 = *(__global
                                             float *) &temp_mem_2000[(i_1824 *
                                                                      size_1432 +
                                                                      i_1825) *
                                                                     4];
                            float x_1886 = x_1884 - y_1885;
                            float x_1887 = x_1886 / res_1410;
                            float x_1888 = *(__global
                                             float *) &temp_mem_2000[(i_1829 *
                                                                      size_1432 +
                                                                      i_1825) *
                                                                     4];
                            float y_1889 = *(__global
                                             float *) &temp_mem_2000[(i_1830 *
                                                                      size_1432 +
                                                                      i_1825) *
                                                                     4];
                            float x_1890 = x_1888 + y_1889;
                            float y_1891 = 2.0F * y_1885;
                            float x_1892 = x_1890 - y_1891;
                            float y_1893 = x_1892 / res_1416;
                            float res_1894 = x_1887 + y_1893;
                            
                            res_1932 = res_1894;
                        } else {
                            float res_1931;
                            
                            if (x_1827) {
                                float x_1895 = *(__global
                                                 float *) &temp_mem_2000[(i_1824 *
                                                                          size_1432 +
                                                                          i_1835) *
                                                                         4];
                                float y_1896 = *(__global
                                                 float *) &temp_mem_2000[(i_1824 *
                                                                          size_1432 +
                                                                          i_1838) *
                                                                         4];
                                float x_1897 = x_1895 + y_1896;
                                float y_1898 = *(__global
                                                 float *) &temp_mem_2000[(i_1824 *
                                                                          size_1432 +
                                                                          i_1825) *
                                                                         4];
                                float y_1899 = 2.0F * y_1898;
                                float x_1900 = x_1897 - y_1899;
                                float x_1901 = x_1900 / res_1410;
                                float x_1902 = *(__global
                                                 float *) &temp_mem_2000[(i_1830 *
                                                                          size_1432 +
                                                                          i_1825) *
                                                                         4];
                                float x_1903 = x_1902 - y_1898;
                                float y_1904 = x_1903 / res_1416;
                                float res_1905 = x_1901 + y_1904;
                                
                                res_1931 = res_1905;
                            } else {
                                float res_1930;
                                
                                if (y_1833) {
                                    float x_1906 = *(__global
                                                     float *) &temp_mem_2000[(i_1824 *
                                                                              size_1432 +
                                                                              i_1835) *
                                                                             4];
                                    float y_1907 = *(__global
                                                     float *) &temp_mem_2000[(i_1824 *
                                                                              size_1432 +
                                                                              i_1825) *
                                                                             4];
                                    float x_1908 = x_1906 - y_1907;
                                    float x_1909 = x_1908 / res_1410;
                                    float x_1910 = *(__global
                                                     float *) &temp_mem_2000[(i_1829 *
                                                                              size_1432 +
                                                                              i_1825) *
                                                                             4];
                                    float y_1911 = *(__global
                                                     float *) &temp_mem_2000[(i_1830 *
                                                                              size_1432 +
                                                                              i_1825) *
                                                                             4];
                                    float x_1912 = x_1910 + y_1911;
                                    float y_1913 = 2.0F * y_1907;
                                    float x_1914 = x_1912 - y_1913;
                                    float y_1915 = x_1914 / res_1416;
                                    float res_1916 = x_1909 + y_1915;
                                    
                                    res_1930 = res_1916;
                                } else {
                                    float x_1917 = *(__global
                                                     float *) &temp_mem_2000[(i_1824 *
                                                                              size_1432 +
                                                                              i_1835) *
                                                                             4];
                                    float y_1918 = *(__global
                                                     float *) &temp_mem_2000[(i_1824 *
                                                                              size_1432 +
                                                                              i_1838) *
                                                                             4];
                                    float x_1919 = x_1917 + y_1918;
                                    float y_1920 = *(__global
                                                     float *) &temp_mem_2000[(i_1824 *
                                                                              size_1432 +
                                                                              i_1825) *
                                                                             4];
                                    float y_1921 = 2.0F * y_1920;
                                    float x_1922 = x_1919 - y_1921;
                                    float x_1923 = x_1922 / res_1410;
                                    float x_1924 = *(__global
                                                     float *) &temp_mem_2000[(i_1829 *
                                                                              size_1432 +
                                                                              i_1825) *
                                                                             4];
                                    float y_1925 = *(__global
                                                     float *) &temp_mem_2000[(i_1830 *
                                                                              size_1432 +
                                                                              i_1825) *
                                                                             4];
                                    float x_1926 = x_1924 + y_1925;
                                    float x_1927 = x_1926 - y_1921;
                                    float y_1928 = x_1927 / res_1416;
                                    float res_1929 = x_1923 + y_1928;
                                    
                                    res_1930 = res_1929;
                                }
                                res_1931 = res_1930;
                            }
                            res_1932 = res_1931;
                        }
                        res_1933 = res_1932;
                    }
                    res_1934 = res_1933;
                }
                res_1935 = res_1934;
            }
            res_1936 = res_1935;
        }
        y_1937 = res_1936;
    }
    
    float x_1938 = x_1832 + y_1937;
    float y_1939 = *(__global float *) &temp_mem_2000[(i_1824 * size_1432 +
                                                       i_1825) * 4];
    float x_1940 = 80.0F - y_1939;
    float y_1941 = x_1940 / res_1421;
    float y_1942 = x_1938 + y_1941;
    float res_1943 = x_1448 * y_1942;
    float res_1944 = y_1939 + res_1943;
    
    // write kernel result
    {
        *(__global float *) &mem_2003[(i_1824 * col_1388 + i_1825) * 4] =
            res_1944;
    }
}
"""
# Hacky parser/reader for values written in Futhark syntax.  Used for
# reading stdin when compiling standalone programs with the Python
# code generator.

lookahead_buffer = []

def reset_lookahead():
    global lookahead_buffer
    lookahead_buffer = []

def get_char(f):
    global lookahead_buffer
    if len(lookahead_buffer) == 0:
        return f.read(1)
    else:
        c = lookahead_buffer[0]
        lookahead_buffer = lookahead_buffer[1:]
        return c

def unget_char(f, c):
    global lookahead_buffer
    lookahead_buffer = [c] + lookahead_buffer

def peek_char(f):
    c = get_char(f)
    if c:
        unget_char(f, c)
    return c

def skip_spaces(f):
    c = get_char(f)
    while c != None:
        if c.isspace():
            c = get_char(f)
        elif c == '-':
          # May be line comment.
          if peek_char(f) == '-':
            # Yes, line comment. Skip to end of line.
            while (c != '\n' and c != None):
              c = get_char(f)
          else:
            break
        else:
          break
    if c:
        unget_char(f, c)

def parse_specific_char(f, expected):
    got = get_char(f)
    if got != expected:
        unget_char(f, got)
        raise ValueError
    return True

def parse_specific_string(f, s):
    for c in s:
        parse_specific_char(f, c)
    return True

def optional(p, *args):
    try:
        return p(*args)
    except ValueError:
        return None

def sepBy(p, sep, *args):
    elems = []
    x = optional(p, *args)
    if x != None:
        elems += [x]
        while optional(sep, *args) != None:
            x = p(*args)
            elems += [x]
    return elems

def parse_int(f):
    s = ''
    c = get_char(f)
    while c != None:
        if c.isdigit():
            s += c
            c = get_char(f)
        else:
            unget_char(f, c)
            break
    optional(read_int_trailer, f)
    return s

def parse_int_signed(f):
    s = ''
    c = get_char(f)

    if c == '-' and peek_char(f).isdigit():
      s = c + parse_int(f)
    else:
      unget_char(f, c)
      s = parse_int(f)

    return s

def read_int_trailer(f):
  parse_specific_char(f, 'i')
  while peek_char(f).isdigit():
    get_char(f)

def read_comma(f):
    skip_spaces(f)
    parse_specific_char(f, ',')
    return ','

def read_int(f):
    skip_spaces(f)
    return int(parse_int_signed(f))

def read_char(f):
    skip_spaces(f)
    parse_specific_char(f, '\'')
    c = get_char(f)
    parse_specific_char(f, '\'')
    return c

def read_double(f):
    skip_spaces(f)
    c = get_char(f)
    if (c == '-'):
      sign = '-'
    else:
      unget_char(f,c)
      sign = ''
    bef = optional(parse_int, f)
    if bef == None:
        bef = '0'
        parse_specific_char(f, '.')
        aft = parse_int(f)
    elif optional(parse_specific_char, f, '.'):
        aft = parse_int(f)
    else:
        aft = '0'
    if (optional(parse_specific_char, f, 'E') or
        optional(parse_specific_char, f, 'e')):
        expt = parse_int_signed(f)
    else:
        expt = '0'
    optional(read_float_trailer, f)
    return float(sign + bef + '.' + aft + 'E' + expt)

def read_float(f):
    return read_double(f)

def read_float_trailer(f):
  parse_specific_char(f, 'f')
  while peek_char(f).isdigit():
    get_char(f)

def read_bool(f):
    skip_spaces(f)
    if peek_char(f) == 'T':
        parse_specific_string(f, 'True')
        return True
    elif peek_char(f) == 'F':
        parse_specific_string(f, 'False')
        return False
    else:
        raise ValueError

def read_array_elems(f, elem_reader):
    skip_spaces(f)
    parse_specific_char(f, '[')
    xs = sepBy(elem_reader, read_comma, f)
    skip_spaces(f)
    parse_specific_char(f, ']')
    return xs

def read_array_helper(f, elem_reader, rank):
    def nested_row_reader(_):
        return read_array_helper(f, elem_reader, rank-1)
    if rank == 1:
        row_reader = elem_reader
    else:
        row_reader = nested_row_reader
    return read_array_elems(f, row_reader)

def expected_array_dims(l, rank):
  if rank > 1:
      n = len(l)
      if n == 0:
          elem = []
      else:
          elem = l[0]
      return [n] + expected_array_dims(elem, rank-1)
  else:
      return [len(l)]

def verify_array_dims(l, dims):
    if dims[0] != len(l):
        raise ValueError
    if len(dims) > 1:
        for x in l:
            verify_array_dims(x, dims[1:])

def read_double_signed(f):

    skip_spaces(f)
    c = get_char(f)

    if c == '-' and peek_char(f).isdigit():
      v = -1 * read_double(f)
    else:
      unget_char(f, c)
      v = read_double(f)

    return v

def read_array(f, elem_reader, rank, bt):
    elems = read_array_helper(f, elem_reader, rank)
    dims = expected_array_dims(elems, rank)
    verify_array_dims(elems, dims)
    return np.array(elems, dtype=bt)
# Scalar functions.

import numpy as np

def signed(x):
  if type(x) == np.uint8:
    return np.int8(x)
  elif type(x) == np.uint16:
    return np.int16(x)
  elif type(x) == np.uint32:
    return np.int32(x)
  else:
    return np.int64(x)

def unsigned(x):
  if type(x) == np.int8:
    return np.uint8(x)
  elif type(x) == np.int16:
    return np.uint16(x)
  elif type(x) == np.int32:
    return np.uint32(x)
  else:
    return np.uint64(x)

def shlN(x,y):
  return x << y

def ashrN(x,y):
  return x >> y

def sdivN(x,y):
  return x / y

def smodN(x,y):
  return x % y

def udivN(x,y):
  return signed(unsigned(x) / unsigned(y))

def umodN(x,y):
  return signed(unsigned(x) % unsigned(y))

def squotN(x,y):
  return np.int32(float(x) / float(y))

def sremN(x,y):
  return np.fmod(x,y)

def powN(x,y):
  return x ** y

def fpowN(x,y):
  return x ** y

def sleN(x,y):
  return x <= y

def sltN(x,y):
  return x < y

def uleN(x,y):
  return unsigned(x) <= unsigned(y)

def ultN(x,y):
  return unsigned(x) < unsigned(y)

def lshr8(x,y):
  return np.int8(np.uint8(x) >> np.uint8(y))

def lshr16(x,y):
  return np.int16(np.uint16(x) >> np.uint16(y))

def lshr32(x,y):
  return np.int32(np.uint32(x) >> np.uint32(y))

def lshr64(x,y):
  return np.int64(np.uint64(x) >> np.uint64(y))

def sext_T_i8(x):
  return np.int8(x)

def sext_T_i16(x):
  return np.int16(x)

def sext_T_i32(x):
  return np.int32(x)

def sext_T_i64(x):
  return np.int32(x)

def zext_i8_i8(x):
  return np.int8(np.uint8(x))

def zext_i8_i16(x):
  return np.int16(np.uint8(x))

def zext_i8_i32(x):
  return np.int32(np.uint8(x))

def zext_i8_i64(x):
  return np.int64(np.uint8(x))

def zext_i16_i8(x):
  return np.int8(np.uint16(x))

def zext_i16_i16(x):
  return np.int16(np.uint16(x))

def zext_i16_i32(x):
  return np.int32(np.uint16(x))

def zext_i16_i64(x):
  return np.int64(np.uint16(x))

def zext_i32_i8(x):
  return np.int8(np.uint32(x))

def zext_i32_i16(x):
  return np.int16(np.uint32(x))

def zext_i32_i32(x):
  return np.int32(np.uint32(x))

def zext_i32_i64(x):
  return np.int64(np.uint32(x))

def zext_i64_i8(x):
  return np.int8(np.uint64(x))

def zext_i64_i16(x):
  return np.int16(np.uint64(x))

def zext_i64_i32(x):
  return np.int32(np.uint64(x))

def zext_i64_i64(x):
  return np.int64(np.uint64(x))

shl8 = shl16 = shl32 = shl64 = shlN
ashr8 = ashr16 = ashr32 = ashr64 = ashrN
sdiv8 = sdiv16 = sdiv32 = sdiv64 = sdivN
smod8 = smod16 = smod32 = smod64 = smodN
udiv8 = udiv16 = udiv32 = udiv64 = udivN
umod8 = umod16 = umod32 = umod64 = umodN
squot8 = squot16 = squot32 = squot64 = squotN
srem8 = srem16 = srem32 = srem64 = sremN
pow8 = pow16 = pow32 = pow64 = powN
fpow32 = fpow64 = fpowN
sle8 = sle16 = sle32 = sle64 = sleN
slt8 = slt16 = slt32 = slt64 = sltN
ule8 = ule16 = ule32 = ule64 = uleN
ult8 = ult16 = ult32 = ult64 = ultN
sext_i8_i8 = sext_i16_i8 = sext_i32_i8 = sext_i64_i8 = sext_T_i8
sext_i8_i16 = sext_i16_i16 = sext_i32_i16 = sext_i64_i16 = sext_T_i16
sext_i8_i32 = sext_i16_i32 = sext_i32_i32 = sext_i64_i32 = sext_T_i32
sext_i8_i64 = sext_i16_i64 = sext_i32_i64 = sext_i64_i64 = sext_T_i64

def ssignum(x):
  return np.sign(x)

def usignum(x):
  if x < 0:
    return ssignum(-x)
  else:
    return ssignum(x)

def sitofp_T_f32(x):
  return np.float32(x)
sitofp_i8_f32 = sitofp_i16_f32 = sitofp_i32_f32 = sitofp_i64_f32 = sitofp_T_f32

def sitofp_T_f64(x):
  return np.float64(x)
sitofp_i8_f64 = sitofp_i16_f64 = sitofp_i32_f64 = sitofp_i64_f64 = sitofp_T_f64

def uitofp_T_f32(x):
  return np.float32(unsigned(x))
uitofp_i8_f32 = uitofp_i16_f32 = uitofp_i32_f32 = uitofp_i64_f32 = uitofp_T_f32

def uitofp_T_f64(x):
  return np.float64(unsigned(x))
uitofp_i8_f64 = uitofp_i16_f64 = uitofp_i32_f64 = uitofp_i64_f64 = uitofp_T_f64

def fptosi_T_i8(x):
  return np.int8(np.trunc(x))
fptosi_f32_i8 = fptosi_f64_i8 = fptosi_T_i8

def fptosi_T_i16(x):
  return np.int16(np.trunc(x))
fptosi_f32_i16 = fptosi_f64_i16 = fptosi_T_i16

def fptosi_T_i32(x):
  return np.int32(np.trunc(x))
fptosi_f32_i32 = fptosi_f64_i32 = fptosi_T_i32

def fptosi_T_i64(x):
  return np.int64(np.trunc(x))
fptosi_f32_i64 = fptosi_f64_i64 = fptosi_T_i64

def fptoui_T_i8(x):
  return np.uint8(np.trunc(x))
fptoui_f32_i8 = fptoui_f64_i8 = fptoui_T_i8

def fptoui_T_i16(x):
  return np.uint16(np.trunc(x))
fptoui_f32_i16 = fptoui_f64_i16 = fptoui_T_i16

def fptoui_T_i32(x):
  return np.uint32(np.trunc(x))
fptoui_f32_i32 = fptoui_f64_i32 = fptoui_T_i32

def fptoui_T_i64(x):
  return np.uint64(np.trunc(x))
fptoui_f32_i64 = fptoui_f64_i64 = fptoui_T_i64

def fpconv_f32_f64(x):
  return np.float64(x)

def fpconv_f64_f32(x):
  return np.float32(x)

def futhark_log64(x):
  return np.float64(np.log(x))

def futhark_sqrt64(x):
  return np.sqrt(x)

def futhark_exp64(x):
  return np.exp(x)

def futhark_cos64(x):
  return np.cos(x)

def futhark_sin64(x):
  return np.sin(x)

def futhark_atan2_64(x, y):
  return np.arctan2(x, y)

def futhark_isnan64(x):
  return np.isnan(x)

def futhark_isinf64(x):
  return np.isinf(x)

def futhark_log32(x):
  return np.float32(np.log(x))

def futhark_sqrt32(x):
  return np.float32(np.sqrt(x))

def futhark_exp32(x):
  return np.exp(x)

def futhark_cos32(x):
  return np.cos(x)

def futhark_sin32(x):
  return np.sin(x)

def futhark_atan2_32(x, y):
  return np.arctan2(x, y)

def futhark_isnan32(x):
  return np.isnan(x)

def futhark_isinf32(x):
  return np.isinf(x)
class hotspot:
  def __init__(self):
    self.ctx = cl.create_some_context(interactive=False)
    self.queue = cl.CommandQueue(self.ctx)
     # XXX: Assuming just a single device here.
    platform_name = self.ctx.get_info(cl.context_info.DEVICES)[0].platform.name
    device_type = self.ctx.get_info(cl.context_info.DEVICES)[0].type
    lockstep_width = 1
    if ((platform_name == "NVIDIA CUDA") and (device_type == cl.device_type.GPU)):
      lockstep_width = np.int32(32)
    if ((platform_name == "AMD Accelerated Parallel Processing") and (device_type == cl.device_type.GPU)):
      lockstep_width = np.int32(64)
    if (len(fut_opencl_src) >= 0):
      program = cl.Program(self.ctx, fut_opencl_src).build(["-DFUT_BLOCK_DIM={}".format(FUT_BLOCK_DIM), "-DLOCKSTEP_WIDTH={}".format(lockstep_width)])
    
    self.map_kernel_1649_var = program.map_kernel_1649
    self.fut_kernel_map_transpose_i8_var = program.fut_kernel_map_transpose_i8
    self.map_kernel_1801_var = program.map_kernel_1801
    self.map_kernel_1677_var = program.map_kernel_1677
    self.map_kernel_1947_var = program.map_kernel_1947
    self.map_kernel_1823_var = program.map_kernel_1823
  def futhark_render_frame(self, temp_mem_size_1955, temp_mem_1956, row_1118,
                           col_1119):
    nesting_size_1647 = (col_1119 * row_1118)
    x_1961 = (row_1118 * np.int32(3))
    bytes_1959 = (x_1961 * col_1119)
    mem_1962 = cl.Buffer(self.ctx, cl.mem_flags.READ_WRITE,
                         long(long(bytes_1959) if (bytes_1959 > np.int32(0)) else np.int32(1)))
    total_size_2010 = (nesting_size_1647 * np.int32(3))
    mem_1958 = cl.Buffer(self.ctx, cl.mem_flags.READ_WRITE,
                         long(long(total_size_2010) if (total_size_2010 > np.int32(0)) else np.int32(1)))
    group_size_2014 = np.int32(512)
    num_groups_2015 = squot32((((row_1118 * col_1119) + group_size_2014) - np.int32(1)),
                              group_size_2014)
    if ((np.int32(1) * (num_groups_2015 * group_size_2014)) != np.int32(0)):
      self.map_kernel_1649_var.set_args(temp_mem_1956, np.int32(row_1118),
                                        mem_1958, np.int32(nesting_size_1647),
                                        np.int32(col_1119), mem_1962)
      cl.enqueue_nd_range_kernel(self.queue, self.map_kernel_1649_var,
                                 (long((num_groups_2015 * group_size_2014)),),
                                 (long(group_size_2014),))
      if synchronous:
        self.queue.finish()
    x_1965 = (row_1118 * col_1119)
    bytes_1963 = (x_1965 * np.int32(3))
    mem_1966 = cl.Buffer(self.ctx, cl.mem_flags.READ_WRITE,
                         long(long(bytes_1963) if (bytes_1963 > np.int32(0)) else np.int32(1)))
    if ((((np.int32(1) * (col_1119 + srem32((np.int32(16) - srem32(col_1119,
                                                                   np.int32(16))),
                                            np.int32(16)))) * (np.int32(3) + srem32((np.int32(16) - srem32(np.int32(3),
                                                                                                           np.int32(16))),
                                                                                    np.int32(16)))) * row_1118) != np.int32(0)):
      self.fut_kernel_map_transpose_i8_var.set_args(mem_1966,
                                                    np.int32(np.int32(0)),
                                                    mem_1962,
                                                    np.int32(np.int32(0)),
                                                    np.int32(col_1119),
                                                    np.int32(np.int32(3)),
                                                    np.int32(((row_1118 * col_1119) * np.int32(3))),
                                                    cl.LocalMemory(long((((np.int32(16) + np.int32(1)) * np.int32(16)) * np.int32(1)))))
      cl.enqueue_nd_range_kernel(self.queue,
                                 self.fut_kernel_map_transpose_i8_var,
                                 (long((col_1119 + srem32((np.int32(16) - srem32(col_1119,
                                                                                 np.int32(16))),
                                                          np.int32(16)))),
                                  long((np.int32(3) + srem32((np.int32(16) - srem32(np.int32(3),
                                                                                    np.int32(16))),
                                                             np.int32(16)))),
                                  long(row_1118)), (long(np.int32(16)),
                                                    long(np.int32(16)),
                                                    long(np.int32(1))))
      if synchronous:
        self.queue.finish()
    out_mem_2011 = mem_1966
    out_memsize_2012 = bytes_1963
    return (out_memsize_2012, out_mem_2011)
  def futhark_main(self, temp_mem_size_1968, power_mem_size_1970, temp_mem_1969,
                   power_mem_1971, row_1135, col_1136, num_iterations_1137):
    y_1146 = sitofp_i32_f32(row_1135)
    res_1147 = (np.float32(1.6e-2) / y_1146)
    y_1149 = sitofp_i32_f32(col_1136)
    res_1150 = (np.float32(1.6e-2) / y_1149)
    x_1156 = (np.float32(437.50003) * res_1150)
    res_1157 = (x_1156 * res_1147)
    y_1162 = (np.float32(0.1) * res_1147)
    res_1163 = (res_1150 / y_1162)
    y_1168 = (np.float32(0.1) * res_1150)
    res_1169 = (res_1147 / y_1168)
    x_1172 = (np.float32(100.0) * res_1147)
    y_1173 = (x_1172 * res_1150)
    res_1174 = (np.float32(5.0e-4) / y_1173)
    cond_1198 = (row_1135 == np.int32(0))
    if cond_1198:
      size_1199 = np.int32(0)
    else:
      size_1199 = col_1136
    x_1201 = (np.float32(1.4583334e-7) / res_1157)
    y_1202 = (col_1136 - np.int32(1))
    y_1203 = (row_1135 - np.int32(1))
    eq_x_y_1209 = (col_1136 == np.int32(0))
    p_and_eq_x_y_1210 = (cond_1198 and eq_x_y_1209)
    not_p_1211 = not(cond_1198)
    assert_arg_1212 = (p_and_eq_x_y_1210 or not_p_1211)
    assert assert_arg_1212, 'hotspot.fut:44:8-44:8'
    bytes_1972 = (np.int32(4) * row_1135)
    mem_1973 = cl.Buffer(self.ctx, cl.mem_flags.READ_WRITE,
                         long(long(bytes_1972) if (bytes_1972 > np.int32(0)) else np.int32(1)))
    mem_1975 = cl.Buffer(self.ctx, cl.mem_flags.READ_WRITE,
                         long(long(bytes_1972) if (bytes_1972 > np.int32(0)) else np.int32(1)))
    mem_1977 = cl.Buffer(self.ctx, cl.mem_flags.READ_WRITE,
                         long(long(row_1135) if (row_1135 > np.int32(0)) else np.int32(1)))
    mem_1979 = cl.Buffer(self.ctx, cl.mem_flags.READ_WRITE,
                         long(long(row_1135) if (row_1135 > np.int32(0)) else np.int32(1)))
    group_size_2020 = np.int32(512)
    num_groups_2021 = squot32(((row_1135 + group_size_2020) - np.int32(1)),
                              group_size_2020)
    if ((np.int32(1) * (num_groups_2021 * group_size_2020)) != np.int32(0)):
      self.map_kernel_1801_var.set_args(np.int32(row_1135), np.int32(y_1203),
                                        mem_1973, mem_1975, mem_1977, mem_1979)
      cl.enqueue_nd_range_kernel(self.queue, self.map_kernel_1801_var,
                                 (long((num_groups_2021 * group_size_2020)),),
                                 (long(group_size_2020),))
      if synchronous:
        self.queue.finish()
    nesting_size_1675 = (col_1136 * row_1135)
    bytes_1982 = (bytes_1972 * col_1136)
    double_buffer_mem_2006 = cl.Buffer(self.ctx, cl.mem_flags.READ_WRITE,
                                       long(long(bytes_1982) if (bytes_1982 > np.int32(0)) else np.int32(1)))
    mem_1984 = cl.Buffer(self.ctx, cl.mem_flags.READ_WRITE,
                         long(long(bytes_1982) if (bytes_1982 > np.int32(0)) else np.int32(1)))
    temp_mem_size_1980 = temp_mem_size_1968
    temp_mem_1981 = temp_mem_1969
    size_1185 = col_1136
    i_1187 = np.int32(0)
    one_2039 = np.int32(1)
    for counter_2038 in range(num_iterations_1137):
      group_size_2026 = np.int32(512)
      num_groups_2027 = squot32((((row_1135 * col_1136) + group_size_2026) - np.int32(1)),
                                group_size_2026)
      if ((np.int32(1) * (num_groups_2027 * group_size_2026)) != np.int32(0)):
        self.map_kernel_1677_var.set_args(np.int32(col_1136), temp_mem_1981,
                                          np.int32(size_1185),
                                          np.float32(x_1201), mem_1977,
                                          np.float32(res_1169), mem_1973,
                                          np.int32(y_1202),
                                          np.float32(res_1174),
                                          np.float32(res_1163),
                                          np.int32(row_1135), mem_1975,
                                          power_mem_1971, mem_1979, mem_1984)
        cl.enqueue_nd_range_kernel(self.queue, self.map_kernel_1677_var,
                                   (long((num_groups_2027 * group_size_2026)),),
                                   (long(group_size_2026),))
        if synchronous:
          self.queue.finish()
      if (((row_1135 * size_1199) * np.int32(4)) != np.int32(0)):
        cl.enqueue_copy(self.queue, double_buffer_mem_2006, mem_1984,
                        dest_offset=long(np.int32(0)),
                        src_offset=long(np.int32(0)),
                        byte_count=long(((row_1135 * size_1199) * np.int32(4))))
      if synchronous:
        self.queue.finish()
      temp_mem_size_tmp_2022 = bytes_1982
      temp_mem_tmp_2023 = double_buffer_mem_2006
      size_tmp_2024 = size_1199
      temp_mem_size_1980 = temp_mem_size_tmp_2022
      temp_mem_1981 = temp_mem_tmp_2023
      size_1185 = size_tmp_2024
      i_1187 += one_2039
    temp_mem_1986 = temp_mem_1981
    size_1379 = size_1185
    temp_mem_size_1985 = temp_mem_size_1980
    assert_arg_1383 = (col_1136 == size_1379)
    assert assert_arg_1383, 'hotspot.fut:87:23-87:23'
    out_mem_2016 = temp_mem_1986
    out_arrsize_2018 = row_1135
    out_arrsize_2019 = col_1136
    out_memsize_2017 = temp_mem_size_1985
    return (out_memsize_2017, out_mem_2016, out_arrsize_2018, out_arrsize_2019)
  def futhark_compute_tran_temp(self, temp_mem_size_1987, power_mem_size_1989,
                                temp_mem_1988, power_mem_1990, row_1387,
                                col_1388, num_iterations_1389):
    y_1393 = sitofp_i32_f32(row_1387)
    res_1394 = (np.float32(1.6e-2) / y_1393)
    y_1396 = sitofp_i32_f32(col_1388)
    res_1397 = (np.float32(1.6e-2) / y_1396)
    x_1403 = (np.float32(437.50003) * res_1397)
    res_1404 = (x_1403 * res_1394)
    y_1409 = (np.float32(0.1) * res_1394)
    res_1410 = (res_1397 / y_1409)
    y_1415 = (np.float32(0.1) * res_1397)
    res_1416 = (res_1394 / y_1415)
    x_1419 = (np.float32(100.0) * res_1394)
    y_1420 = (x_1419 * res_1397)
    res_1421 = (np.float32(5.0e-4) / y_1420)
    cond_1445 = (row_1387 == np.int32(0))
    if cond_1445:
      size_1446 = np.int32(0)
    else:
      size_1446 = col_1388
    x_1448 = (np.float32(1.4583334e-7) / res_1404)
    y_1449 = (col_1388 - np.int32(1))
    y_1450 = (row_1387 - np.int32(1))
    eq_x_y_1456 = (col_1388 == np.int32(0))
    p_and_eq_x_y_1457 = (cond_1445 and eq_x_y_1456)
    not_p_1458 = not(cond_1445)
    assert_arg_1459 = (p_and_eq_x_y_1457 or not_p_1458)
    assert assert_arg_1459, 'hotspot.fut:44:8-44:8'
    mem_1992 = cl.Buffer(self.ctx, cl.mem_flags.READ_WRITE,
                         long(long(row_1387) if (row_1387 > np.int32(0)) else np.int32(1)))
    mem_1994 = cl.Buffer(self.ctx, cl.mem_flags.READ_WRITE,
                         long(long(row_1387) if (row_1387 > np.int32(0)) else np.int32(1)))
    bytes_1995 = (np.int32(4) * row_1387)
    mem_1996 = cl.Buffer(self.ctx, cl.mem_flags.READ_WRITE,
                         long(long(bytes_1995) if (bytes_1995 > np.int32(0)) else np.int32(1)))
    mem_1998 = cl.Buffer(self.ctx, cl.mem_flags.READ_WRITE,
                         long(long(bytes_1995) if (bytes_1995 > np.int32(0)) else np.int32(1)))
    group_size_2030 = np.int32(512)
    num_groups_2031 = squot32(((row_1387 + group_size_2030) - np.int32(1)),
                              group_size_2030)
    if ((np.int32(1) * (num_groups_2031 * group_size_2030)) != np.int32(0)):
      self.map_kernel_1947_var.set_args(np.int32(y_1450), np.int32(row_1387),
                                        mem_1992, mem_1994, mem_1996, mem_1998)
      cl.enqueue_nd_range_kernel(self.queue, self.map_kernel_1947_var,
                                 (long((num_groups_2031 * group_size_2030)),),
                                 (long(group_size_2030),))
      if synchronous:
        self.queue.finish()
    nesting_size_1821 = (col_1388 * row_1387)
    bytes_2001 = (bytes_1995 * col_1388)
    double_buffer_mem_2008 = cl.Buffer(self.ctx, cl.mem_flags.READ_WRITE,
                                       long(long(bytes_2001) if (bytes_2001 > np.int32(0)) else np.int32(1)))
    mem_2003 = cl.Buffer(self.ctx, cl.mem_flags.READ_WRITE,
                         long(long(bytes_2001) if (bytes_2001 > np.int32(0)) else np.int32(1)))
    temp_mem_size_1999 = temp_mem_size_1987
    temp_mem_2000 = temp_mem_1988
    size_1432 = col_1388
    i_1434 = np.int32(0)
    one_2041 = np.int32(1)
    for counter_2040 in range(num_iterations_1389):
      group_size_2036 = np.int32(512)
      num_groups_2037 = squot32((((row_1387 * col_1388) + group_size_2036) - np.int32(1)),
                                group_size_2036)
      if ((np.int32(1) * (num_groups_2037 * group_size_2036)) != np.int32(0)):
        self.map_kernel_1823_var.set_args(np.float32(res_1416), mem_1992,
                                          np.int32(col_1388), temp_mem_2000,
                                          np.int32(size_1432),
                                          np.float32(x_1448), mem_1996,
                                          np.int32(y_1449),
                                          np.float32(res_1421),
                                          np.float32(res_1410), mem_1994,
                                          power_mem_1990, mem_1998,
                                          np.int32(row_1387), mem_2003)
        cl.enqueue_nd_range_kernel(self.queue, self.map_kernel_1823_var,
                                   (long((num_groups_2037 * group_size_2036)),),
                                   (long(group_size_2036),))
        if synchronous:
          self.queue.finish()
      if (((row_1387 * size_1446) * np.int32(4)) != np.int32(0)):
        cl.enqueue_copy(self.queue, double_buffer_mem_2008, mem_2003,
                        dest_offset=long(np.int32(0)),
                        src_offset=long(np.int32(0)),
                        byte_count=long(((row_1387 * size_1446) * np.int32(4))))
      if synchronous:
        self.queue.finish()
      temp_mem_size_tmp_2032 = bytes_2001
      temp_mem_tmp_2033 = double_buffer_mem_2008
      size_tmp_2034 = size_1446
      temp_mem_size_1999 = temp_mem_size_tmp_2032
      temp_mem_2000 = temp_mem_tmp_2033
      size_1432 = size_tmp_2034
      i_1434 += one_2041
    temp_mem_2005 = temp_mem_2000
    size_1626 = size_1432
    temp_mem_size_2004 = temp_mem_size_1999
    assert_arg_1630 = (col_1388 == size_1626)
    assert assert_arg_1630, 'hotspot.fut:87:23-87:23'
    out_mem_2028 = temp_mem_2005
    out_memsize_2029 = temp_mem_size_2004
    return (out_memsize_2029, out_mem_2028)
  def render_frame(self, temp_mem_1956_ext):
    row_1118 = np.int32(temp_mem_1956_ext.shape[np.int32(0)])
    col_1119 = np.int32(temp_mem_1956_ext.shape[np.int32(1)])
    temp_mem_size_1955 = np.int32(temp_mem_1956_ext.nbytes)
    if (type(temp_mem_1956_ext) == cl.array.Array):
      temp_mem_1956 = temp_mem_1956_ext.data
    else:
      temp_mem_1956 = cl.Buffer(self.ctx, cl.mem_flags.READ_WRITE,
                                long(long(temp_mem_size_1955) if (temp_mem_size_1955 > np.int32(0)) else np.int32(1)))
      if (temp_mem_size_1955 != np.int32(0)):
        cl.enqueue_copy(self.queue, temp_mem_1956, temp_mem_1956_ext,
                        is_blocking=synchronous)
    (out_memsize_2012,
     out_mem_2011) = self.futhark_render_frame(temp_mem_size_1955,
                                               temp_mem_1956, row_1118,
                                               col_1119)
    return cl.array.Array(self.queue, (row_1118, col_1119, np.int32(3)),
                          ct.c_int8, data=out_mem_2011)
  def main(self, num_iterations_1137_ext, temp_mem_1969_ext,
           power_mem_1971_ext):
    num_iterations_1137 = np.int32(num_iterations_1137_ext)
    row_1135 = np.int32(temp_mem_1969_ext.shape[np.int32(0)])
    col_1136 = np.int32(temp_mem_1969_ext.shape[np.int32(1)])
    temp_mem_size_1968 = np.int32(temp_mem_1969_ext.nbytes)
    if (type(temp_mem_1969_ext) == cl.array.Array):
      temp_mem_1969 = temp_mem_1969_ext.data
    else:
      temp_mem_1969 = cl.Buffer(self.ctx, cl.mem_flags.READ_WRITE,
                                long(long(temp_mem_size_1968) if (temp_mem_size_1968 > np.int32(0)) else np.int32(1)))
      if (temp_mem_size_1968 != np.int32(0)):
        cl.enqueue_copy(self.queue, temp_mem_1969, temp_mem_1969_ext,
                        is_blocking=synchronous)
    row_1135 = np.int32(power_mem_1971_ext.shape[np.int32(0)])
    col_1136 = np.int32(power_mem_1971_ext.shape[np.int32(1)])
    power_mem_size_1970 = np.int32(power_mem_1971_ext.nbytes)
    if (type(power_mem_1971_ext) == cl.array.Array):
      power_mem_1971 = power_mem_1971_ext.data
    else:
      power_mem_1971 = cl.Buffer(self.ctx, cl.mem_flags.READ_WRITE,
                                 long(long(power_mem_size_1970) if (power_mem_size_1970 > np.int32(0)) else np.int32(1)))
      if (power_mem_size_1970 != np.int32(0)):
        cl.enqueue_copy(self.queue, power_mem_1971, power_mem_1971_ext,
                        is_blocking=synchronous)
    (out_memsize_2017, out_mem_2016, out_arrsize_2018,
     out_arrsize_2019) = self.futhark_main(temp_mem_size_1968,
                                           power_mem_size_1970, temp_mem_1969,
                                           power_mem_1971, row_1135, col_1136,
                                           num_iterations_1137)
    return cl.array.Array(self.queue, (out_arrsize_2018, out_arrsize_2019),
                          ct.c_float, data=out_mem_2016)
  def compute_tran_temp(self, num_iterations_1389_ext, temp_mem_1988_ext,
                        power_mem_1990_ext):
    num_iterations_1389 = np.int32(num_iterations_1389_ext)
    row_1387 = np.int32(temp_mem_1988_ext.shape[np.int32(0)])
    col_1388 = np.int32(temp_mem_1988_ext.shape[np.int32(1)])
    temp_mem_size_1987 = np.int32(temp_mem_1988_ext.nbytes)
    if (type(temp_mem_1988_ext) == cl.array.Array):
      temp_mem_1988 = temp_mem_1988_ext.data
    else:
      temp_mem_1988 = cl.Buffer(self.ctx, cl.mem_flags.READ_WRITE,
                                long(long(temp_mem_size_1987) if (temp_mem_size_1987 > np.int32(0)) else np.int32(1)))
      if (temp_mem_size_1987 != np.int32(0)):
        cl.enqueue_copy(self.queue, temp_mem_1988, temp_mem_1988_ext,
                        is_blocking=synchronous)
    row_1387 = np.int32(power_mem_1990_ext.shape[np.int32(0)])
    col_1388 = np.int32(power_mem_1990_ext.shape[np.int32(1)])
    power_mem_size_1989 = np.int32(power_mem_1990_ext.nbytes)
    if (type(power_mem_1990_ext) == cl.array.Array):
      power_mem_1990 = power_mem_1990_ext.data
    else:
      power_mem_1990 = cl.Buffer(self.ctx, cl.mem_flags.READ_WRITE,
                                 long(long(power_mem_size_1989) if (power_mem_size_1989 > np.int32(0)) else np.int32(1)))
      if (power_mem_size_1989 != np.int32(0)):
        cl.enqueue_copy(self.queue, power_mem_1990, power_mem_1990_ext,
                        is_blocking=synchronous)
    (out_memsize_2029,
     out_mem_2028) = self.futhark_compute_tran_temp(temp_mem_size_1987,
                                                    power_mem_size_1989,
                                                    temp_mem_1988,
                                                    power_mem_1990, row_1387,
                                                    col_1388,
                                                    num_iterations_1389)
    return cl.array.Array(self.queue, (row_1387, col_1388), ct.c_float,
                          data=out_mem_2028)