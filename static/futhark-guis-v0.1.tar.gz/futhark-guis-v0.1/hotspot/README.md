HotSpot Visualisation with PyGame
==

Try running `./hotspot-gui.py 800`.  Use the mouse to draw heat
sources (all of them will have the same intensity), then press Space
to run.  You can use Space to toggle between drawing more heat sources
and continuing the simulation.

Most of the parameters (such as ambient temperature and chip
properties) are hardcoded in the Futhark program.
